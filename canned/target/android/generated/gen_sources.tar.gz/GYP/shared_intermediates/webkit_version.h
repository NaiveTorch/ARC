// Copyright 2013 The Chromium Authors. All rights reserved.
// Use of this source is governed by a BSD-style license that can be
// found in the LICENSE file.

// webkit_version.h is generated from webkit_version.h.in.  Edit the source!

#define WEBKIT_VERSION_MAJOR 537
#define WEBKIT_VERSION_MINOR 36
#define WEBKIT_SVN_REVISION "@159105"

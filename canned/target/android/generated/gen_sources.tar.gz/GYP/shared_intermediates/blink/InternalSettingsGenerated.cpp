/*
 * THIS FILE WAS AUTOMATICALLY GENERATED, DO NOT EDIT.
 *
 * Copyright (C) 2011 Google Inc.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY GOOGLE, INC. ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL APPLE COMPUTER, INC. OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "config.h"
#include "InternalSettingsGenerated.h"

#include "core/page/Page.h"
#include "core/page/Settings.h"

namespace WebCore {

InternalSettingsGenerated::InternalSettingsGenerated(Page* page)
    : m_page(page)
    , m_DOMPasteAllowed(page->settings()->DOMPasteAllowed())
    , m_accelerated2dCanvasEnabled(page->settings()->accelerated2dCanvasEnabled())
    , m_acceleratedCompositingEnabled(page->settings()->acceleratedCompositingEnabled())
    , m_acceleratedCompositingFor3DTransformsEnabled(page->settings()->acceleratedCompositingFor3DTransformsEnabled())
    , m_acceleratedCompositingForAnimationEnabled(page->settings()->acceleratedCompositingForAnimationEnabled())
    , m_acceleratedCompositingForCanvasEnabled(page->settings()->acceleratedCompositingForCanvasEnabled())
    , m_acceleratedCompositingForFiltersEnabled(page->settings()->acceleratedCompositingForFiltersEnabled())
    , m_acceleratedCompositingForFixedPositionEnabled(page->settings()->acceleratedCompositingForFixedPositionEnabled())
    , m_acceleratedCompositingForFixedRootBackgroundEnabled(page->settings()->acceleratedCompositingForFixedRootBackgroundEnabled())
    , m_acceleratedCompositingForOverflowScrollEnabled(page->settings()->acceleratedCompositingForOverflowScrollEnabled())
    , m_acceleratedCompositingForPluginsEnabled(page->settings()->acceleratedCompositingForPluginsEnabled())
    , m_acceleratedCompositingForScrollableFramesEnabled(page->settings()->acceleratedCompositingForScrollableFramesEnabled())
    , m_acceleratedCompositingForTransitionEnabled(page->settings()->acceleratedCompositingForTransitionEnabled())
    , m_acceleratedCompositingForVideoEnabled(page->settings()->acceleratedCompositingForVideoEnabled())
    , m_acceleratedFiltersEnabled(page->settings()->acceleratedFiltersEnabled())
    , m_allowCustomScrollbarInMainFrame(page->settings()->allowCustomScrollbarInMainFrame())
    , m_allowDisplayOfInsecureContent(page->settings()->allowDisplayOfInsecureContent())
    , m_allowFileAccessFromFileURLs(page->settings()->allowFileAccessFromFileURLs())
    , m_allowRunningOfInsecureContent(page->settings()->allowRunningOfInsecureContent())
    , m_allowScriptsToCloseWindows(page->settings()->allowScriptsToCloseWindows())
    , m_allowUniversalAccessFromFileURLs(page->settings()->allowUniversalAccessFromFileURLs())
    , m_antialiased2dCanvasEnabled(page->settings()->antialiased2dCanvasEnabled())
    , m_applyPageScaleFactorInCompositor(page->settings()->applyPageScaleFactorInCompositor())
    , m_asynchronousSpellCheckingEnabled(page->settings()->asynchronousSpellCheckingEnabled())
    , m_authorAndUserStylesEnabled(page->settings()->authorAndUserStylesEnabled())
    , m_caretBrowsingEnabled(page->settings()->caretBrowsingEnabled())
    , m_compositedScrollingForFramesEnabled(page->settings()->compositedScrollingForFramesEnabled())
    , m_compositorTouchHitTesting(page->settings()->compositorTouchHitTesting())
    , m_cookieEnabled(page->settings()->cookieEnabled())
    , m_defaultFixedFontSize(page->settings()->defaultFixedFontSize())
    , m_defaultFontSize(page->settings()->defaultFontSize())
    , m_defaultTextEncodingName(page->settings()->defaultTextEncodingName())
    , m_defaultVideoPosterURL(page->settings()->defaultVideoPosterURL())
    , m_deviceSupportsMouse(page->settings()->deviceSupportsMouse())
    , m_deviceSupportsTouch(page->settings()->deviceSupportsTouch())
    , m_downloadableBinaryFontsEnabled(page->settings()->downloadableBinaryFontsEnabled())
    , m_experimentalWebSocketEnabled(page->settings()->experimentalWebSocketEnabled())
    , m_fixedPositionCreatesStackingContext(page->settings()->fixedPositionCreatesStackingContext())
    , m_forceCompositingMode(page->settings()->forceCompositingMode())
    , m_fullScreenEnabled(page->settings()->fullScreenEnabled())
    , m_hyperlinkAuditingEnabled(page->settings()->hyperlinkAuditingEnabled())
    , m_ignoreMainFrameOverflowHiddenQuirk(page->settings()->ignoreMainFrameOverflowHiddenQuirk())
    , m_javaScriptCanAccessClipboard(page->settings()->javaScriptCanAccessClipboard())
    , m_javaScriptCanOpenWindowsAutomatically(page->settings()->javaScriptCanOpenWindowsAutomatically())
    , m_layoutFallbackWidth(page->settings()->layoutFallbackWidth())
    , m_localStorageEnabled(page->settings()->localStorageEnabled())
    , m_mediaEnabled(page->settings()->mediaEnabled())
    , m_mediaPlaybackRequiresUserGesture(page->settings()->mediaPlaybackRequiresUserGesture())
    , m_memoryInfoEnabled(page->settings()->memoryInfoEnabled())
    , m_minimumAccelerated2dCanvasSize(page->settings()->minimumAccelerated2dCanvasSize())
    , m_minimumFontSize(page->settings()->minimumFontSize())
    , m_minimumLogicalFontSize(page->settings()->minimumLogicalFontSize())
    , m_needsSiteSpecificQuirks(page->settings()->needsSiteSpecificQuirks())
    , m_offlineWebApplicationCacheEnabled(page->settings()->offlineWebApplicationCacheEnabled())
    , m_pageCacheSupportsPlugins(page->settings()->pageCacheSupportsPlugins())
    , m_passwordEchoDurationInSeconds(page->settings()->passwordEchoDurationInSeconds())
    , m_passwordEchoEnabled(page->settings()->passwordEchoEnabled())
    , m_pinchVirtualViewportEnabled(page->settings()->pinchVirtualViewportEnabled())
    , m_privilegedWebGLExtensionsEnabled(page->settings()->privilegedWebGLExtensionsEnabled())
    , m_regionBasedColumnsEnabled(page->settings()->regionBasedColumnsEnabled())
    , m_reportScreenSizeInPhysicalPixelsQuirk(page->settings()->reportScreenSizeInPhysicalPixelsQuirk())
    , m_scrollAnimatorEnabled(page->settings()->scrollAnimatorEnabled())
    , m_scrollingCoordinatorEnabled(page->settings()->scrollingCoordinatorEnabled())
    , m_selectTrailingWhitespaceEnabled(page->settings()->selectTrailingWhitespaceEnabled())
    , m_selectionIncludesAltImageText(page->settings()->selectionIncludesAltImageText())
    , m_shouldClearDocumentBackground(page->settings()->shouldClearDocumentBackground())
    , m_shouldDisplayCaptions(page->settings()->shouldDisplayCaptions())
    , m_shouldDisplaySubtitles(page->settings()->shouldDisplaySubtitles())
    , m_shouldDisplayTextDescriptions(page->settings()->shouldDisplayTextDescriptions())
    , m_shouldPrintBackgrounds(page->settings()->shouldPrintBackgrounds())
    , m_shouldRespectImageOrientation(page->settings()->shouldRespectImageOrientation())
    , m_showRepaintCounter(page->settings()->showRepaintCounter())
    , m_shrinksStandaloneImagesToFit(page->settings()->shrinksStandaloneImagesToFit())
    , m_smartInsertDeleteEnabled(page->settings()->smartInsertDeleteEnabled())
    , m_spatialNavigationEnabled(page->settings()->spatialNavigationEnabled())
    , m_supportsMultipleWindows(page->settings()->supportsMultipleWindows())
    , m_syncXHRInDocumentsEnabled(page->settings()->syncXHRInDocumentsEnabled())
    , m_textAreasAreResizable(page->settings()->textAreasAreResizable())
    , m_threadedHTMLParser(page->settings()->threadedHTMLParser())
    , m_touchAdjustmentEnabled(page->settings()->touchAdjustmentEnabled())
    , m_touchDragDropEnabled(page->settings()->touchDragDropEnabled())
    , m_touchEditingEnabled(page->settings()->touchEditingEnabled())
    , m_unifiedTextCheckerEnabled(page->settings()->unifiedTextCheckerEnabled())
    , m_unsafePluginPastingEnabled(page->settings()->unsafePluginPastingEnabled())
    , m_useLegacyBackgroundSizeShorthandBehavior(page->settings()->useLegacyBackgroundSizeShorthandBehavior())
    , m_useThreadedHTMLParserForDataURLs(page->settings()->useThreadedHTMLParserForDataURLs())
    , m_usesEncodingDetector(page->settings()->usesEncodingDetector())
    , m_validationMessageTimerMagnification(page->settings()->validationMessageTimerMagnification())
    , m_viewportMetaMergeQuirk(page->settings()->viewportMetaMergeQuirk())
    , m_viewportMetaZeroValuesQuirk(page->settings()->viewportMetaZeroValuesQuirk())
    , m_visualWordMovementEnabled(page->settings()->visualWordMovementEnabled())
    , m_webAudioEnabled(page->settings()->webAudioEnabled())
    , m_webGLEnabled(page->settings()->webGLEnabled())
    , m_webGLErrorsToConsoleEnabled(page->settings()->webGLErrorsToConsoleEnabled())
    , m_webSecurityEnabled(page->settings()->webSecurityEnabled())
    , m_wideViewportQuirkEnabled(page->settings()->wideViewportQuirkEnabled())
    , m_xssAuditorEnabled(page->settings()->xssAuditorEnabled())
{
}

InternalSettingsGenerated::~InternalSettingsGenerated()
{
}

void InternalSettingsGenerated::resetToConsistentState()
{
    m_page->settings()->setDOMPasteAllowed(m_DOMPasteAllowed);
    m_page->settings()->setAccelerated2dCanvasEnabled(m_accelerated2dCanvasEnabled);
    m_page->settings()->setAcceleratedCompositingEnabled(m_acceleratedCompositingEnabled);
    m_page->settings()->setAcceleratedCompositingFor3DTransformsEnabled(m_acceleratedCompositingFor3DTransformsEnabled);
    m_page->settings()->setAcceleratedCompositingForAnimationEnabled(m_acceleratedCompositingForAnimationEnabled);
    m_page->settings()->setAcceleratedCompositingForCanvasEnabled(m_acceleratedCompositingForCanvasEnabled);
    m_page->settings()->setAcceleratedCompositingForFiltersEnabled(m_acceleratedCompositingForFiltersEnabled);
    m_page->settings()->setAcceleratedCompositingForFixedPositionEnabled(m_acceleratedCompositingForFixedPositionEnabled);
    m_page->settings()->setAcceleratedCompositingForFixedRootBackgroundEnabled(m_acceleratedCompositingForFixedRootBackgroundEnabled);
    m_page->settings()->setAcceleratedCompositingForOverflowScrollEnabled(m_acceleratedCompositingForOverflowScrollEnabled);
    m_page->settings()->setAcceleratedCompositingForPluginsEnabled(m_acceleratedCompositingForPluginsEnabled);
    m_page->settings()->setAcceleratedCompositingForScrollableFramesEnabled(m_acceleratedCompositingForScrollableFramesEnabled);
    m_page->settings()->setAcceleratedCompositingForTransitionEnabled(m_acceleratedCompositingForTransitionEnabled);
    m_page->settings()->setAcceleratedCompositingForVideoEnabled(m_acceleratedCompositingForVideoEnabled);
    m_page->settings()->setAcceleratedFiltersEnabled(m_acceleratedFiltersEnabled);
    m_page->settings()->setAllowCustomScrollbarInMainFrame(m_allowCustomScrollbarInMainFrame);
    m_page->settings()->setAllowDisplayOfInsecureContent(m_allowDisplayOfInsecureContent);
    m_page->settings()->setAllowFileAccessFromFileURLs(m_allowFileAccessFromFileURLs);
    m_page->settings()->setAllowRunningOfInsecureContent(m_allowRunningOfInsecureContent);
    m_page->settings()->setAllowScriptsToCloseWindows(m_allowScriptsToCloseWindows);
    m_page->settings()->setAllowUniversalAccessFromFileURLs(m_allowUniversalAccessFromFileURLs);
    m_page->settings()->setAntialiased2dCanvasEnabled(m_antialiased2dCanvasEnabled);
    m_page->settings()->setApplyPageScaleFactorInCompositor(m_applyPageScaleFactorInCompositor);
    m_page->settings()->setAsynchronousSpellCheckingEnabled(m_asynchronousSpellCheckingEnabled);
    m_page->settings()->setAuthorAndUserStylesEnabled(m_authorAndUserStylesEnabled);
    m_page->settings()->setCaretBrowsingEnabled(m_caretBrowsingEnabled);
    m_page->settings()->setCompositedScrollingForFramesEnabled(m_compositedScrollingForFramesEnabled);
    m_page->settings()->setCompositorTouchHitTesting(m_compositorTouchHitTesting);
    m_page->settings()->setCookieEnabled(m_cookieEnabled);
    m_page->settings()->setDefaultFixedFontSize(m_defaultFixedFontSize);
    m_page->settings()->setDefaultFontSize(m_defaultFontSize);
    m_page->settings()->setDefaultTextEncodingName(m_defaultTextEncodingName);
    m_page->settings()->setDefaultVideoPosterURL(m_defaultVideoPosterURL);
    m_page->settings()->setDeviceSupportsMouse(m_deviceSupportsMouse);
    m_page->settings()->setDeviceSupportsTouch(m_deviceSupportsTouch);
    m_page->settings()->setDownloadableBinaryFontsEnabled(m_downloadableBinaryFontsEnabled);
    m_page->settings()->setExperimentalWebSocketEnabled(m_experimentalWebSocketEnabled);
    m_page->settings()->setFixedPositionCreatesStackingContext(m_fixedPositionCreatesStackingContext);
    m_page->settings()->setForceCompositingMode(m_forceCompositingMode);
    m_page->settings()->setFullScreenEnabled(m_fullScreenEnabled);
    m_page->settings()->setHyperlinkAuditingEnabled(m_hyperlinkAuditingEnabled);
    m_page->settings()->setIgnoreMainFrameOverflowHiddenQuirk(m_ignoreMainFrameOverflowHiddenQuirk);
    m_page->settings()->setJavaScriptCanAccessClipboard(m_javaScriptCanAccessClipboard);
    m_page->settings()->setJavaScriptCanOpenWindowsAutomatically(m_javaScriptCanOpenWindowsAutomatically);
    m_page->settings()->setLayoutFallbackWidth(m_layoutFallbackWidth);
    m_page->settings()->setLocalStorageEnabled(m_localStorageEnabled);
    m_page->settings()->setMediaEnabled(m_mediaEnabled);
    m_page->settings()->setMediaPlaybackRequiresUserGesture(m_mediaPlaybackRequiresUserGesture);
    m_page->settings()->setMemoryInfoEnabled(m_memoryInfoEnabled);
    m_page->settings()->setMinimumAccelerated2dCanvasSize(m_minimumAccelerated2dCanvasSize);
    m_page->settings()->setMinimumFontSize(m_minimumFontSize);
    m_page->settings()->setMinimumLogicalFontSize(m_minimumLogicalFontSize);
    m_page->settings()->setNeedsSiteSpecificQuirks(m_needsSiteSpecificQuirks);
    m_page->settings()->setOfflineWebApplicationCacheEnabled(m_offlineWebApplicationCacheEnabled);
    m_page->settings()->setPageCacheSupportsPlugins(m_pageCacheSupportsPlugins);
    m_page->settings()->setPasswordEchoDurationInSeconds(m_passwordEchoDurationInSeconds);
    m_page->settings()->setPasswordEchoEnabled(m_passwordEchoEnabled);
    m_page->settings()->setPinchVirtualViewportEnabled(m_pinchVirtualViewportEnabled);
    m_page->settings()->setPrivilegedWebGLExtensionsEnabled(m_privilegedWebGLExtensionsEnabled);
    m_page->settings()->setRegionBasedColumnsEnabled(m_regionBasedColumnsEnabled);
    m_page->settings()->setReportScreenSizeInPhysicalPixelsQuirk(m_reportScreenSizeInPhysicalPixelsQuirk);
    m_page->settings()->setScrollAnimatorEnabled(m_scrollAnimatorEnabled);
    m_page->settings()->setScrollingCoordinatorEnabled(m_scrollingCoordinatorEnabled);
    m_page->settings()->setSelectTrailingWhitespaceEnabled(m_selectTrailingWhitespaceEnabled);
    m_page->settings()->setSelectionIncludesAltImageText(m_selectionIncludesAltImageText);
    m_page->settings()->setShouldClearDocumentBackground(m_shouldClearDocumentBackground);
    m_page->settings()->setShouldDisplayCaptions(m_shouldDisplayCaptions);
    m_page->settings()->setShouldDisplaySubtitles(m_shouldDisplaySubtitles);
    m_page->settings()->setShouldDisplayTextDescriptions(m_shouldDisplayTextDescriptions);
    m_page->settings()->setShouldPrintBackgrounds(m_shouldPrintBackgrounds);
    m_page->settings()->setShouldRespectImageOrientation(m_shouldRespectImageOrientation);
    m_page->settings()->setShowRepaintCounter(m_showRepaintCounter);
    m_page->settings()->setShrinksStandaloneImagesToFit(m_shrinksStandaloneImagesToFit);
    m_page->settings()->setSmartInsertDeleteEnabled(m_smartInsertDeleteEnabled);
    m_page->settings()->setSpatialNavigationEnabled(m_spatialNavigationEnabled);
    m_page->settings()->setSupportsMultipleWindows(m_supportsMultipleWindows);
    m_page->settings()->setSyncXHRInDocumentsEnabled(m_syncXHRInDocumentsEnabled);
    m_page->settings()->setTextAreasAreResizable(m_textAreasAreResizable);
    m_page->settings()->setThreadedHTMLParser(m_threadedHTMLParser);
    m_page->settings()->setTouchAdjustmentEnabled(m_touchAdjustmentEnabled);
    m_page->settings()->setTouchDragDropEnabled(m_touchDragDropEnabled);
    m_page->settings()->setTouchEditingEnabled(m_touchEditingEnabled);
    m_page->settings()->setUnifiedTextCheckerEnabled(m_unifiedTextCheckerEnabled);
    m_page->settings()->setUnsafePluginPastingEnabled(m_unsafePluginPastingEnabled);
    m_page->settings()->setUseLegacyBackgroundSizeShorthandBehavior(m_useLegacyBackgroundSizeShorthandBehavior);
    m_page->settings()->setUseThreadedHTMLParserForDataURLs(m_useThreadedHTMLParserForDataURLs);
    m_page->settings()->setUsesEncodingDetector(m_usesEncodingDetector);
    m_page->settings()->setValidationMessageTimerMagnification(m_validationMessageTimerMagnification);
    m_page->settings()->setViewportMetaMergeQuirk(m_viewportMetaMergeQuirk);
    m_page->settings()->setViewportMetaZeroValuesQuirk(m_viewportMetaZeroValuesQuirk);
    m_page->settings()->setVisualWordMovementEnabled(m_visualWordMovementEnabled);
    m_page->settings()->setWebAudioEnabled(m_webAudioEnabled);
    m_page->settings()->setWebGLEnabled(m_webGLEnabled);
    m_page->settings()->setWebGLErrorsToConsoleEnabled(m_webGLErrorsToConsoleEnabled);
    m_page->settings()->setWebSecurityEnabled(m_webSecurityEnabled);
    m_page->settings()->setWideViewportQuirkEnabled(m_wideViewportQuirkEnabled);
    m_page->settings()->setXSSAuditorEnabled(m_xssAuditorEnabled);
}
void InternalSettingsGenerated::setDOMPasteAllowed(bool DOMPasteAllowed)
{
    m_page->settings()->setDOMPasteAllowed(DOMPasteAllowed);
}

void InternalSettingsGenerated::setAccelerated2dCanvasEnabled(bool accelerated2dCanvasEnabled)
{
    m_page->settings()->setAccelerated2dCanvasEnabled(accelerated2dCanvasEnabled);
}

void InternalSettingsGenerated::setAcceleratedCompositingEnabled(bool acceleratedCompositingEnabled)
{
    m_page->settings()->setAcceleratedCompositingEnabled(acceleratedCompositingEnabled);
}

void InternalSettingsGenerated::setAcceleratedCompositingFor3DTransformsEnabled(bool acceleratedCompositingFor3DTransformsEnabled)
{
    m_page->settings()->setAcceleratedCompositingFor3DTransformsEnabled(acceleratedCompositingFor3DTransformsEnabled);
}

void InternalSettingsGenerated::setAcceleratedCompositingForAnimationEnabled(bool acceleratedCompositingForAnimationEnabled)
{
    m_page->settings()->setAcceleratedCompositingForAnimationEnabled(acceleratedCompositingForAnimationEnabled);
}

void InternalSettingsGenerated::setAcceleratedCompositingForCanvasEnabled(bool acceleratedCompositingForCanvasEnabled)
{
    m_page->settings()->setAcceleratedCompositingForCanvasEnabled(acceleratedCompositingForCanvasEnabled);
}

void InternalSettingsGenerated::setAcceleratedCompositingForFiltersEnabled(bool acceleratedCompositingForFiltersEnabled)
{
    m_page->settings()->setAcceleratedCompositingForFiltersEnabled(acceleratedCompositingForFiltersEnabled);
}

void InternalSettingsGenerated::setAcceleratedCompositingForFixedPositionEnabled(bool acceleratedCompositingForFixedPositionEnabled)
{
    m_page->settings()->setAcceleratedCompositingForFixedPositionEnabled(acceleratedCompositingForFixedPositionEnabled);
}

void InternalSettingsGenerated::setAcceleratedCompositingForFixedRootBackgroundEnabled(bool acceleratedCompositingForFixedRootBackgroundEnabled)
{
    m_page->settings()->setAcceleratedCompositingForFixedRootBackgroundEnabled(acceleratedCompositingForFixedRootBackgroundEnabled);
}

void InternalSettingsGenerated::setAcceleratedCompositingForOverflowScrollEnabled(bool acceleratedCompositingForOverflowScrollEnabled)
{
    m_page->settings()->setAcceleratedCompositingForOverflowScrollEnabled(acceleratedCompositingForOverflowScrollEnabled);
}

void InternalSettingsGenerated::setAcceleratedCompositingForPluginsEnabled(bool acceleratedCompositingForPluginsEnabled)
{
    m_page->settings()->setAcceleratedCompositingForPluginsEnabled(acceleratedCompositingForPluginsEnabled);
}

void InternalSettingsGenerated::setAcceleratedCompositingForScrollableFramesEnabled(bool acceleratedCompositingForScrollableFramesEnabled)
{
    m_page->settings()->setAcceleratedCompositingForScrollableFramesEnabled(acceleratedCompositingForScrollableFramesEnabled);
}

void InternalSettingsGenerated::setAcceleratedCompositingForTransitionEnabled(bool acceleratedCompositingForTransitionEnabled)
{
    m_page->settings()->setAcceleratedCompositingForTransitionEnabled(acceleratedCompositingForTransitionEnabled);
}

void InternalSettingsGenerated::setAcceleratedCompositingForVideoEnabled(bool acceleratedCompositingForVideoEnabled)
{
    m_page->settings()->setAcceleratedCompositingForVideoEnabled(acceleratedCompositingForVideoEnabled);
}

void InternalSettingsGenerated::setAcceleratedFiltersEnabled(bool acceleratedFiltersEnabled)
{
    m_page->settings()->setAcceleratedFiltersEnabled(acceleratedFiltersEnabled);
}

void InternalSettingsGenerated::setAllowCustomScrollbarInMainFrame(bool allowCustomScrollbarInMainFrame)
{
    m_page->settings()->setAllowCustomScrollbarInMainFrame(allowCustomScrollbarInMainFrame);
}

void InternalSettingsGenerated::setAllowDisplayOfInsecureContent(bool allowDisplayOfInsecureContent)
{
    m_page->settings()->setAllowDisplayOfInsecureContent(allowDisplayOfInsecureContent);
}

void InternalSettingsGenerated::setAllowFileAccessFromFileURLs(bool allowFileAccessFromFileURLs)
{
    m_page->settings()->setAllowFileAccessFromFileURLs(allowFileAccessFromFileURLs);
}

void InternalSettingsGenerated::setAllowRunningOfInsecureContent(bool allowRunningOfInsecureContent)
{
    m_page->settings()->setAllowRunningOfInsecureContent(allowRunningOfInsecureContent);
}

void InternalSettingsGenerated::setAllowScriptsToCloseWindows(bool allowScriptsToCloseWindows)
{
    m_page->settings()->setAllowScriptsToCloseWindows(allowScriptsToCloseWindows);
}

void InternalSettingsGenerated::setAllowUniversalAccessFromFileURLs(bool allowUniversalAccessFromFileURLs)
{
    m_page->settings()->setAllowUniversalAccessFromFileURLs(allowUniversalAccessFromFileURLs);
}

void InternalSettingsGenerated::setAntialiased2dCanvasEnabled(bool antialiased2dCanvasEnabled)
{
    m_page->settings()->setAntialiased2dCanvasEnabled(antialiased2dCanvasEnabled);
}

void InternalSettingsGenerated::setApplyPageScaleFactorInCompositor(bool applyPageScaleFactorInCompositor)
{
    m_page->settings()->setApplyPageScaleFactorInCompositor(applyPageScaleFactorInCompositor);
}

void InternalSettingsGenerated::setAsynchronousSpellCheckingEnabled(bool asynchronousSpellCheckingEnabled)
{
    m_page->settings()->setAsynchronousSpellCheckingEnabled(asynchronousSpellCheckingEnabled);
}

void InternalSettingsGenerated::setAuthorAndUserStylesEnabled(bool authorAndUserStylesEnabled)
{
    m_page->settings()->setAuthorAndUserStylesEnabled(authorAndUserStylesEnabled);
}

void InternalSettingsGenerated::setCaretBrowsingEnabled(bool caretBrowsingEnabled)
{
    m_page->settings()->setCaretBrowsingEnabled(caretBrowsingEnabled);
}

void InternalSettingsGenerated::setCompositedScrollingForFramesEnabled(bool compositedScrollingForFramesEnabled)
{
    m_page->settings()->setCompositedScrollingForFramesEnabled(compositedScrollingForFramesEnabled);
}

void InternalSettingsGenerated::setCompositorTouchHitTesting(bool compositorTouchHitTesting)
{
    m_page->settings()->setCompositorTouchHitTesting(compositorTouchHitTesting);
}

void InternalSettingsGenerated::setCookieEnabled(bool cookieEnabled)
{
    m_page->settings()->setCookieEnabled(cookieEnabled);
}

void InternalSettingsGenerated::setDefaultFixedFontSize(int defaultFixedFontSize)
{
    m_page->settings()->setDefaultFixedFontSize(defaultFixedFontSize);
}

void InternalSettingsGenerated::setDefaultFontSize(int defaultFontSize)
{
    m_page->settings()->setDefaultFontSize(defaultFontSize);
}

void InternalSettingsGenerated::setDefaultTextEncodingName(const String& defaultTextEncodingName)
{
    m_page->settings()->setDefaultTextEncodingName(defaultTextEncodingName);
}

void InternalSettingsGenerated::setDefaultVideoPosterURL(const String& defaultVideoPosterURL)
{
    m_page->settings()->setDefaultVideoPosterURL(defaultVideoPosterURL);
}

void InternalSettingsGenerated::setDeviceSupportsMouse(bool deviceSupportsMouse)
{
    m_page->settings()->setDeviceSupportsMouse(deviceSupportsMouse);
}

void InternalSettingsGenerated::setDeviceSupportsTouch(bool deviceSupportsTouch)
{
    m_page->settings()->setDeviceSupportsTouch(deviceSupportsTouch);
}

void InternalSettingsGenerated::setDownloadableBinaryFontsEnabled(bool downloadableBinaryFontsEnabled)
{
    m_page->settings()->setDownloadableBinaryFontsEnabled(downloadableBinaryFontsEnabled);
}

void InternalSettingsGenerated::setExperimentalWebSocketEnabled(bool experimentalWebSocketEnabled)
{
    m_page->settings()->setExperimentalWebSocketEnabled(experimentalWebSocketEnabled);
}

void InternalSettingsGenerated::setFixedPositionCreatesStackingContext(bool fixedPositionCreatesStackingContext)
{
    m_page->settings()->setFixedPositionCreatesStackingContext(fixedPositionCreatesStackingContext);
}

void InternalSettingsGenerated::setForceCompositingMode(bool forceCompositingMode)
{
    m_page->settings()->setForceCompositingMode(forceCompositingMode);
}

void InternalSettingsGenerated::setFullScreenEnabled(bool fullScreenEnabled)
{
    m_page->settings()->setFullScreenEnabled(fullScreenEnabled);
}

void InternalSettingsGenerated::setHyperlinkAuditingEnabled(bool hyperlinkAuditingEnabled)
{
    m_page->settings()->setHyperlinkAuditingEnabled(hyperlinkAuditingEnabled);
}

void InternalSettingsGenerated::setIgnoreMainFrameOverflowHiddenQuirk(bool ignoreMainFrameOverflowHiddenQuirk)
{
    m_page->settings()->setIgnoreMainFrameOverflowHiddenQuirk(ignoreMainFrameOverflowHiddenQuirk);
}

void InternalSettingsGenerated::setJavaScriptCanAccessClipboard(bool javaScriptCanAccessClipboard)
{
    m_page->settings()->setJavaScriptCanAccessClipboard(javaScriptCanAccessClipboard);
}

void InternalSettingsGenerated::setJavaScriptCanOpenWindowsAutomatically(bool javaScriptCanOpenWindowsAutomatically)
{
    m_page->settings()->setJavaScriptCanOpenWindowsAutomatically(javaScriptCanOpenWindowsAutomatically);
}

void InternalSettingsGenerated::setLayoutFallbackWidth(int layoutFallbackWidth)
{
    m_page->settings()->setLayoutFallbackWidth(layoutFallbackWidth);
}

void InternalSettingsGenerated::setLocalStorageEnabled(bool localStorageEnabled)
{
    m_page->settings()->setLocalStorageEnabled(localStorageEnabled);
}

void InternalSettingsGenerated::setMediaEnabled(bool mediaEnabled)
{
    m_page->settings()->setMediaEnabled(mediaEnabled);
}

void InternalSettingsGenerated::setMediaPlaybackRequiresUserGesture(bool mediaPlaybackRequiresUserGesture)
{
    m_page->settings()->setMediaPlaybackRequiresUserGesture(mediaPlaybackRequiresUserGesture);
}

void InternalSettingsGenerated::setMemoryInfoEnabled(bool memoryInfoEnabled)
{
    m_page->settings()->setMemoryInfoEnabled(memoryInfoEnabled);
}

void InternalSettingsGenerated::setMinimumAccelerated2dCanvasSize(int minimumAccelerated2dCanvasSize)
{
    m_page->settings()->setMinimumAccelerated2dCanvasSize(minimumAccelerated2dCanvasSize);
}

void InternalSettingsGenerated::setMinimumFontSize(int minimumFontSize)
{
    m_page->settings()->setMinimumFontSize(minimumFontSize);
}

void InternalSettingsGenerated::setMinimumLogicalFontSize(int minimumLogicalFontSize)
{
    m_page->settings()->setMinimumLogicalFontSize(minimumLogicalFontSize);
}

void InternalSettingsGenerated::setNeedsSiteSpecificQuirks(bool needsSiteSpecificQuirks)
{
    m_page->settings()->setNeedsSiteSpecificQuirks(needsSiteSpecificQuirks);
}

void InternalSettingsGenerated::setOfflineWebApplicationCacheEnabled(bool offlineWebApplicationCacheEnabled)
{
    m_page->settings()->setOfflineWebApplicationCacheEnabled(offlineWebApplicationCacheEnabled);
}

void InternalSettingsGenerated::setPageCacheSupportsPlugins(bool pageCacheSupportsPlugins)
{
    m_page->settings()->setPageCacheSupportsPlugins(pageCacheSupportsPlugins);
}

void InternalSettingsGenerated::setPasswordEchoDurationInSeconds(double passwordEchoDurationInSeconds)
{
    m_page->settings()->setPasswordEchoDurationInSeconds(passwordEchoDurationInSeconds);
}

void InternalSettingsGenerated::setPasswordEchoEnabled(bool passwordEchoEnabled)
{
    m_page->settings()->setPasswordEchoEnabled(passwordEchoEnabled);
}

void InternalSettingsGenerated::setPinchVirtualViewportEnabled(bool pinchVirtualViewportEnabled)
{
    m_page->settings()->setPinchVirtualViewportEnabled(pinchVirtualViewportEnabled);
}

void InternalSettingsGenerated::setPrivilegedWebGLExtensionsEnabled(bool privilegedWebGLExtensionsEnabled)
{
    m_page->settings()->setPrivilegedWebGLExtensionsEnabled(privilegedWebGLExtensionsEnabled);
}

void InternalSettingsGenerated::setRegionBasedColumnsEnabled(bool regionBasedColumnsEnabled)
{
    m_page->settings()->setRegionBasedColumnsEnabled(regionBasedColumnsEnabled);
}

void InternalSettingsGenerated::setReportScreenSizeInPhysicalPixelsQuirk(bool reportScreenSizeInPhysicalPixelsQuirk)
{
    m_page->settings()->setReportScreenSizeInPhysicalPixelsQuirk(reportScreenSizeInPhysicalPixelsQuirk);
}

void InternalSettingsGenerated::setScrollAnimatorEnabled(bool scrollAnimatorEnabled)
{
    m_page->settings()->setScrollAnimatorEnabled(scrollAnimatorEnabled);
}

void InternalSettingsGenerated::setScrollingCoordinatorEnabled(bool scrollingCoordinatorEnabled)
{
    m_page->settings()->setScrollingCoordinatorEnabled(scrollingCoordinatorEnabled);
}

void InternalSettingsGenerated::setSelectTrailingWhitespaceEnabled(bool selectTrailingWhitespaceEnabled)
{
    m_page->settings()->setSelectTrailingWhitespaceEnabled(selectTrailingWhitespaceEnabled);
}

void InternalSettingsGenerated::setSelectionIncludesAltImageText(bool selectionIncludesAltImageText)
{
    m_page->settings()->setSelectionIncludesAltImageText(selectionIncludesAltImageText);
}

void InternalSettingsGenerated::setShouldClearDocumentBackground(bool shouldClearDocumentBackground)
{
    m_page->settings()->setShouldClearDocumentBackground(shouldClearDocumentBackground);
}

void InternalSettingsGenerated::setShouldDisplayCaptions(bool shouldDisplayCaptions)
{
    m_page->settings()->setShouldDisplayCaptions(shouldDisplayCaptions);
}

void InternalSettingsGenerated::setShouldDisplaySubtitles(bool shouldDisplaySubtitles)
{
    m_page->settings()->setShouldDisplaySubtitles(shouldDisplaySubtitles);
}

void InternalSettingsGenerated::setShouldDisplayTextDescriptions(bool shouldDisplayTextDescriptions)
{
    m_page->settings()->setShouldDisplayTextDescriptions(shouldDisplayTextDescriptions);
}

void InternalSettingsGenerated::setShouldPrintBackgrounds(bool shouldPrintBackgrounds)
{
    m_page->settings()->setShouldPrintBackgrounds(shouldPrintBackgrounds);
}

void InternalSettingsGenerated::setShouldRespectImageOrientation(bool shouldRespectImageOrientation)
{
    m_page->settings()->setShouldRespectImageOrientation(shouldRespectImageOrientation);
}

void InternalSettingsGenerated::setShowRepaintCounter(bool showRepaintCounter)
{
    m_page->settings()->setShowRepaintCounter(showRepaintCounter);
}

void InternalSettingsGenerated::setShrinksStandaloneImagesToFit(bool shrinksStandaloneImagesToFit)
{
    m_page->settings()->setShrinksStandaloneImagesToFit(shrinksStandaloneImagesToFit);
}

void InternalSettingsGenerated::setSmartInsertDeleteEnabled(bool smartInsertDeleteEnabled)
{
    m_page->settings()->setSmartInsertDeleteEnabled(smartInsertDeleteEnabled);
}

void InternalSettingsGenerated::setSpatialNavigationEnabled(bool spatialNavigationEnabled)
{
    m_page->settings()->setSpatialNavigationEnabled(spatialNavigationEnabled);
}

void InternalSettingsGenerated::setSupportsMultipleWindows(bool supportsMultipleWindows)
{
    m_page->settings()->setSupportsMultipleWindows(supportsMultipleWindows);
}

void InternalSettingsGenerated::setSyncXHRInDocumentsEnabled(bool syncXHRInDocumentsEnabled)
{
    m_page->settings()->setSyncXHRInDocumentsEnabled(syncXHRInDocumentsEnabled);
}

void InternalSettingsGenerated::setTextAreasAreResizable(bool textAreasAreResizable)
{
    m_page->settings()->setTextAreasAreResizable(textAreasAreResizable);
}

void InternalSettingsGenerated::setThreadedHTMLParser(bool threadedHTMLParser)
{
    m_page->settings()->setThreadedHTMLParser(threadedHTMLParser);
}

void InternalSettingsGenerated::setTouchAdjustmentEnabled(bool touchAdjustmentEnabled)
{
    m_page->settings()->setTouchAdjustmentEnabled(touchAdjustmentEnabled);
}

void InternalSettingsGenerated::setTouchDragDropEnabled(bool touchDragDropEnabled)
{
    m_page->settings()->setTouchDragDropEnabled(touchDragDropEnabled);
}

void InternalSettingsGenerated::setTouchEditingEnabled(bool touchEditingEnabled)
{
    m_page->settings()->setTouchEditingEnabled(touchEditingEnabled);
}

void InternalSettingsGenerated::setUnifiedTextCheckerEnabled(bool unifiedTextCheckerEnabled)
{
    m_page->settings()->setUnifiedTextCheckerEnabled(unifiedTextCheckerEnabled);
}

void InternalSettingsGenerated::setUnsafePluginPastingEnabled(bool unsafePluginPastingEnabled)
{
    m_page->settings()->setUnsafePluginPastingEnabled(unsafePluginPastingEnabled);
}

void InternalSettingsGenerated::setUseLegacyBackgroundSizeShorthandBehavior(bool useLegacyBackgroundSizeShorthandBehavior)
{
    m_page->settings()->setUseLegacyBackgroundSizeShorthandBehavior(useLegacyBackgroundSizeShorthandBehavior);
}

void InternalSettingsGenerated::setUseThreadedHTMLParserForDataURLs(bool useThreadedHTMLParserForDataURLs)
{
    m_page->settings()->setUseThreadedHTMLParserForDataURLs(useThreadedHTMLParserForDataURLs);
}

void InternalSettingsGenerated::setUsesEncodingDetector(bool usesEncodingDetector)
{
    m_page->settings()->setUsesEncodingDetector(usesEncodingDetector);
}

void InternalSettingsGenerated::setValidationMessageTimerMagnification(int validationMessageTimerMagnification)
{
    m_page->settings()->setValidationMessageTimerMagnification(validationMessageTimerMagnification);
}

void InternalSettingsGenerated::setViewportMetaMergeQuirk(bool viewportMetaMergeQuirk)
{
    m_page->settings()->setViewportMetaMergeQuirk(viewportMetaMergeQuirk);
}

void InternalSettingsGenerated::setViewportMetaZeroValuesQuirk(bool viewportMetaZeroValuesQuirk)
{
    m_page->settings()->setViewportMetaZeroValuesQuirk(viewportMetaZeroValuesQuirk);
}

void InternalSettingsGenerated::setVisualWordMovementEnabled(bool visualWordMovementEnabled)
{
    m_page->settings()->setVisualWordMovementEnabled(visualWordMovementEnabled);
}

void InternalSettingsGenerated::setWebAudioEnabled(bool webAudioEnabled)
{
    m_page->settings()->setWebAudioEnabled(webAudioEnabled);
}

void InternalSettingsGenerated::setWebGLEnabled(bool webGLEnabled)
{
    m_page->settings()->setWebGLEnabled(webGLEnabled);
}

void InternalSettingsGenerated::setWebGLErrorsToConsoleEnabled(bool webGLErrorsToConsoleEnabled)
{
    m_page->settings()->setWebGLErrorsToConsoleEnabled(webGLErrorsToConsoleEnabled);
}

void InternalSettingsGenerated::setWebSecurityEnabled(bool webSecurityEnabled)
{
    m_page->settings()->setWebSecurityEnabled(webSecurityEnabled);
}

void InternalSettingsGenerated::setWideViewportQuirkEnabled(bool wideViewportQuirkEnabled)
{
    m_page->settings()->setWideViewportQuirkEnabled(wideViewportQuirkEnabled);
}

void InternalSettingsGenerated::setXSSAuditorEnabled(bool xssAuditorEnabled)
{
    m_page->settings()->setXSSAuditorEnabled(xssAuditorEnabled);
}

} // namespace WebCore

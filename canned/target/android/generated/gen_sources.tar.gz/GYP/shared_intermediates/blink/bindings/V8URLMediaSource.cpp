/*
    This file is generated just to tell build scripts that V8URLMediaSource.h and
    V8URLMediaSource.cpp are created for URLMediaSource.idl, and thus
    prevent the build scripts from trying to generate V8URLMediaSource.h and
    V8URLMediaSource.cpp at every build. This file must not be tried to compile.
*/

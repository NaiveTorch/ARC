/*
 * Copyright (C) 2013 Google Inc. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 *
 *     * Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following disclaimer
 * in the documentation and/or other materials provided with the
 * distribution.
 *     * Neither the name of Google Inc. nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */


#ifndef EventHeaders_h
#define EventHeaders_h

#include "core/dom/KeyboardEvent.h"
#include "V8KeyboardEvent.h"
#include "core/svg/SVGZoomEvent.h"
#include "V8SVGZoomEvent.h"
#if ENABLE(INPUT_SPEECH)
#include "core/page/SpeechInputEvent.h"
#include "V8SpeechInputEvent.h"
#endif
#include "modules/speech/SpeechRecognitionEvent.h"
#include "V8SpeechRecognitionEvent.h"
#include "modules/mediastream/RTCDTMFToneChangeEvent.h"
#include "V8RTCDTMFToneChangeEvent.h"
#include "core/dom/PageTransitionEvent.h"
#include "V8PageTransitionEvent.h"
#include "core/dom/UIEvent.h"
#include "V8UIEvent.h"
#include "modules/speech/SpeechSynthesisEvent.h"
#include "V8SpeechSynthesisEvent.h"
#include "core/dom/AnimationEvent.h"
#include "V8WebKitAnimationEvent.h"
#include "core/html/canvas/WebGLContextEvent.h"
#include "V8WebGLContextEvent.h"
#include "core/dom/ProgressEvent.h"
#include "V8ProgressEvent.h"
#include "core/dom/CustomEvent.h"
#include "V8CustomEvent.h"
#include "modules/device_orientation/DeviceOrientationEvent.h"
#include "V8DeviceOrientationEvent.h"
#include "modules/mediastream/RTCIceCandidateEvent.h"
#include "V8RTCIceCandidateEvent.h"
#include "core/dom/OverflowEvent.h"
#include "V8OverflowEvent.h"
#include "core/dom/TransitionEvent.h"
#include "V8TransitionEvent.h"
#include "core/html/MediaKeyEvent.h"
#include "V8MediaKeyEvent.h"
#include "core/dom/MouseEvent.h"
#include "V8MouseEvent.h"
#include "modules/speech/SpeechRecognitionError.h"
#include "V8SpeechRecognitionError.h"
#include "core/html/track/TrackEvent.h"
#include "V8TrackEvent.h"
#include "modules/mediastream/MediaStreamTrackEvent.h"
#include "V8MediaStreamTrackEvent.h"
#include "core/dom/TouchEvent.h"
#include "V8TouchEvent.h"
#include "core/storage/StorageEvent.h"
#include "V8StorageEvent.h"
#include "modules/device_orientation/DeviceMotionEvent.h"
#include "V8DeviceMotionEvent.h"
#include "core/dom/MutationEvent.h"
#include "V8MutationEvent.h"
#include "core/dom/ErrorEvent.h"
#include "V8ErrorEvent.h"
#if ENABLE(ENCRYPTED_MEDIA_V2)
#include "modules/encryptedmedia/MediaKeyNeededEvent.h"
#include "V8MediaKeyNeededEvent.h"
#endif
#include "core/xml/XMLHttpRequestProgressEvent.h"
#include "V8XMLHttpRequestProgressEvent.h"
#if ENABLE(WEB_AUDIO)
#include "modules/webaudio/OfflineAudioCompletionEvent.h"
#include "V8OfflineAudioCompletionEvent.h"
#endif
#include "modules/mediastream/MediaStreamEvent.h"
#include "V8MediaStreamEvent.h"
#include "core/dom/SecurityPolicyViolationEvent.h"
#include "V8SecurityPolicyViolationEvent.h"
#include "modules/websockets/CloseEvent.h"
#include "V8CloseEvent.h"
#include "core/dom/ResourceProgressEvent.h"
#include "V8ResourceProgressEvent.h"
#include "core/dom/MessageEvent.h"
#include "V8MessageEvent.h"
#include "core/dom/PopStateEvent.h"
#include "V8PopStateEvent.h"
#include "core/css/CSSFontFaceLoadEvent.h"
#include "V8CSSFontFaceLoadEvent.h"
#include "modules/mediastream/RTCDataChannelEvent.h"
#include "V8RTCDataChannelEvent.h"
#include "modules/webmidi/MIDIConnectionEvent.h"
#include "V8MIDIConnectionEvent.h"
#if ENABLE(ENCRYPTED_MEDIA_V2)
#include "modules/encryptedmedia/MediaKeyMessageEvent.h"
#include "V8MediaKeyMessageEvent.h"
#endif
#include "modules/indexeddb/IDBVersionChangeEvent.h"
#include "V8IDBVersionChangeEvent.h"
#include "core/dom/FocusEvent.h"
#include "V8FocusEvent.h"
#include "core/dom/AutocompleteErrorEvent.h"
#include "V8AutocompleteErrorEvent.h"
#include "core/dom/TextEvent.h"
#include "V8TextEvent.h"
#if ENABLE(WEB_AUDIO)
#include "modules/webaudio/AudioProcessingEvent.h"
#include "V8AudioProcessingEvent.h"
#endif
#include "core/dom/WheelEvent.h"
#include "V8WheelEvent.h"
#include "modules/webmidi/MIDIMessageEvent.h"
#include "V8MIDIMessageEvent.h"
#include "core/dom/CompositionEvent.h"
#include "V8CompositionEvent.h"
#include "core/dom/BeforeLoadEvent.h"
#include "V8BeforeLoadEvent.h"
#include "core/dom/Event.h"
#include "V8Event.h"
#include "core/dom/HashChangeEvent.h"
#include "V8HashChangeEvent.h"

#endif // EventHeaders_h

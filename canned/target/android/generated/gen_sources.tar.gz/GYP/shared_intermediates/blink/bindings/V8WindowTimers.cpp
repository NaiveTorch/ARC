/*
    This file is generated just to tell build scripts that V8WindowTimers.h and
    V8WindowTimers.cpp are created for WindowTimers.idl, and thus
    prevent the build scripts from trying to generate V8WindowTimers.h and
    V8WindowTimers.cpp at every build. This file must not be tried to compile.
*/

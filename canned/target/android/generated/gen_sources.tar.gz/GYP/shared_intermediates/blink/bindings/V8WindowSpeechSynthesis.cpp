/*
    This file is generated just to tell build scripts that V8WindowSpeechSynthesis.h and
    V8WindowSpeechSynthesis.cpp are created for WindowSpeechSynthesis.idl, and thus
    prevent the build scripts from trying to generate V8WindowSpeechSynthesis.h and
    V8WindowSpeechSynthesis.cpp at every build. This file must not be tried to compile.
*/

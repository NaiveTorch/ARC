#ifndef CSSGrammarH
#define CSSGrammarH
/* A Bison parser, made by GNU Bison 2.5.  */

/* Bison interface for Yacc-like parsers in C
   
      Copyright (C) 1984, 1989-1990, 2000-2011 Free Software Foundation, Inc.
   
   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.
   
   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */


/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     TOKEN_EOF = 0,
     LOWEST_PREC = 258,
     UNIMPORTANT_TOK = 259,
     WHITESPACE = 260,
     SGML_CD = 261,
     INCLUDES = 262,
     DASHMATCH = 263,
     BEGINSWITH = 264,
     ENDSWITH = 265,
     CONTAINS = 266,
     STRING = 267,
     IDENT = 268,
     NTH = 269,
     HEX = 270,
     IDSEL = 271,
     IMPORT_SYM = 272,
     PAGE_SYM = 273,
     MEDIA_SYM = 274,
     SUPPORTS_SYM = 275,
     FONT_FACE_SYM = 276,
     HOST_SYM = 277,
     CHARSET_SYM = 278,
     NAMESPACE_SYM = 279,
     VIEWPORT_RULE_SYM = 280,
     INTERNAL_DECLS_SYM = 281,
     INTERNAL_MEDIALIST_SYM = 282,
     INTERNAL_RULE_SYM = 283,
     INTERNAL_SELECTOR_SYM = 284,
     INTERNAL_VALUE_SYM = 285,
     INTERNAL_KEYFRAME_RULE_SYM = 286,
     INTERNAL_SUPPORTS_CONDITION_SYM = 287,
     WEBKIT_KEYFRAMES_SYM = 288,
     WEBKIT_REGION_RULE_SYM = 289,
     WEBKIT_FILTER_RULE_SYM = 290,
     TOPLEFTCORNER_SYM = 291,
     TOPLEFT_SYM = 292,
     TOPCENTER_SYM = 293,
     TOPRIGHT_SYM = 294,
     TOPRIGHTCORNER_SYM = 295,
     BOTTOMLEFTCORNER_SYM = 296,
     BOTTOMLEFT_SYM = 297,
     BOTTOMCENTER_SYM = 298,
     BOTTOMRIGHT_SYM = 299,
     BOTTOMRIGHTCORNER_SYM = 300,
     LEFTTOP_SYM = 301,
     LEFTMIDDLE_SYM = 302,
     LEFTBOTTOM_SYM = 303,
     RIGHTTOP_SYM = 304,
     RIGHTMIDDLE_SYM = 305,
     RIGHTBOTTOM_SYM = 306,
     ATKEYWORD = 307,
     IMPORTANT_SYM = 308,
     MEDIA_ONLY = 309,
     MEDIA_NOT = 310,
     MEDIA_AND = 311,
     SUPPORTS_NOT = 312,
     SUPPORTS_AND = 313,
     SUPPORTS_OR = 314,
     REMS = 315,
     CHS = 316,
     QEMS = 317,
     EMS = 318,
     EXS = 319,
     PXS = 320,
     CMS = 321,
     MMS = 322,
     INS = 323,
     PTS = 324,
     PCS = 325,
     DEGS = 326,
     RADS = 327,
     GRADS = 328,
     TURNS = 329,
     MSECS = 330,
     SECS = 331,
     HERTZ = 332,
     KHERTZ = 333,
     DIMEN = 334,
     INVALIDDIMEN = 335,
     PERCENTAGE = 336,
     FLOATTOKEN = 337,
     INTEGER = 338,
     VW = 339,
     VH = 340,
     VMIN = 341,
     VMAX = 342,
     DPPX = 343,
     DPI = 344,
     DPCM = 345,
     FR = 346,
     URI = 347,
     FUNCTION = 348,
     ANYFUNCTION = 349,
     CUEFUNCTION = 350,
     NOTFUNCTION = 351,
     DISTRIBUTEDFUNCTION = 352,
     CALCFUNCTION = 353,
     MINFUNCTION = 354,
     MAXFUNCTION = 355,
     VARFUNCTION = 356,
     VAR_DEFINITION = 357,
     PARTFUNCTION = 358,
     HOSTFUNCTION = 359,
     UNICODERANGE = 360
   };
#endif



#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
{

/* Line 2068 of yacc.c  */
#line 89 "/ssd2/android_4.4_r1/out/target/product/generic_x86/obj/GYP/shared_intermediates/blink/CSSGrammar.y"

    bool boolean;
    char character;
    int integer;
    double number;
    CSSParserString string;

    StyleRuleBase* rule;
    Vector<RefPtr<StyleRuleBase> >* ruleList;
    CSSParserSelector* selector;
    Vector<OwnPtr<CSSParserSelector> >* selectorList;
    CSSSelector::MarginBoxType marginBox;
    CSSSelector::Relation relation;
    MediaQuerySet* mediaList;
    MediaQuery* mediaQuery;
    MediaQuery::Restrictor mediaQueryRestrictor;
    MediaQueryExp* mediaQueryExp;
    CSSParserValue value;
    CSSParserValueList* valueList;
    Vector<OwnPtr<MediaQueryExp> >* mediaQueryExpList;
    StyleKeyframe* keyframe;
    Vector<RefPtr<StyleKeyframe> >* keyframeRuleList;
    float val;
    CSSPropertyID id;
    CSSParserLocation location;



/* Line 2068 of yacc.c  */
#line 185 "/ssd2/android_4.4_r1/out/target/product/generic_x86/obj/GYP/shared_intermediates/blink/CSSGrammar.hpp"
} YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
#endif





#endif

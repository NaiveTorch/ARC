// Code generated from InspectorInstrumentation.idl

#ifndef InspectorDatabaseInstrumentationInl_h
#define InspectorDatabaseInstrumentationInl_h

#include "core/inspector/InspectorInstrumentation.h"
#include "modules/webdatabase/Database.h"

namespace WebCore {

namespace InspectorInstrumentation {

void didOpenDatabaseImpl(InstrumentingAgents*, PassRefPtr<Database>, const String&, const String&, const String&);

inline void didOpenDatabase(ScriptExecutionContext* context, PassRefPtr<Database> database, const String& domain, const String& name, const String& version)
{   
    if (InstrumentingAgents* agents = instrumentingAgentsForScriptExecutionContext(context))
        didOpenDatabaseImpl(agents, database, domain, name, version);
}

} // namespace InspectorInstrumentation

} // namespace WebCore

#endif // !defined(InspectorDatabaseInstrumentationInl_h)

// Code generated from InspectorInstrumentation.idl

#ifndef InspectorOverridesInl_h
#define InspectorOverridesInl_h

#include "core/inspector/InspectorInstrumentation.h"

namespace WebCore {

namespace InspectorInstrumentation {

bool forcePseudoStateImpl(InstrumentingAgents*, Element*, CSSSelector::PseudoType);

inline bool forcePseudoState(Element* element, CSSSelector::PseudoType pseudoState)
{   
    FAST_RETURN_IF_NO_FRONTENDS(false);
    if (InstrumentingAgents* agents = instrumentingAgentsForElement(element))
        return forcePseudoStateImpl(agents, element, pseudoState);
    return false;
}

bool shouldApplyScreenWidthOverrideImpl(InstrumentingAgents*);

inline bool shouldApplyScreenWidthOverride(Frame* frame)
{   
    FAST_RETURN_IF_NO_FRONTENDS(false);
    if (InstrumentingAgents* agents = instrumentingAgentsForFrame(frame))
        return shouldApplyScreenWidthOverrideImpl(agents);
    return false;
}

bool shouldApplyScreenHeightOverrideImpl(InstrumentingAgents*);

inline bool shouldApplyScreenHeightOverride(Frame* frame)
{   
    FAST_RETURN_IF_NO_FRONTENDS(false);
    if (InstrumentingAgents* agents = instrumentingAgentsForFrame(frame))
        return shouldApplyScreenHeightOverrideImpl(agents);
    return false;
}

bool shouldPauseDedicatedWorkerOnStartImpl(InstrumentingAgents*);

inline bool shouldPauseDedicatedWorkerOnStart(ScriptExecutionContext* context)
{   
    FAST_RETURN_IF_NO_FRONTENDS(false);
    if (InstrumentingAgents* agents = instrumentingAgentsForScriptExecutionContext(context))
        return shouldPauseDedicatedWorkerOnStartImpl(agents);
    return false;
}

GeolocationPosition* overrideGeolocationPositionImpl(InstrumentingAgents*, GeolocationPosition*);

inline GeolocationPosition* overrideGeolocationPosition(Page* page, GeolocationPosition* position)
{   
    FAST_RETURN_IF_NO_FRONTENDS(position);
    if (InstrumentingAgents* agents = instrumentingAgentsForPage(page))
        return overrideGeolocationPositionImpl(agents, position);
    return position;
}

DeviceOrientationData* overrideDeviceOrientationImpl(InstrumentingAgents*, DeviceOrientationData*);

inline DeviceOrientationData* overrideDeviceOrientation(Page* page, DeviceOrientationData* deviceOrientation)
{   
    FAST_RETURN_IF_NO_FRONTENDS(deviceOrientation);
    if (InstrumentingAgents* agents = instrumentingAgentsForPage(page))
        return overrideDeviceOrientationImpl(agents, deviceOrientation);
    return deviceOrientation;
}

String getCurrentUserInitiatedProfileNameImpl(InstrumentingAgents*, bool);

inline String getCurrentUserInitiatedProfileName(Page* page, bool incrementProfileNumber)
{   
    if (InstrumentingAgents* agents = instrumentingAgentsForPage(page))
        return getCurrentUserInitiatedProfileNameImpl(agents, incrementProfileNumber);
    return "";
}

} // namespace InspectorInstrumentation

} // namespace WebCore

#endif // !defined(InspectorOverridesInl_h)

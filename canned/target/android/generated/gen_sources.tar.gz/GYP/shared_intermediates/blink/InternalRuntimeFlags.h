/*
 * Copyright (C) 2013 Google Inc. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 *
 *     * Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following disclaimer
 * in the documentation and/or other materials provided with the
 * distribution.
 *     * Neither the name of Google Inc. nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef InternalRuntimeFlags_h
#define InternalRuntimeFlags_h

#include "RuntimeEnabledFeatures.h"
#include "wtf/PassRefPtr.h"
#include "wtf/RefPtr.h"
#include "wtf/RefCounted.h"

namespace WebCore {

class InternalRuntimeFlags : public RefCounted<InternalRuntimeFlags> {
public:
    static PassRefPtr<InternalRuntimeFlags> create()
    {
        return adoptRef(new InternalRuntimeFlags);
    }

    bool animatedWebPEnabled() { return RuntimeEnabledFeatures::animatedWebPEnabled(); }

    bool applicationCacheEnabled() { return RuntimeEnabledFeatures::applicationCacheEnabled(); }

    bool authorShadowDOMForAnyElementEnabled() { return RuntimeEnabledFeatures::authorShadowDOMForAnyElementEnabled(); }

    bool cryptoEnabled() { return RuntimeEnabledFeatures::cryptoEnabled(); }

    bool cssCompositingEnabled() { return RuntimeEnabledFeatures::cssCompositingEnabled(); }

    bool cssExclusionsEnabled() { return RuntimeEnabledFeatures::cssExclusionsEnabled(); }

    bool cssGridLayoutEnabled() { return RuntimeEnabledFeatures::cssGridLayoutEnabled(); }

    bool cssRegionsEnabled() { return RuntimeEnabledFeatures::cssRegionsEnabled(); }

    bool cssTouchActionEnabled() { return RuntimeEnabledFeatures::cssTouchActionEnabled(); }

    bool cssVariablesEnabled() { return RuntimeEnabledFeatures::cssVariablesEnabled(); }

    bool css3TextEnabled() { return RuntimeEnabledFeatures::css3TextEnabled(); }

    bool css3TextDecorationsEnabled() { return RuntimeEnabledFeatures::css3TextDecorationsEnabled(); }

    bool customDOMElementsEnabled() { return RuntimeEnabledFeatures::customDOMElementsEnabled(); }

    bool databaseEnabled() { return RuntimeEnabledFeatures::databaseEnabled(); }

    bool dataListElementEnabled() { return RuntimeEnabledFeatures::dataListElementEnabled(); }

    bool deviceMotionEnabled() { return RuntimeEnabledFeatures::deviceMotionEnabled(); }

    bool deviceOrientationEnabled() { return RuntimeEnabledFeatures::deviceOrientationEnabled(); }

    bool dialogElementEnabled() { return RuntimeEnabledFeatures::dialogElementEnabled(); }

    bool directoryUploadEnabled() { return RuntimeEnabledFeatures::directoryUploadEnabled(); }

    bool embedderCustomElementsEnabled() { return RuntimeEnabledFeatures::embedderCustomElementsEnabled(); }

    bool encodingAPIEnabled() { return RuntimeEnabledFeatures::encodingAPIEnabled(); }

    bool encryptedMediaEnabled() { return RuntimeEnabledFeatures::encryptedMediaEnabled(); }

    bool encryptedMediaAnyVersionEnabled() { return RuntimeEnabledFeatures::encryptedMediaAnyVersionEnabled(); }

    bool experimentalCanvasFeaturesEnabled() { return RuntimeEnabledFeatures::experimentalCanvasFeaturesEnabled(); }

    bool experimentalContentSecurityPolicyFeaturesEnabled() { return RuntimeEnabledFeatures::experimentalContentSecurityPolicyFeaturesEnabled(); }

    bool fileSystemEnabled() { return RuntimeEnabledFeatures::fileSystemEnabled(); }

    bool fontLoadEventsEnabled() { return RuntimeEnabledFeatures::fontLoadEventsEnabled(); }

    bool fullscreenEnabled() { return RuntimeEnabledFeatures::fullscreenEnabled(); }

    bool cssViewportEnabled() { return RuntimeEnabledFeatures::cssViewportEnabled(); }

    bool gamepadEnabled() { return RuntimeEnabledFeatures::gamepadEnabled(); }

    bool geolocationEnabled() { return RuntimeEnabledFeatures::geolocationEnabled(); }

    bool htmlImportsEnabled() { return RuntimeEnabledFeatures::htmlImportsEnabled(); }

    bool highResolutionTimeInWorkersEnabled() { return RuntimeEnabledFeatures::highResolutionTimeInWorkersEnabled(); }

    bool imeAPIEnabled() { return RuntimeEnabledFeatures::imeAPIEnabled(); }

    bool indexedDBEnabled() { return RuntimeEnabledFeatures::indexedDBEnabled(); }

    bool inputModeAttributeEnabled() { return RuntimeEnabledFeatures::inputModeAttributeEnabled(); }

    bool inputTypeColorEnabled() { return RuntimeEnabledFeatures::inputTypeColorEnabled(); }

    bool inputTypeWeekEnabled() { return RuntimeEnabledFeatures::inputTypeWeekEnabled(); }

    bool langAttributeAwareFormControlUIEnabled() { return RuntimeEnabledFeatures::langAttributeAwareFormControlUIEnabled(); }

    bool lazyLayoutEnabled() { return RuntimeEnabledFeatures::lazyLayoutEnabled(); }

    bool legacyEncryptedMediaEnabled() { return RuntimeEnabledFeatures::legacyEncryptedMediaEnabled(); }

    bool localStorageEnabled() { return RuntimeEnabledFeatures::localStorageEnabled(); }

    bool mediaEnabled() { return RuntimeEnabledFeatures::mediaEnabled(); }

    bool mediaSourceEnabled() { return RuntimeEnabledFeatures::mediaSourceEnabled(); }

    bool mediaStreamEnabled() { return RuntimeEnabledFeatures::mediaStreamEnabled(); }

    bool notificationsEnabled() { return RuntimeEnabledFeatures::notificationsEnabled(); }

    bool pagePopupEnabled() { return RuntimeEnabledFeatures::pagePopupEnabled(); }

    bool parseSVGAsHTMLEnabled() { return RuntimeEnabledFeatures::parseSVGAsHTMLEnabled(); }

    bool pathOpsSVGClippingEnabled() { return RuntimeEnabledFeatures::pathOpsSVGClippingEnabled(); }

    bool peerConnectionEnabled() { return RuntimeEnabledFeatures::peerConnectionEnabled(); }

    bool programmaticScrollNotificationsEnabled() { return RuntimeEnabledFeatures::programmaticScrollNotificationsEnabled(); }

    bool promiseEnabled() { return RuntimeEnabledFeatures::promiseEnabled(); }

    bool quotaEnabled() { return RuntimeEnabledFeatures::quotaEnabled(); }

    bool overlayScrollbarsEnabled() { return RuntimeEnabledFeatures::overlayScrollbarsEnabled(); }

    bool requestAutocompleteEnabled() { return RuntimeEnabledFeatures::requestAutocompleteEnabled(); }

    bool rowSpanLogicalHeightSpreadingEnabled() { return RuntimeEnabledFeatures::rowSpanLogicalHeightSpreadingEnabled(); }

    bool scriptedSpeechEnabled() { return RuntimeEnabledFeatures::scriptedSpeechEnabled(); }

    bool seamlessIFramesEnabled() { return RuntimeEnabledFeatures::seamlessIFramesEnabled(); }

    bool sessionStorageEnabled() { return RuntimeEnabledFeatures::sessionStorageEnabled(); }

    bool shadowDOMEnabled() { return RuntimeEnabledFeatures::shadowDOMEnabled(); }

    bool speechInputEnabled() { return RuntimeEnabledFeatures::speechInputEnabled(); }

    bool speechSynthesisEnabled() { return RuntimeEnabledFeatures::speechSynthesisEnabled(); }

    bool streamEnabled() { return RuntimeEnabledFeatures::streamEnabled(); }

    bool styleScopedEnabled() { return RuntimeEnabledFeatures::styleScopedEnabled(); }

    bool touchEnabled() { return RuntimeEnabledFeatures::touchEnabled(); }

    bool userSelectAllEnabled() { return RuntimeEnabledFeatures::userSelectAllEnabled(); }

    bool vibrationEnabled() { return RuntimeEnabledFeatures::vibrationEnabled(); }

    bool videoTrackEnabled() { return RuntimeEnabledFeatures::videoTrackEnabled(); }

    bool webAnimationsEnabled() { return RuntimeEnabledFeatures::webAnimationsEnabled(); }

    bool webAnimationsCSSEnabled() { return RuntimeEnabledFeatures::webAnimationsCSSEnabled(); }

    bool webAnimationsSVGEnabled() { return RuntimeEnabledFeatures::webAnimationsSVGEnabled(); }

#if ENABLE(WEB_AUDIO)
    bool webAudioEnabled() { return RuntimeEnabledFeatures::webAudioEnabled(); }
#endif

    bool webGLDraftExtensionsEnabled() { return RuntimeEnabledFeatures::webGLDraftExtensionsEnabled(); }

    bool webMIDIEnabled() { return RuntimeEnabledFeatures::webMIDIEnabled(); }

    bool webKitMediaSourceEnabled() { return RuntimeEnabledFeatures::webKitMediaSourceEnabled(); }

    bool woff2Enabled() { return RuntimeEnabledFeatures::woff2Enabled(); }


private:
    InternalRuntimeFlags() { }
};

} // namespace WebCore

#endif // InternalRuntimeFlags_h

// Code generated from InspectorInstrumentation.idl

#ifndef InspectorInstrumentationInl_h
#define InspectorInstrumentationInl_h

#include "core/inspector/InspectorInstrumentation.h"

namespace WebCore {

namespace InspectorInstrumentation {

void didClearWindowObjectInWorldImpl(InstrumentingAgents*, Frame*, DOMWrapperWorld*);

inline void didClearWindowObjectInWorld(Frame* paramFrame, DOMWrapperWorld* paramDOMWrapperWorld)
{   
    if (InstrumentingAgents* agents = instrumentingAgentsForFrame(paramFrame))
        didClearWindowObjectInWorldImpl(agents, paramFrame, paramDOMWrapperWorld);
}

void willInsertDOMNodeImpl(InstrumentingAgents*, Node*);

inline void willInsertDOMNode(Document* paramDocument, Node* parent)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (InstrumentingAgents* agents = instrumentingAgentsForDocument(paramDocument))
        willInsertDOMNodeImpl(agents, parent);
}

void didInsertDOMNodeImpl(InstrumentingAgents*, Node*);

inline void didInsertDOMNode(Document* paramDocument, Node* paramNode)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (InstrumentingAgents* agents = instrumentingAgentsForDocument(paramDocument))
        didInsertDOMNodeImpl(agents, paramNode);
}

void willRemoveDOMNodeImpl(InstrumentingAgents*, Node*);

inline void willRemoveDOMNode(Document* document, Node* paramNode)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (InstrumentingAgents* agents = instrumentingAgentsForDocument(document))
        willRemoveDOMNodeImpl(agents, paramNode);
}

void willModifyDOMAttrImpl(InstrumentingAgents*, Element*, const AtomicString&, const AtomicString&);

inline void willModifyDOMAttr(Document* paramDocument, Element* paramElement, const AtomicString& oldValue, const AtomicString& newValue)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (InstrumentingAgents* agents = instrumentingAgentsForDocument(paramDocument))
        willModifyDOMAttrImpl(agents, paramElement, oldValue, newValue);
}

void didModifyDOMAttrImpl(InstrumentingAgents*, Element*, const AtomicString&, const AtomicString&);

inline void didModifyDOMAttr(Document* paramDocument, Element* paramElement, const AtomicString& name, const AtomicString& value)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (InstrumentingAgents* agents = instrumentingAgentsForDocument(paramDocument))
        didModifyDOMAttrImpl(agents, paramElement, name, value);
}

void didRemoveDOMAttrImpl(InstrumentingAgents*, Element*, const AtomicString&);

inline void didRemoveDOMAttr(Document* paramDocument, Element* paramElement, const AtomicString& name)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (InstrumentingAgents* agents = instrumentingAgentsForDocument(paramDocument))
        didRemoveDOMAttrImpl(agents, paramElement, name);
}

void characterDataModifiedImpl(InstrumentingAgents*, CharacterData*);

inline void characterDataModified(Document* paramDocument, CharacterData* paramCharacterData)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (InstrumentingAgents* agents = instrumentingAgentsForDocument(paramDocument))
        characterDataModifiedImpl(agents, paramCharacterData);
}

void didInvalidateStyleAttrImpl(InstrumentingAgents*, Node*);

inline void didInvalidateStyleAttr(Document* paramDocument, Node* paramNode)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (InstrumentingAgents* agents = instrumentingAgentsForDocument(paramDocument))
        didInvalidateStyleAttrImpl(agents, paramNode);
}

void activeStyleSheetsUpdatedImpl(InstrumentingAgents*, Document*, const Vector<RefPtr<StyleSheet> >&);

inline void activeStyleSheetsUpdated(Document* paramDocument, const Vector<RefPtr<StyleSheet> >& newSheets)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (InstrumentingAgents* agents = instrumentingAgentsForDocument(paramDocument))
        activeStyleSheetsUpdatedImpl(agents, paramDocument, newSheets);
}

void frameWindowDiscardedImpl(InstrumentingAgents*, DOMWindow*);

inline void frameWindowDiscarded(Frame* paramFrame, DOMWindow* domWindow)
{   
    if (InstrumentingAgents* agents = instrumentingAgentsForFrame(paramFrame))
        frameWindowDiscardedImpl(agents, domWindow);
}

void mediaQueryResultChangedImpl(InstrumentingAgents*);

inline void mediaQueryResultChanged(Document* paramDocument)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (InstrumentingAgents* agents = instrumentingAgentsForDocument(paramDocument))
        mediaQueryResultChangedImpl(agents);
}

void didPushShadowRootImpl(InstrumentingAgents*, Element*, ShadowRoot*);

inline void didPushShadowRoot(Element* host, ShadowRoot* paramShadowRoot)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (InstrumentingAgents* agents = instrumentingAgentsForElement(host))
        didPushShadowRootImpl(agents, host, paramShadowRoot);
}

void willPopShadowRootImpl(InstrumentingAgents*, Element*, ShadowRoot*);

inline void willPopShadowRoot(Element* host, ShadowRoot* paramShadowRoot)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (InstrumentingAgents* agents = instrumentingAgentsForElement(host))
        willPopShadowRootImpl(agents, host, paramShadowRoot);
}

void didCreateNamedFlowImpl(InstrumentingAgents*, Document*, NamedFlow*);

inline void didCreateNamedFlow(Document* paramDocument, NamedFlow* paramNamedFlow)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (InstrumentingAgents* agents = instrumentingAgentsForDocument(paramDocument))
        didCreateNamedFlowImpl(agents, paramDocument, paramNamedFlow);
}

void willRemoveNamedFlowImpl(InstrumentingAgents*, Document*, NamedFlow*);

inline void willRemoveNamedFlow(Document* paramDocument, NamedFlow* paramNamedFlow)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (InstrumentingAgents* agents = instrumentingAgentsForDocument(paramDocument))
        willRemoveNamedFlowImpl(agents, paramDocument, paramNamedFlow);
}

void didUpdateRegionLayoutImpl(InstrumentingAgents*, Document*, NamedFlow*);

inline void didUpdateRegionLayout(Document* paramDocument, NamedFlow* paramNamedFlow)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (InstrumentingAgents* agents = instrumentingAgentsForDocument(paramDocument))
        didUpdateRegionLayoutImpl(agents, paramDocument, paramNamedFlow);
}

void didChangeRegionOversetImpl(InstrumentingAgents*, Document*, NamedFlow*);

inline void didChangeRegionOverset(Document* paramDocument, NamedFlow* paramNamedFlow)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (InstrumentingAgents* agents = instrumentingAgentsForDocument(paramDocument))
        didChangeRegionOversetImpl(agents, paramDocument, paramNamedFlow);
}

void willSendXMLHttpRequestImpl(InstrumentingAgents*, const String&);

inline void willSendXMLHttpRequest(ScriptExecutionContext* paramScriptExecutionContext, const String& url)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (InstrumentingAgents* agents = instrumentingAgentsForScriptExecutionContext(paramScriptExecutionContext))
        willSendXMLHttpRequestImpl(agents, url);
}

void didFireWebGLErrorImpl(InstrumentingAgents*, const String&);

inline void didFireWebGLError(Element* paramElement, const String& errorName)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (InstrumentingAgents* agents = instrumentingAgentsForElement(paramElement))
        didFireWebGLErrorImpl(agents, errorName);
}

void didFireWebGLWarningImpl(InstrumentingAgents*);

inline void didFireWebGLWarning(Element* paramElement)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (InstrumentingAgents* agents = instrumentingAgentsForElement(paramElement))
        didFireWebGLWarningImpl(agents);
}

void didFireWebGLErrorOrWarningImpl(InstrumentingAgents*, const String&);

inline void didFireWebGLErrorOrWarning(Element* paramElement, const String& message)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (InstrumentingAgents* agents = instrumentingAgentsForElement(paramElement))
        didFireWebGLErrorOrWarningImpl(agents, message);
}

void didScheduleResourceRequestImpl(InstrumentingAgents*, Document*, const String&);

inline void didScheduleResourceRequest(Document* paramDocument, const String& url)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (InstrumentingAgents* agents = instrumentingAgentsForDocument(paramDocument))
        didScheduleResourceRequestImpl(agents, paramDocument, url);
}

void didInstallTimerImpl(InstrumentingAgents*, ScriptExecutionContext*, int, int, bool);

inline void didInstallTimer(ScriptExecutionContext* paramScriptExecutionContext, int timerId, int timeout, bool singleShot)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (InstrumentingAgents* agents = instrumentingAgentsForScriptExecutionContext(paramScriptExecutionContext))
        didInstallTimerImpl(agents, paramScriptExecutionContext, timerId, timeout, singleShot);
}

void didRemoveTimerImpl(InstrumentingAgents*, ScriptExecutionContext*, int);

inline void didRemoveTimer(ScriptExecutionContext* paramScriptExecutionContext, int timerId)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (InstrumentingAgents* agents = instrumentingAgentsForScriptExecutionContext(paramScriptExecutionContext))
        didRemoveTimerImpl(agents, paramScriptExecutionContext, timerId);
}

InspectorInstrumentationCookie willCallFunctionImpl(InstrumentingAgents*, ScriptExecutionContext*, const String&, int);

inline InspectorInstrumentationCookie willCallFunction(ScriptExecutionContext* paramScriptExecutionContext, const String& scriptName, int scriptLine)
{   
    FAST_RETURN_IF_NO_FRONTENDS(InspectorInstrumentationCookie());
    if (InstrumentingAgents* agents = instrumentingAgentsForScriptExecutionContext(paramScriptExecutionContext))
        return willCallFunctionImpl(agents, paramScriptExecutionContext, scriptName, scriptLine);
    return InspectorInstrumentationCookie();
}

void didCallFunctionImpl(const InspectorInstrumentationCookie&);

inline void didCallFunction(const InspectorInstrumentationCookie& paramInspectorInstrumentationCookie)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (paramInspectorInstrumentationCookie.isValid())
        didCallFunctionImpl(paramInspectorInstrumentationCookie);
}

InspectorInstrumentationCookie willDispatchXHRReadyStateChangeEventImpl(InstrumentingAgents*, ScriptExecutionContext*, XMLHttpRequest*);

inline InspectorInstrumentationCookie willDispatchXHRReadyStateChangeEvent(ScriptExecutionContext* paramScriptExecutionContext, XMLHttpRequest* paramXMLHttpRequest)
{   
    FAST_RETURN_IF_NO_FRONTENDS(InspectorInstrumentationCookie());
    if (InstrumentingAgents* agents = instrumentingAgentsForScriptExecutionContext(paramScriptExecutionContext))
        return willDispatchXHRReadyStateChangeEventImpl(agents, paramScriptExecutionContext, paramXMLHttpRequest);
    return InspectorInstrumentationCookie();
}

void didDispatchXHRReadyStateChangeEventImpl(const InspectorInstrumentationCookie&);

inline void didDispatchXHRReadyStateChangeEvent(const InspectorInstrumentationCookie& paramInspectorInstrumentationCookie)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (paramInspectorInstrumentationCookie.isValid())
        didDispatchXHRReadyStateChangeEventImpl(paramInspectorInstrumentationCookie);
}

InspectorInstrumentationCookie willDispatchEventImpl(InstrumentingAgents*, Document*, const Event&, DOMWindow*, Node*, const EventPath&);

inline InspectorInstrumentationCookie willDispatchEvent(Document* paramDocument, const Event& paramEvent, DOMWindow* paramDOMWindow, Node* paramNode, const EventPath& paramEventPath)
{   
    FAST_RETURN_IF_NO_FRONTENDS(InspectorInstrumentationCookie());
    if (InstrumentingAgents* agents = instrumentingAgentsForDocument(paramDocument))
        return willDispatchEventImpl(agents, paramDocument, paramEvent, paramDOMWindow, paramNode, paramEventPath);
    return InspectorInstrumentationCookie();
}

void didDispatchEventImpl(const InspectorInstrumentationCookie&);

inline void didDispatchEvent(const InspectorInstrumentationCookie& paramInspectorInstrumentationCookie)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (paramInspectorInstrumentationCookie.isValid())
        didDispatchEventImpl(paramInspectorInstrumentationCookie);
}

InspectorInstrumentationCookie willHandleEventImpl(InstrumentingAgents*, Event*);

inline InspectorInstrumentationCookie willHandleEvent(ScriptExecutionContext* paramScriptExecutionContext, Event* paramEvent)
{   
    FAST_RETURN_IF_NO_FRONTENDS(InspectorInstrumentationCookie());
    if (InstrumentingAgents* agents = instrumentingAgentsForScriptExecutionContext(paramScriptExecutionContext))
        return willHandleEventImpl(agents, paramEvent);
    return InspectorInstrumentationCookie();
}

void didHandleEventImpl(const InspectorInstrumentationCookie&);

inline void didHandleEvent(const InspectorInstrumentationCookie& paramInspectorInstrumentationCookie)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (paramInspectorInstrumentationCookie.isValid())
        didHandleEventImpl(paramInspectorInstrumentationCookie);
}

InspectorInstrumentationCookie willDispatchEventOnWindowImpl(InstrumentingAgents*, const Event&, DOMWindow*);

inline InspectorInstrumentationCookie willDispatchEventOnWindow(Frame* paramFrame, const Event& paramEvent, DOMWindow* paramDOMWindow)
{   
    FAST_RETURN_IF_NO_FRONTENDS(InspectorInstrumentationCookie());
    if (InstrumentingAgents* agents = instrumentingAgentsForFrame(paramFrame))
        return willDispatchEventOnWindowImpl(agents, paramEvent, paramDOMWindow);
    return InspectorInstrumentationCookie();
}

void didDispatchEventOnWindowImpl(const InspectorInstrumentationCookie&);

inline void didDispatchEventOnWindow(const InspectorInstrumentationCookie& paramInspectorInstrumentationCookie)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (paramInspectorInstrumentationCookie.isValid())
        didDispatchEventOnWindowImpl(paramInspectorInstrumentationCookie);
}

InspectorInstrumentationCookie willEvaluateScriptImpl(InstrumentingAgents*, Frame*, const String&, int);

inline InspectorInstrumentationCookie willEvaluateScript(Frame* paramFrame, const String& url, int lineNumber)
{   
    FAST_RETURN_IF_NO_FRONTENDS(InspectorInstrumentationCookie());
    if (InstrumentingAgents* agents = instrumentingAgentsForFrame(paramFrame))
        return willEvaluateScriptImpl(agents, paramFrame, url, lineNumber);
    return InspectorInstrumentationCookie();
}

void didEvaluateScriptImpl(const InspectorInstrumentationCookie&);

inline void didEvaluateScript(const InspectorInstrumentationCookie& paramInspectorInstrumentationCookie)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (paramInspectorInstrumentationCookie.isValid())
        didEvaluateScriptImpl(paramInspectorInstrumentationCookie);
}

void scriptsEnabledImpl(InstrumentingAgents*, bool);

inline void scriptsEnabled(Page* paramPage, bool isEnabled)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (InstrumentingAgents* agents = instrumentingAgentsForPage(paramPage))
        scriptsEnabledImpl(agents, isEnabled);
}

void didCreateIsolatedContextImpl(InstrumentingAgents*, Frame*, ScriptState*, SecurityOrigin*);

inline void didCreateIsolatedContext(Frame* paramFrame, ScriptState* paramScriptState, SecurityOrigin* paramSecurityOrigin)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (InstrumentingAgents* agents = instrumentingAgentsForFrame(paramFrame))
        didCreateIsolatedContextImpl(agents, paramFrame, paramScriptState, paramSecurityOrigin);
}

InspectorInstrumentationCookie willFireTimerImpl(InstrumentingAgents*, ScriptExecutionContext*, int);

inline InspectorInstrumentationCookie willFireTimer(ScriptExecutionContext* paramScriptExecutionContext, int timerId)
{   
    FAST_RETURN_IF_NO_FRONTENDS(InspectorInstrumentationCookie());
    if (InstrumentingAgents* agents = instrumentingAgentsForScriptExecutionContext(paramScriptExecutionContext))
        return willFireTimerImpl(agents, paramScriptExecutionContext, timerId);
    return InspectorInstrumentationCookie();
}

void didFireTimerImpl(const InspectorInstrumentationCookie&);

inline void didFireTimer(const InspectorInstrumentationCookie& paramInspectorInstrumentationCookie)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (paramInspectorInstrumentationCookie.isValid())
        didFireTimerImpl(paramInspectorInstrumentationCookie);
}

void didInvalidateLayoutImpl(InstrumentingAgents*, Frame*);

inline void didInvalidateLayout(Frame* paramFrame)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (InstrumentingAgents* agents = instrumentingAgentsForFrame(paramFrame))
        didInvalidateLayoutImpl(agents, paramFrame);
}

InspectorInstrumentationCookie willLayoutImpl(InstrumentingAgents*, Frame*);

inline InspectorInstrumentationCookie willLayout(Frame* paramFrame)
{   
    FAST_RETURN_IF_NO_FRONTENDS(InspectorInstrumentationCookie());
    if (InstrumentingAgents* agents = instrumentingAgentsForFrame(paramFrame))
        return willLayoutImpl(agents, paramFrame);
    return InspectorInstrumentationCookie();
}

void didLayoutImpl(const InspectorInstrumentationCookie&, RenderObject*);

inline void didLayout(const InspectorInstrumentationCookie& paramInspectorInstrumentationCookie, RenderObject* root)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (paramInspectorInstrumentationCookie.isValid())
        didLayoutImpl(paramInspectorInstrumentationCookie, root);
}

void didScrollImpl(InstrumentingAgents*);

inline void didScroll(Page* paramPage)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (InstrumentingAgents* agents = instrumentingAgentsForPage(paramPage))
        didScrollImpl(agents);
}

void didResizeMainFrameImpl(InstrumentingAgents*);

inline void didResizeMainFrame(Page* paramPage)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (InstrumentingAgents* agents = instrumentingAgentsForPage(paramPage))
        didResizeMainFrameImpl(agents);
}

InspectorInstrumentationCookie willDispatchXHRLoadEventImpl(InstrumentingAgents*, ScriptExecutionContext*, XMLHttpRequest*);

inline InspectorInstrumentationCookie willDispatchXHRLoadEvent(ScriptExecutionContext* paramScriptExecutionContext, XMLHttpRequest* paramXMLHttpRequest)
{   
    FAST_RETURN_IF_NO_FRONTENDS(InspectorInstrumentationCookie());
    if (InstrumentingAgents* agents = instrumentingAgentsForScriptExecutionContext(paramScriptExecutionContext))
        return willDispatchXHRLoadEventImpl(agents, paramScriptExecutionContext, paramXMLHttpRequest);
    return InspectorInstrumentationCookie();
}

void didDispatchXHRLoadEventImpl(const InspectorInstrumentationCookie&);

inline void didDispatchXHRLoadEvent(const InspectorInstrumentationCookie& paramInspectorInstrumentationCookie)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (paramInspectorInstrumentationCookie.isValid())
        didDispatchXHRLoadEventImpl(paramInspectorInstrumentationCookie);
}

void willScrollLayerImpl(InstrumentingAgents*, RenderObject*);

inline void willScrollLayer(RenderObject* paramRenderObject)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (InstrumentingAgents* agents = instrumentingAgentsForRenderObject(paramRenderObject))
        willScrollLayerImpl(agents, paramRenderObject);
}

void didScrollLayerImpl(InstrumentingAgents*);

inline void didScrollLayer(RenderObject* paramRenderObject)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (InstrumentingAgents* agents = instrumentingAgentsForRenderObject(paramRenderObject))
        didScrollLayerImpl(agents);
}

void willPaintImpl(InstrumentingAgents*, RenderObject*);

inline void willPaint(RenderObject* paramRenderObject)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (InstrumentingAgents* agents = instrumentingAgentsForRenderObject(paramRenderObject))
        willPaintImpl(agents, paramRenderObject);
}

void didPaintImpl(InstrumentingAgents*, RenderObject*, GraphicsContext*, const LayoutRect&);

inline void didPaint(RenderObject* paramRenderObject, GraphicsContext* paramGraphicsContext, const LayoutRect& paramLayoutRect)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (InstrumentingAgents* agents = instrumentingAgentsForRenderObject(paramRenderObject))
        didPaintImpl(agents, paramRenderObject, paramGraphicsContext, paramLayoutRect);
}

InspectorInstrumentationCookie willRecalculateStyleImpl(InstrumentingAgents*, Document*);

inline InspectorInstrumentationCookie willRecalculateStyle(Document* paramDocument)
{   
    FAST_RETURN_IF_NO_FRONTENDS(InspectorInstrumentationCookie());
    if (InstrumentingAgents* agents = instrumentingAgentsForDocument(paramDocument))
        return willRecalculateStyleImpl(agents, paramDocument);
    return InspectorInstrumentationCookie();
}

void didRecalculateStyleImpl(const InspectorInstrumentationCookie&);

inline void didRecalculateStyle(const InspectorInstrumentationCookie& paramInspectorInstrumentationCookie)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (paramInspectorInstrumentationCookie.isValid())
        didRecalculateStyleImpl(paramInspectorInstrumentationCookie);
}

void didRecalculateStyleForElementImpl(InstrumentingAgents*);

inline void didRecalculateStyleForElement(Element* paramElement)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (InstrumentingAgents* agents = instrumentingAgentsForElement(paramElement))
        didRecalculateStyleForElementImpl(agents);
}

void didScheduleStyleRecalculationImpl(InstrumentingAgents*, Document*);

inline void didScheduleStyleRecalculation(Document* paramDocument)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (InstrumentingAgents* agents = instrumentingAgentsForDocument(paramDocument))
        didScheduleStyleRecalculationImpl(agents, paramDocument);
}

void applyUserAgentOverrideImpl(InstrumentingAgents*, String*);

inline void applyUserAgentOverride(Frame* paramFrame, String* userAgent)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (InstrumentingAgents* agents = instrumentingAgentsForFrame(paramFrame))
        applyUserAgentOverrideImpl(agents, userAgent);
}

void applyScreenWidthOverrideImpl(InstrumentingAgents*, long*);

inline void applyScreenWidthOverride(Frame* paramFrame, long* width)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (InstrumentingAgents* agents = instrumentingAgentsForFrame(paramFrame))
        applyScreenWidthOverrideImpl(agents, width);
}

void applyScreenHeightOverrideImpl(InstrumentingAgents*, long*);

inline void applyScreenHeightOverride(Frame* paramFrame, long* height)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (InstrumentingAgents* agents = instrumentingAgentsForFrame(paramFrame))
        applyScreenHeightOverrideImpl(agents, height);
}

void applyEmulatedMediaImpl(InstrumentingAgents*, String*);

inline void applyEmulatedMedia(Frame* paramFrame, String* media)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (InstrumentingAgents* agents = instrumentingAgentsForFrame(paramFrame))
        applyEmulatedMediaImpl(agents, media);
}

void willSendRequestImpl(InstrumentingAgents*, unsigned long, DocumentLoader*, ResourceRequest&, const ResourceResponse&, const FetchInitiatorInfo&);

inline void willSendRequest(Frame* paramFrame, unsigned long identifier, DocumentLoader* paramDocumentLoader, ResourceRequest& paramResourceRequest, const ResourceResponse& redirectResponse, const FetchInitiatorInfo& paramFetchInitiatorInfo)
{   
    if (InstrumentingAgents* agents = instrumentingAgentsForFrame(paramFrame))
        willSendRequestImpl(agents, identifier, paramDocumentLoader, paramResourceRequest, redirectResponse, paramFetchInitiatorInfo);
}

void continueAfterPingLoaderImpl(InstrumentingAgents*, unsigned long, DocumentLoader*, ResourceRequest&, const ResourceResponse&);

inline void continueAfterPingLoader(Frame* paramFrame, unsigned long identifier, DocumentLoader* paramDocumentLoader, ResourceRequest& paramResourceRequest, const ResourceResponse& paramResourceResponse)
{   
    if (InstrumentingAgents* agents = instrumentingAgentsForFrame(paramFrame))
        continueAfterPingLoaderImpl(agents, identifier, paramDocumentLoader, paramResourceRequest, paramResourceResponse);
}

void markResourceAsCachedImpl(InstrumentingAgents*, unsigned long);

inline void markResourceAsCached(Page* paramPage, unsigned long identifier)
{   
    if (InstrumentingAgents* agents = instrumentingAgentsForPage(paramPage))
        markResourceAsCachedImpl(agents, identifier);
}

InspectorInstrumentationCookie willReceiveResourceDataImpl(InstrumentingAgents*, Frame*, unsigned long, int);

inline InspectorInstrumentationCookie willReceiveResourceData(Frame* paramFrame, unsigned long identifier, int length)
{   
    FAST_RETURN_IF_NO_FRONTENDS(InspectorInstrumentationCookie());
    if (InstrumentingAgents* agents = instrumentingAgentsForFrame(paramFrame))
        return willReceiveResourceDataImpl(agents, paramFrame, identifier, length);
    return InspectorInstrumentationCookie();
}

void didReceiveResourceDataImpl(const InspectorInstrumentationCookie&);

inline void didReceiveResourceData(const InspectorInstrumentationCookie& paramInspectorInstrumentationCookie)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (paramInspectorInstrumentationCookie.isValid())
        didReceiveResourceDataImpl(paramInspectorInstrumentationCookie);
}

InspectorInstrumentationCookie willReceiveResourceResponseImpl(InstrumentingAgents*, Frame*, unsigned long, const ResourceResponse&);

inline InspectorInstrumentationCookie willReceiveResourceResponse(Frame* paramFrame, unsigned long identifier, const ResourceResponse& paramResourceResponse)
{   
    if (InstrumentingAgents* agents = instrumentingAgentsForFrame(paramFrame))
        return willReceiveResourceResponseImpl(agents, paramFrame, identifier, paramResourceResponse);
    return InspectorInstrumentationCookie();
}

void didReceiveResourceResponseImpl(const InspectorInstrumentationCookie&, unsigned long, DocumentLoader*, const ResourceResponse&, ResourceLoader*);

inline void didReceiveResourceResponse(const InspectorInstrumentationCookie& paramInspectorInstrumentationCookie, unsigned long identifier, DocumentLoader* paramDocumentLoader, const ResourceResponse& paramResourceResponse, ResourceLoader* paramResourceLoader)
{   
    if (paramInspectorInstrumentationCookie.isValid())
        didReceiveResourceResponseImpl(paramInspectorInstrumentationCookie, identifier, paramDocumentLoader, paramResourceResponse, paramResourceLoader);
}

void continueAfterXFrameOptionsDeniedImpl(Frame*, DocumentLoader*, unsigned long, const ResourceResponse&);

inline void continueAfterXFrameOptionsDenied(Frame* frame, DocumentLoader* loader, unsigned long identifier, const ResourceResponse& r)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    continueAfterXFrameOptionsDeniedImpl(frame, loader, identifier, r);
}

void continueWithPolicyDownloadImpl(Frame*, DocumentLoader*, unsigned long, const ResourceResponse&);

inline void continueWithPolicyDownload(Frame* frame, DocumentLoader* loader, unsigned long identifier, const ResourceResponse& r)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    continueWithPolicyDownloadImpl(frame, loader, identifier, r);
}

void continueWithPolicyIgnoreImpl(Frame*, DocumentLoader*, unsigned long, const ResourceResponse&);

inline void continueWithPolicyIgnore(Frame* frame, DocumentLoader* loader, unsigned long identifier, const ResourceResponse& r)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    continueWithPolicyIgnoreImpl(frame, loader, identifier, r);
}

void didReceiveDataImpl(InstrumentingAgents*, unsigned long, const char*, int, int);

inline void didReceiveData(Frame* paramFrame, unsigned long identifier, const char* data, int dataLength, int encodedDataLength)
{   
    if (InstrumentingAgents* agents = instrumentingAgentsForFrame(paramFrame))
        didReceiveDataImpl(agents, identifier, data, dataLength, encodedDataLength);
}

void didFinishLoadingImpl(InstrumentingAgents*, unsigned long, DocumentLoader*, double);

inline void didFinishLoading(Frame* frame, unsigned long identifier, DocumentLoader* paramDocumentLoader, double finishTime)
{   
    if (InstrumentingAgents* agents = instrumentingAgentsForFrame(frame))
        didFinishLoadingImpl(agents, identifier, paramDocumentLoader, finishTime);
}

void didFailLoadingImpl(InstrumentingAgents*, unsigned long, DocumentLoader*, const ResourceError&);

inline void didFailLoading(Frame* frame, unsigned long identifier, DocumentLoader* paramDocumentLoader, const ResourceError& paramResourceError)
{   
    if (InstrumentingAgents* agents = instrumentingAgentsForFrame(frame))
        didFailLoadingImpl(agents, identifier, paramDocumentLoader, paramResourceError);
}

void documentThreadableLoaderStartedLoadingForClientImpl(InstrumentingAgents*, unsigned long, ThreadableLoaderClient*);

inline void documentThreadableLoaderStartedLoadingForClient(ScriptExecutionContext* paramScriptExecutionContext, unsigned long identifier, ThreadableLoaderClient* client)
{   
    if (InstrumentingAgents* agents = instrumentingAgentsForScriptExecutionContext(paramScriptExecutionContext))
        documentThreadableLoaderStartedLoadingForClientImpl(agents, identifier, client);
}

void willLoadXHRImpl(InstrumentingAgents*, ThreadableLoaderClient*, const String&, const KURL&, bool, PassRefPtr<FormData>, const HTTPHeaderMap&, bool);

inline void willLoadXHR(ScriptExecutionContext* paramScriptExecutionContext, ThreadableLoaderClient* client, const String& method, const KURL& url, bool async, PassRefPtr<FormData> paramFormData, const HTTPHeaderMap& headers, bool includeCredentials)
{   
    if (InstrumentingAgents* agents = instrumentingAgentsForScriptExecutionContext(paramScriptExecutionContext))
        willLoadXHRImpl(agents, client, method, url, async, paramFormData, headers, includeCredentials);
}

void didFailXHRLoadingImpl(InstrumentingAgents*, ThreadableLoaderClient*);

inline void didFailXHRLoading(ScriptExecutionContext* paramScriptExecutionContext, ThreadableLoaderClient* client)
{   
    if (InstrumentingAgents* agents = instrumentingAgentsForScriptExecutionContext(paramScriptExecutionContext))
        didFailXHRLoadingImpl(agents, client);
}

void didFinishXHRLoadingImpl(InstrumentingAgents*, ThreadableLoaderClient*, unsigned long, ScriptString, const String&, const String&, unsigned);

inline void didFinishXHRLoading(ScriptExecutionContext* paramScriptExecutionContext, ThreadableLoaderClient* client, unsigned long identifier, ScriptString sourceString, const String& url, const String& sendURL, unsigned sendLineNumber)
{   
    if (InstrumentingAgents* agents = instrumentingAgentsForScriptExecutionContext(paramScriptExecutionContext))
        didFinishXHRLoadingImpl(agents, client, identifier, sourceString, url, sendURL, sendLineNumber);
}

void didReceiveXHRResponseImpl(InstrumentingAgents*, unsigned long);

inline void didReceiveXHRResponse(ScriptExecutionContext* paramScriptExecutionContext, unsigned long identifier)
{   
    if (InstrumentingAgents* agents = instrumentingAgentsForScriptExecutionContext(paramScriptExecutionContext))
        didReceiveXHRResponseImpl(agents, identifier);
}

void willLoadXHRSynchronouslyImpl(InstrumentingAgents*);

inline void willLoadXHRSynchronously(ScriptExecutionContext* paramScriptExecutionContext)
{   
    if (InstrumentingAgents* agents = instrumentingAgentsForScriptExecutionContext(paramScriptExecutionContext))
        willLoadXHRSynchronouslyImpl(agents);
}

void didLoadXHRSynchronouslyImpl(InstrumentingAgents*);

inline void didLoadXHRSynchronously(ScriptExecutionContext* paramScriptExecutionContext)
{   
    if (InstrumentingAgents* agents = instrumentingAgentsForScriptExecutionContext(paramScriptExecutionContext))
        didLoadXHRSynchronouslyImpl(agents);
}

void scriptImportedImpl(InstrumentingAgents*, unsigned long, const String&);

inline void scriptImported(ScriptExecutionContext* paramScriptExecutionContext, unsigned long identifier, const String& sourceString)
{   
    if (InstrumentingAgents* agents = instrumentingAgentsForScriptExecutionContext(paramScriptExecutionContext))
        scriptImportedImpl(agents, identifier, sourceString);
}

void scriptExecutionBlockedByCSPImpl(InstrumentingAgents*, const String&);

inline void scriptExecutionBlockedByCSP(ScriptExecutionContext* paramScriptExecutionContext, const String& directiveText)
{   
    if (InstrumentingAgents* agents = instrumentingAgentsForScriptExecutionContext(paramScriptExecutionContext))
        scriptExecutionBlockedByCSPImpl(agents, directiveText);
}

void didReceiveScriptResponseImpl(InstrumentingAgents*, unsigned long);

inline void didReceiveScriptResponse(ScriptExecutionContext* paramScriptExecutionContext, unsigned long identifier)
{   
    if (InstrumentingAgents* agents = instrumentingAgentsForScriptExecutionContext(paramScriptExecutionContext))
        didReceiveScriptResponseImpl(agents, identifier);
}

void domContentLoadedEventFiredImpl(InstrumentingAgents*, Frame*);

inline void domContentLoadedEventFired(Frame* paramFrame)
{   
    if (InstrumentingAgents* agents = instrumentingAgentsForFrame(paramFrame))
        domContentLoadedEventFiredImpl(agents, paramFrame);
}

void loadEventFiredImpl(InstrumentingAgents*, Frame*);

inline void loadEventFired(Frame* paramFrame)
{   
    if (InstrumentingAgents* agents = instrumentingAgentsForFrame(paramFrame))
        loadEventFiredImpl(agents, paramFrame);
}

void frameDetachedFromParentImpl(InstrumentingAgents*, Frame*);

inline void frameDetachedFromParent(Frame* paramFrame)
{   
    if (InstrumentingAgents* agents = instrumentingAgentsForFrame(paramFrame))
        frameDetachedFromParentImpl(agents, paramFrame);
}

void childDocumentOpenedImpl(InstrumentingAgents*, Document*);

inline void childDocumentOpened(Document* paramDocument)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (InstrumentingAgents* agents = instrumentingAgentsForDocument(paramDocument))
        childDocumentOpenedImpl(agents, paramDocument);
}

void didCommitLoadImpl(InstrumentingAgents*, Frame*, DocumentLoader*);

inline void didCommitLoad(Frame* paramFrame, DocumentLoader* paramDocumentLoader)
{   
    if (InstrumentingAgents* agents = instrumentingAgentsForFrame(paramFrame))
        didCommitLoadImpl(agents, paramFrame, paramDocumentLoader);
}

void frameDocumentUpdatedImpl(InstrumentingAgents*, Frame*);

inline void frameDocumentUpdated(Frame* paramFrame)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (InstrumentingAgents* agents = instrumentingAgentsForFrame(paramFrame))
        frameDocumentUpdatedImpl(agents, paramFrame);
}

void loaderDetachedFromFrameImpl(InstrumentingAgents*, DocumentLoader*);

inline void loaderDetachedFromFrame(Frame* paramFrame, DocumentLoader* paramDocumentLoader)
{   
    if (InstrumentingAgents* agents = instrumentingAgentsForFrame(paramFrame))
        loaderDetachedFromFrameImpl(agents, paramDocumentLoader);
}

void frameStartedLoadingImpl(InstrumentingAgents*, Frame*);

inline void frameStartedLoading(Frame* paramFrame)
{   
    if (InstrumentingAgents* agents = instrumentingAgentsForFrame(paramFrame))
        frameStartedLoadingImpl(agents, paramFrame);
}

void frameStoppedLoadingImpl(InstrumentingAgents*, Frame*);

inline void frameStoppedLoading(Frame* paramFrame)
{   
    if (InstrumentingAgents* agents = instrumentingAgentsForFrame(paramFrame))
        frameStoppedLoadingImpl(agents, paramFrame);
}

void frameScheduledNavigationImpl(InstrumentingAgents*, Frame*, double);

inline void frameScheduledNavigation(Frame* paramFrame, double delay)
{   
    if (InstrumentingAgents* agents = instrumentingAgentsForFrame(paramFrame))
        frameScheduledNavigationImpl(agents, paramFrame, delay);
}

void frameClearedScheduledNavigationImpl(InstrumentingAgents*, Frame*);

inline void frameClearedScheduledNavigation(Frame* paramFrame)
{   
    if (InstrumentingAgents* agents = instrumentingAgentsForFrame(paramFrame))
        frameClearedScheduledNavigationImpl(agents, paramFrame);
}

InspectorInstrumentationCookie willRunJavaScriptDialogImpl(InstrumentingAgents*, const String&);

inline InspectorInstrumentationCookie willRunJavaScriptDialog(Page* paramPage, const String& message)
{   
    FAST_RETURN_IF_NO_FRONTENDS(InspectorInstrumentationCookie());
    if (InstrumentingAgents* agents = instrumentingAgentsForPage(paramPage))
        return willRunJavaScriptDialogImpl(agents, message);
    return InspectorInstrumentationCookie();
}

void didRunJavaScriptDialogImpl(const InspectorInstrumentationCookie&);

inline void didRunJavaScriptDialog(const InspectorInstrumentationCookie& paramInspectorInstrumentationCookie)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (paramInspectorInstrumentationCookie.isValid())
        didRunJavaScriptDialogImpl(paramInspectorInstrumentationCookie);
}

void willDestroyResourceImpl(Resource*);

inline void willDestroyResource(Resource* cachedResource)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    willDestroyResourceImpl(cachedResource);
}

InspectorInstrumentationCookie willWriteHTMLImpl(InstrumentingAgents*, Document*, unsigned);

inline InspectorInstrumentationCookie willWriteHTML(Document* paramDocument, unsigned startLine)
{   
    FAST_RETURN_IF_NO_FRONTENDS(InspectorInstrumentationCookie());
    if (InstrumentingAgents* agents = instrumentingAgentsForDocument(paramDocument))
        return willWriteHTMLImpl(agents, paramDocument, startLine);
    return InspectorInstrumentationCookie();
}

void didWriteHTMLImpl(const InspectorInstrumentationCookie&, unsigned);

inline void didWriteHTML(const InspectorInstrumentationCookie& paramInspectorInstrumentationCookie, unsigned endLine)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (paramInspectorInstrumentationCookie.isValid())
        didWriteHTMLImpl(paramInspectorInstrumentationCookie, endLine);
}

void didRequestAnimationFrameImpl(InstrumentingAgents*, Document*, int);

inline void didRequestAnimationFrame(Document* paramDocument, int callbackId)
{   
    if (InstrumentingAgents* agents = instrumentingAgentsForDocument(paramDocument))
        didRequestAnimationFrameImpl(agents, paramDocument, callbackId);
}

void didCancelAnimationFrameImpl(InstrumentingAgents*, Document*, int);

inline void didCancelAnimationFrame(Document* paramDocument, int callbackId)
{   
    if (InstrumentingAgents* agents = instrumentingAgentsForDocument(paramDocument))
        didCancelAnimationFrameImpl(agents, paramDocument, callbackId);
}

InspectorInstrumentationCookie willFireAnimationFrameImpl(InstrumentingAgents*, Document*, int);

inline InspectorInstrumentationCookie willFireAnimationFrame(Document* paramDocument, int callbackId)
{   
    if (InstrumentingAgents* agents = instrumentingAgentsForDocument(paramDocument))
        return willFireAnimationFrameImpl(agents, paramDocument, callbackId);
    return InspectorInstrumentationCookie();
}

void didFireAnimationFrameImpl(const InspectorInstrumentationCookie&);

inline void didFireAnimationFrame(const InspectorInstrumentationCookie& paramInspectorInstrumentationCookie)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (paramInspectorInstrumentationCookie.isValid())
        didFireAnimationFrameImpl(paramInspectorInstrumentationCookie);
}

void didDispatchDOMStorageEventImpl(InstrumentingAgents*, const String&, const String&, const String&, StorageType, SecurityOrigin*);

inline void didDispatchDOMStorageEvent(Page* page, const String& key, const String& oldValue, const String& newValue, StorageType storageType, SecurityOrigin* securityOrigin)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (InstrumentingAgents* agents = instrumentingAgentsForPage(page))
        didDispatchDOMStorageEventImpl(agents, key, oldValue, newValue, storageType, securityOrigin);
}

void didStartWorkerGlobalScopeImpl(InstrumentingAgents*, WorkerGlobalScopeProxy*, const KURL&);

inline void didStartWorkerGlobalScope(ScriptExecutionContext* paramScriptExecutionContext, WorkerGlobalScopeProxy* proxy, const KURL& url)
{   
    if (InstrumentingAgents* agents = instrumentingAgentsForScriptExecutionContext(paramScriptExecutionContext))
        didStartWorkerGlobalScopeImpl(agents, proxy, url);
}

void willEvaluateWorkerScriptImpl(InstrumentingAgents*, WorkerGlobalScope*, int);

inline void willEvaluateWorkerScript(WorkerGlobalScope* context, int workerThreadStartMode)
{   
    if (InstrumentingAgents* agents = instrumentingAgentsForWorkerGlobalScope(context))
        willEvaluateWorkerScriptImpl(agents, context, workerThreadStartMode);
}

void workerGlobalScopeTerminatedImpl(InstrumentingAgents*, WorkerGlobalScopeProxy*);

inline void workerGlobalScopeTerminated(ScriptExecutionContext* paramScriptExecutionContext, WorkerGlobalScopeProxy* proxy)
{   
    if (InstrumentingAgents* agents = instrumentingAgentsForScriptExecutionContext(paramScriptExecutionContext))
        workerGlobalScopeTerminatedImpl(agents, proxy);
}

void didCreateWebSocketImpl(InstrumentingAgents*, Document*, unsigned long, const KURL&, const String&);

inline void didCreateWebSocket(Document* paramDocument, unsigned long identifier, const KURL& requestURL, const String& protocol)
{   
    if (InstrumentingAgents* agents = instrumentingAgentsForDocument(paramDocument))
        didCreateWebSocketImpl(agents, paramDocument, identifier, requestURL, protocol);
}

void willSendWebSocketHandshakeRequestImpl(InstrumentingAgents*, Document*, unsigned long, const WebSocketHandshakeRequest&);

inline void willSendWebSocketHandshakeRequest(Document* paramDocument, unsigned long identifier, const WebSocketHandshakeRequest& request)
{   
    if (InstrumentingAgents* agents = instrumentingAgentsForDocument(paramDocument))
        willSendWebSocketHandshakeRequestImpl(agents, paramDocument, identifier, request);
}

void didReceiveWebSocketHandshakeResponseImpl(InstrumentingAgents*, Document*, unsigned long, const WebSocketHandshakeResponse&);

inline void didReceiveWebSocketHandshakeResponse(Document* paramDocument, unsigned long identifier, const WebSocketHandshakeResponse& response)
{   
    if (InstrumentingAgents* agents = instrumentingAgentsForDocument(paramDocument))
        didReceiveWebSocketHandshakeResponseImpl(agents, paramDocument, identifier, response);
}

void didCloseWebSocketImpl(InstrumentingAgents*, Document*, unsigned long);

inline void didCloseWebSocket(Document* paramDocument, unsigned long identifier)
{   
    if (InstrumentingAgents* agents = instrumentingAgentsForDocument(paramDocument))
        didCloseWebSocketImpl(agents, paramDocument, identifier);
}

void didReceiveWebSocketFrameImpl(InstrumentingAgents*, unsigned long, const WebSocketFrame&);

inline void didReceiveWebSocketFrame(Document* paramDocument, unsigned long identifier, const WebSocketFrame& frame)
{   
    if (InstrumentingAgents* agents = instrumentingAgentsForDocument(paramDocument))
        didReceiveWebSocketFrameImpl(agents, identifier, frame);
}

void didSendWebSocketFrameImpl(InstrumentingAgents*, unsigned long, const WebSocketFrame&);

inline void didSendWebSocketFrame(Document* paramDocument, unsigned long identifier, const WebSocketFrame& frame)
{   
    if (InstrumentingAgents* agents = instrumentingAgentsForDocument(paramDocument))
        didSendWebSocketFrameImpl(agents, identifier, frame);
}

void didReceiveWebSocketFrameErrorImpl(InstrumentingAgents*, unsigned long, const String&);

inline void didReceiveWebSocketFrameError(Document* paramDocument, unsigned long identifier, const String& errorMessage)
{   
    if (InstrumentingAgents* agents = instrumentingAgentsForDocument(paramDocument))
        didReceiveWebSocketFrameErrorImpl(agents, identifier, errorMessage);
}

void networkStateChangedImpl(InstrumentingAgents*);

inline void networkStateChanged(Page* paramPage)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (InstrumentingAgents* agents = instrumentingAgentsForPage(paramPage))
        networkStateChangedImpl(agents);
}

void updateApplicationCacheStatusImpl(InstrumentingAgents*, Frame*);

inline void updateApplicationCacheStatus(Frame* paramFrame)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (InstrumentingAgents* agents = instrumentingAgentsForFrame(paramFrame))
        updateApplicationCacheStatusImpl(agents, paramFrame);
}

void layerTreeDidChangeImpl(InstrumentingAgents*);

inline void layerTreeDidChange(Page* paramPage)
{   
    if (InstrumentingAgents* agents = instrumentingAgentsForPage(paramPage))
        layerTreeDidChangeImpl(agents);
}

} // namespace InspectorInstrumentation

} // namespace WebCore

#endif // !defined(InspectorInstrumentationInl_h)

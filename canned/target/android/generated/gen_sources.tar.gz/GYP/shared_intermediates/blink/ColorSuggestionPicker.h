namespace WebCore {
extern const char colorSuggestionPickerCss[690];
extern const char colorSuggestionPickerJs[4486];
}

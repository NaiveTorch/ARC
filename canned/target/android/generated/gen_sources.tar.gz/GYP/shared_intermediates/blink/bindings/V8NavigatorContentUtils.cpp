/*
    This file is generated just to tell build scripts that V8NavigatorContentUtils.h and
    V8NavigatorContentUtils.cpp are created for NavigatorContentUtils.idl, and thus
    prevent the build scripts from trying to generate V8NavigatorContentUtils.h and
    V8NavigatorContentUtils.cpp at every build. This file must not be tried to compile.
*/

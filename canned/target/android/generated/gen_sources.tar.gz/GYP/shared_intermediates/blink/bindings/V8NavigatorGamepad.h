/*
    This file is generated just to tell build scripts that V8NavigatorGamepad.h and
    V8NavigatorGamepad.cpp are created for NavigatorGamepad.idl, and thus
    prevent the build scripts from trying to generate V8NavigatorGamepad.h and
    V8NavigatorGamepad.cpp at every build. This file must not be tried to compile.
*/

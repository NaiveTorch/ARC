/*
    This file is generated just to tell build scripts that V8WorkerGlobalScopeNotifications.h and
    V8WorkerGlobalScopeNotifications.cpp are created for WorkerGlobalScopeNotifications.idl, and thus
    prevent the build scripts from trying to generate V8WorkerGlobalScopeNotifications.h and
    V8WorkerGlobalScopeNotifications.cpp at every build. This file must not be tried to compile.
*/

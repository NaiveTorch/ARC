/*
    This file is generated just to tell build scripts that V8DocumentFullscreen.h and
    V8DocumentFullscreen.cpp are created for DocumentFullscreen.idl, and thus
    prevent the build scripts from trying to generate V8DocumentFullscreen.h and
    V8DocumentFullscreen.cpp at every build. This file must not be tried to compile.
*/

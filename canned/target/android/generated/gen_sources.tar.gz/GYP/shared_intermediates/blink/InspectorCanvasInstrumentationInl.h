// Code generated from InspectorInstrumentation.idl

#ifndef InspectorCanvasInstrumentationInl_h
#define InspectorCanvasInstrumentationInl_h

#include "bindings/v8/ScriptObject.h"
#include "core/inspector/InspectorInstrumentation.h"

namespace WebCore {

namespace InspectorInstrumentation {

ScriptObject wrapCanvas2DRenderingContextForInstrumentationImpl(InstrumentingAgents*, const ScriptObject&);

inline ScriptObject wrapCanvas2DRenderingContextForInstrumentation(Document* paramDocument, const ScriptObject& paramScriptObject)
{   
    if (InstrumentingAgents* agents = instrumentingAgentsForDocument(paramDocument))
        return wrapCanvas2DRenderingContextForInstrumentationImpl(agents, paramScriptObject);
    return ScriptObject();
}

ScriptObject wrapWebGLRenderingContextForInstrumentationImpl(InstrumentingAgents*, const ScriptObject&);

inline ScriptObject wrapWebGLRenderingContextForInstrumentation(Document* paramDocument, const ScriptObject& paramScriptObject)
{   
    if (InstrumentingAgents* agents = instrumentingAgentsForDocument(paramDocument))
        return wrapWebGLRenderingContextForInstrumentationImpl(agents, paramScriptObject);
    return ScriptObject();
}

} // namespace InspectorInstrumentation

} // namespace WebCore

#endif // !defined(InspectorCanvasInstrumentationInl_h)

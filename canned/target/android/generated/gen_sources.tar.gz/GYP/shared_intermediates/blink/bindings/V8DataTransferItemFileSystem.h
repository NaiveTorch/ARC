/*
    This file is generated just to tell build scripts that V8DataTransferItemFileSystem.h and
    V8DataTransferItemFileSystem.cpp are created for DataTransferItemFileSystem.idl, and thus
    prevent the build scripts from trying to generate V8DataTransferItemFileSystem.h and
    V8DataTransferItemFileSystem.cpp at every build. This file must not be tried to compile.
*/

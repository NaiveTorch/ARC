/*
 * Copyright (C) 2013 Google Inc. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 *
 *     * Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following disclaimer
 * in the documentation and/or other materials provided with the
 * distribution.
 *     * Neither the name of Google Inc. nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef RuntimeEnabledFeatures_h
#define RuntimeEnabledFeatures_h

namespace WebCore {

// A class that stores static enablers for all experimental features.

class RuntimeEnabledFeatures {
public:
    static void setStableFeaturesEnabled(bool);
    static void setExperimentalFeaturesEnabled(bool);
    static void setTestFeaturesEnabled(bool);


    static void setAnimatedWebPEnabled(bool isEnabled) { isAnimatedWebPEnabled = isEnabled; }
    static bool animatedWebPEnabled() { return isAnimatedWebPEnabled; }

    static void setApplicationCacheEnabled(bool isEnabled) { isApplicationCacheEnabled = isEnabled; }
    static bool applicationCacheEnabled() { return isApplicationCacheEnabled; }

    static void setAuthorShadowDOMForAnyElementEnabled(bool isEnabled) { isAuthorShadowDOMForAnyElementEnabled = isEnabled; }
    static bool authorShadowDOMForAnyElementEnabled() { return isAuthorShadowDOMForAnyElementEnabled; }

    static void setCryptoEnabled(bool isEnabled) { isCryptoEnabled = isEnabled; }
    static bool cryptoEnabled() { return isCryptoEnabled; }

    static void setCSSCompositingEnabled(bool isEnabled) { isCSSCompositingEnabled = isEnabled; }
    static bool cssCompositingEnabled() { return isCSSCompositingEnabled; }

    static void setCSSExclusionsEnabled(bool isEnabled) { isCSSExclusionsEnabled = isEnabled; }
    static bool cssExclusionsEnabled() { return isCSSExclusionsEnabled; }

    static void setCSSGridLayoutEnabled(bool isEnabled) { isCSSGridLayoutEnabled = isEnabled; }
    static bool cssGridLayoutEnabled() { return isCSSGridLayoutEnabled; }

    static void setCSSRegionsEnabled(bool isEnabled) { isCSSRegionsEnabled = isEnabled; }
    static bool cssRegionsEnabled() { return isCSSRegionsEnabled; }

    static void setCSSTouchActionEnabled(bool isEnabled) { isCSSTouchActionEnabled = isEnabled; }
    static bool cssTouchActionEnabled() { return isCSSTouchActionEnabled; }

    static void setCSSVariablesEnabled(bool isEnabled) { isCSSVariablesEnabled = isEnabled; }
    static bool cssVariablesEnabled() { return isCSSVariablesEnabled; }

    static void setCSS3TextEnabled(bool isEnabled) { isCSS3TextEnabled = isEnabled; }
    static bool css3TextEnabled() { return isCSS3TextEnabled; }

    static void setCSS3TextDecorationsEnabled(bool isEnabled) { isCSS3TextDecorationsEnabled = isEnabled; }
    static bool css3TextDecorationsEnabled() { return isCSS3TextDecorationsEnabled; }

    static void setCustomDOMElementsEnabled(bool isEnabled) { isCustomDOMElementsEnabled = isEnabled; }
    static bool customDOMElementsEnabled() { return isCustomDOMElementsEnabled; }

    static void setDatabaseEnabled(bool isEnabled) { isDatabaseEnabled = isEnabled; }
    static bool databaseEnabled() { return isDatabaseEnabled; }

    static void setDataListElementEnabled(bool isEnabled) { isDataListElementEnabled = isEnabled; }
    static bool dataListElementEnabled() { return isDataListElementEnabled; }

    static void setDeviceMotionEnabled(bool isEnabled) { isDeviceMotionEnabled = isEnabled; }
    static bool deviceMotionEnabled() { return isDeviceMotionEnabled; }

    static void setDeviceOrientationEnabled(bool isEnabled) { isDeviceOrientationEnabled = isEnabled; }
    static bool deviceOrientationEnabled() { return isDeviceOrientationEnabled; }

    static void setDialogElementEnabled(bool isEnabled) { isDialogElementEnabled = isEnabled; }
    static bool dialogElementEnabled() { return isDialogElementEnabled; }

    static void setDirectoryUploadEnabled(bool isEnabled) { isDirectoryUploadEnabled = isEnabled; }
    static bool directoryUploadEnabled() { return isDirectoryUploadEnabled; }

    static void setEmbedderCustomElementsEnabled(bool isEnabled) { isEmbedderCustomElementsEnabled = isEnabled; }
    static bool embedderCustomElementsEnabled() { return isEmbedderCustomElementsEnabled; }

    static void setEncodingAPIEnabled(bool isEnabled) { isEncodingAPIEnabled = isEnabled; }
    static bool encodingAPIEnabled() { return isEncodingAPIEnabled; }

    static void setEncryptedMediaEnabled(bool isEnabled) { isEncryptedMediaEnabled = isEnabled; }
    static bool encryptedMediaEnabled() { return isEncryptedMediaEnabled; }

    static void setEncryptedMediaAnyVersionEnabled(bool isEnabled) { isEncryptedMediaAnyVersionEnabled = isEnabled; }
    static bool encryptedMediaAnyVersionEnabled() { return isEncryptedMediaAnyVersionEnabled; }

    static void setExperimentalCanvasFeaturesEnabled(bool isEnabled) { isExperimentalCanvasFeaturesEnabled = isEnabled; }
    static bool experimentalCanvasFeaturesEnabled() { return isExperimentalCanvasFeaturesEnabled; }

    static void setExperimentalContentSecurityPolicyFeaturesEnabled(bool isEnabled) { isExperimentalContentSecurityPolicyFeaturesEnabled = isEnabled; }
    static bool experimentalContentSecurityPolicyFeaturesEnabled() { return isExperimentalContentSecurityPolicyFeaturesEnabled; }

    static void setFileSystemEnabled(bool isEnabled) { isFileSystemEnabled = isEnabled; }
    static bool fileSystemEnabled() { return isFileSystemEnabled; }

    static void setFontLoadEventsEnabled(bool isEnabled) { isFontLoadEventsEnabled = isEnabled; }
    static bool fontLoadEventsEnabled() { return isFontLoadEventsEnabled; }

    static void setFullscreenEnabled(bool isEnabled) { isFullscreenEnabled = isEnabled; }
    static bool fullscreenEnabled() { return isFullscreenEnabled; }

    static void setCSSViewportEnabled(bool isEnabled) { isCSSViewportEnabled = isEnabled; }
    static bool cssViewportEnabled() { return isCSSViewportEnabled; }

    static void setGamepadEnabled(bool isEnabled) { isGamepadEnabled = isEnabled; }
    static bool gamepadEnabled() { return isGamepadEnabled; }

    static void setGeolocationEnabled(bool isEnabled) { isGeolocationEnabled = isEnabled; }
    static bool geolocationEnabled() { return isGeolocationEnabled; }

    static void setHTMLImportsEnabled(bool isEnabled) { isHTMLImportsEnabled = isEnabled; }
    static bool htmlImportsEnabled() { return isHTMLImportsEnabled; }

    static void setHighResolutionTimeInWorkersEnabled(bool isEnabled) { isHighResolutionTimeInWorkersEnabled = isEnabled; }
    static bool highResolutionTimeInWorkersEnabled() { return isHighResolutionTimeInWorkersEnabled; }

    static void setIMEAPIEnabled(bool isEnabled) { isIMEAPIEnabled = isEnabled; }
    static bool imeAPIEnabled() { return isIMEAPIEnabled; }

    static void setIndexedDBEnabled(bool isEnabled) { isIndexedDBEnabled = isEnabled; }
    static bool indexedDBEnabled() { return isIndexedDBEnabled; }

    static void setInputModeAttributeEnabled(bool isEnabled) { isInputModeAttributeEnabled = isEnabled; }
    static bool inputModeAttributeEnabled() { return isInputModeAttributeEnabled; }

    static void setInputTypeColorEnabled(bool isEnabled) { isInputTypeColorEnabled = isEnabled; }
    static bool inputTypeColorEnabled() { return isInputTypeColorEnabled; }

    static void setInputTypeWeekEnabled(bool isEnabled) { isInputTypeWeekEnabled = isEnabled; }
    static bool inputTypeWeekEnabled() { return isInputTypeWeekEnabled; }

    static void setLangAttributeAwareFormControlUIEnabled(bool isEnabled) { isLangAttributeAwareFormControlUIEnabled = isEnabled; }
    static bool langAttributeAwareFormControlUIEnabled() { return isLangAttributeAwareFormControlUIEnabled; }

    static void setLazyLayoutEnabled(bool isEnabled) { isLazyLayoutEnabled = isEnabled; }
    static bool lazyLayoutEnabled() { return isLazyLayoutEnabled; }

    static void setLegacyEncryptedMediaEnabled(bool isEnabled) { isLegacyEncryptedMediaEnabled = isEnabled; }
    static bool legacyEncryptedMediaEnabled() { return isLegacyEncryptedMediaEnabled; }

    static void setLocalStorageEnabled(bool isEnabled) { isLocalStorageEnabled = isEnabled; }
    static bool localStorageEnabled() { return isLocalStorageEnabled; }

    static void setMediaEnabled(bool isEnabled) { isMediaEnabled = isEnabled; }
    static bool mediaEnabled() { return isMediaEnabled; }

    static void setMediaSourceEnabled(bool isEnabled) { isMediaSourceEnabled = isEnabled; }
    static bool mediaSourceEnabled() { return isMediaSourceEnabled; }

    static void setMediaStreamEnabled(bool isEnabled) { isMediaStreamEnabled = isEnabled; }
    static bool mediaStreamEnabled() { return isMediaStreamEnabled; }

    static void setNotificationsEnabled(bool isEnabled) { isNotificationsEnabled = isEnabled; }
    static bool notificationsEnabled() { return isNotificationsEnabled; }

    static void setPagePopupEnabled(bool isEnabled) { isPagePopupEnabled = isEnabled; }
    static bool pagePopupEnabled() { return isPagePopupEnabled; }

    static void setParseSVGAsHTMLEnabled(bool isEnabled) { isParseSVGAsHTMLEnabled = isEnabled; }
    static bool parseSVGAsHTMLEnabled() { return isParseSVGAsHTMLEnabled; }

    static void setPathOpsSVGClippingEnabled(bool isEnabled) { isPathOpsSVGClippingEnabled = isEnabled; }
    static bool pathOpsSVGClippingEnabled() { return isPathOpsSVGClippingEnabled; }

    static void setPeerConnectionEnabled(bool isEnabled) { isPeerConnectionEnabled = isEnabled; }
    static bool peerConnectionEnabled() { return isPeerConnectionEnabled && isMediaStreamEnabled; }

    static void setProgrammaticScrollNotificationsEnabled(bool isEnabled) { isProgrammaticScrollNotificationsEnabled = isEnabled; }
    static bool programmaticScrollNotificationsEnabled() { return isProgrammaticScrollNotificationsEnabled; }

    static void setPromiseEnabled(bool isEnabled) { isPromiseEnabled = isEnabled; }
    static bool promiseEnabled() { return isPromiseEnabled; }

    static void setQuotaEnabled(bool isEnabled) { isQuotaEnabled = isEnabled; }
    static bool quotaEnabled() { return isQuotaEnabled; }

    static void setOverlayScrollbarsEnabled(bool isEnabled) { isOverlayScrollbarsEnabled = isEnabled; }
    static bool overlayScrollbarsEnabled() { return isOverlayScrollbarsEnabled; }

    static void setRequestAutocompleteEnabled(bool isEnabled) { isRequestAutocompleteEnabled = isEnabled; }
    static bool requestAutocompleteEnabled() { return isRequestAutocompleteEnabled; }

    static void setRowSpanLogicalHeightSpreadingEnabled(bool isEnabled) { isRowSpanLogicalHeightSpreadingEnabled = isEnabled; }
    static bool rowSpanLogicalHeightSpreadingEnabled() { return isRowSpanLogicalHeightSpreadingEnabled; }

    static void setScriptedSpeechEnabled(bool isEnabled) { isScriptedSpeechEnabled = isEnabled; }
    static bool scriptedSpeechEnabled() { return isScriptedSpeechEnabled; }

    static void setSeamlessIFramesEnabled(bool isEnabled) { isSeamlessIFramesEnabled = isEnabled; }
    static bool seamlessIFramesEnabled() { return isSeamlessIFramesEnabled; }

    static void setSessionStorageEnabled(bool isEnabled) { isSessionStorageEnabled = isEnabled; }
    static bool sessionStorageEnabled() { return isSessionStorageEnabled; }

    static void setShadowDOMEnabled(bool isEnabled) { isShadowDOMEnabled = isEnabled; }
    static bool shadowDOMEnabled() { return isShadowDOMEnabled; }

    static bool sharedWorkerEnabled();

    static void setSpeechInputEnabled(bool isEnabled) { isSpeechInputEnabled = isEnabled; }
    static bool speechInputEnabled() { return isSpeechInputEnabled; }

    static void setSpeechSynthesisEnabled(bool isEnabled) { isSpeechSynthesisEnabled = isEnabled; }
    static bool speechSynthesisEnabled() { return isSpeechSynthesisEnabled; }

    static void setStreamEnabled(bool isEnabled) { isStreamEnabled = isEnabled; }
    static bool streamEnabled() { return isStreamEnabled; }

    static void setStyleScopedEnabled(bool isEnabled) { isStyleScopedEnabled = isEnabled; }
    static bool styleScopedEnabled() { return isStyleScopedEnabled; }

    static void setTouchEnabled(bool isEnabled) { isTouchEnabled = isEnabled; }
    static bool touchEnabled() { return isTouchEnabled; }

    static void setUserSelectAllEnabled(bool isEnabled) { isUserSelectAllEnabled = isEnabled; }
    static bool userSelectAllEnabled() { return isUserSelectAllEnabled; }

    static void setVibrationEnabled(bool isEnabled) { isVibrationEnabled = isEnabled; }
    static bool vibrationEnabled() { return isVibrationEnabled; }

    static void setVideoTrackEnabled(bool isEnabled) { isVideoTrackEnabled = isEnabled; }
    static bool videoTrackEnabled() { return isVideoTrackEnabled; }

    static void setWebAnimationsEnabled(bool isEnabled) { isWebAnimationsEnabled = isEnabled; }
    static bool webAnimationsEnabled() { return isWebAnimationsEnabled; }

    static void setWebAnimationsCSSEnabled(bool isEnabled) { isWebAnimationsCSSEnabled = isEnabled; }
    static bool webAnimationsCSSEnabled() { return isWebAnimationsCSSEnabled && isWebAnimationsEnabled; }

    static void setWebAnimationsSVGEnabled(bool isEnabled) { isWebAnimationsSVGEnabled = isEnabled; }
    static bool webAnimationsSVGEnabled() { return isWebAnimationsSVGEnabled && isWebAnimationsEnabled; }

#if ENABLE(WEB_AUDIO)
    static void setWebAudioEnabled(bool isEnabled) { isWebAudioEnabled = isEnabled; }
    static bool webAudioEnabled() { return isWebAudioEnabled; }
#else
    static void setWebAudioEnabled(bool) { }
    static bool webAudioEnabled() { return false; }
#endif

    static void setWebGLDraftExtensionsEnabled(bool isEnabled) { isWebGLDraftExtensionsEnabled = isEnabled; }
    static bool webGLDraftExtensionsEnabled() { return isWebGLDraftExtensionsEnabled; }

    static void setWebMIDIEnabled(bool isEnabled) { isWebMIDIEnabled = isEnabled; }
    static bool webMIDIEnabled() { return isWebMIDIEnabled; }

    static void setWebKitMediaSourceEnabled(bool isEnabled) { isWebKitMediaSourceEnabled = isEnabled; }
    static bool webKitMediaSourceEnabled() { return isWebKitMediaSourceEnabled; }

    static void setWOFF2Enabled(bool isEnabled) { isWOFF2Enabled = isEnabled; }
    static bool woff2Enabled() { return isWOFF2Enabled; }


private:
    RuntimeEnabledFeatures() { }

    static bool isAnimatedWebPEnabled;
    static bool isApplicationCacheEnabled;
    static bool isAuthorShadowDOMForAnyElementEnabled;
    static bool isCryptoEnabled;
    static bool isCSSCompositingEnabled;
    static bool isCSSExclusionsEnabled;
    static bool isCSSGridLayoutEnabled;
    static bool isCSSRegionsEnabled;
    static bool isCSSTouchActionEnabled;
    static bool isCSSVariablesEnabled;
    static bool isCSS3TextEnabled;
    static bool isCSS3TextDecorationsEnabled;
    static bool isCustomDOMElementsEnabled;
    static bool isDatabaseEnabled;
    static bool isDataListElementEnabled;
    static bool isDeviceMotionEnabled;
    static bool isDeviceOrientationEnabled;
    static bool isDialogElementEnabled;
    static bool isDirectoryUploadEnabled;
    static bool isEmbedderCustomElementsEnabled;
    static bool isEncodingAPIEnabled;
    static bool isEncryptedMediaEnabled;
    static bool isEncryptedMediaAnyVersionEnabled;
    static bool isExperimentalCanvasFeaturesEnabled;
    static bool isExperimentalContentSecurityPolicyFeaturesEnabled;
    static bool isFileSystemEnabled;
    static bool isFontLoadEventsEnabled;
    static bool isFullscreenEnabled;
    static bool isCSSViewportEnabled;
    static bool isGamepadEnabled;
    static bool isGeolocationEnabled;
    static bool isHTMLImportsEnabled;
    static bool isHighResolutionTimeInWorkersEnabled;
    static bool isIMEAPIEnabled;
    static bool isIndexedDBEnabled;
    static bool isInputModeAttributeEnabled;
    static bool isInputTypeColorEnabled;
    static bool isInputTypeWeekEnabled;
    static bool isLangAttributeAwareFormControlUIEnabled;
    static bool isLazyLayoutEnabled;
    static bool isLegacyEncryptedMediaEnabled;
    static bool isLocalStorageEnabled;
    static bool isMediaEnabled;
    static bool isMediaSourceEnabled;
    static bool isMediaStreamEnabled;
    static bool isNotificationsEnabled;
    static bool isPagePopupEnabled;
    static bool isParseSVGAsHTMLEnabled;
    static bool isPathOpsSVGClippingEnabled;
    static bool isPeerConnectionEnabled;
    static bool isProgrammaticScrollNotificationsEnabled;
    static bool isPromiseEnabled;
    static bool isQuotaEnabled;
    static bool isOverlayScrollbarsEnabled;
    static bool isRequestAutocompleteEnabled;
    static bool isRowSpanLogicalHeightSpreadingEnabled;
    static bool isScriptedSpeechEnabled;
    static bool isSeamlessIFramesEnabled;
    static bool isSessionStorageEnabled;
    static bool isShadowDOMEnabled;
    static bool isSpeechInputEnabled;
    static bool isSpeechSynthesisEnabled;
    static bool isStreamEnabled;
    static bool isStyleScopedEnabled;
    static bool isTouchEnabled;
    static bool isUserSelectAllEnabled;
    static bool isVibrationEnabled;
    static bool isVideoTrackEnabled;
    static bool isWebAnimationsEnabled;
    static bool isWebAnimationsCSSEnabled;
    static bool isWebAnimationsSVGEnabled;
#if ENABLE(WEB_AUDIO)
    static bool isWebAudioEnabled;
#endif
    static bool isWebGLDraftExtensionsEnabled;
    static bool isWebMIDIEnabled;
    static bool isWebKitMediaSourceEnabled;
    static bool isWOFF2Enabled;
};

} // namespace WebCore

#endif // RuntimeEnabledFeatures_h

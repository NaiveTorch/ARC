/*
 * Copyright (C) 2013 Google Inc. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 *
 *     * Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following disclaimer
 * in the documentation and/or other materials provided with the
 * distribution.
 *     * Neither the name of Google Inc. nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */


#ifndef EventTargetHeaders_h
#define EventTargetHeaders_h

#include "core/xml/XMLHttpRequest.h"
#include "V8XMLHttpRequest.h"
#include "modules/webmidi/MIDIPort.h"
#include "V8MIDIPort.h"
#include "modules/webmidi/MIDIAccess.h"
#include "V8MIDIAccess.h"
#include "core/workers/SharedWorker.h"
#include "V8SharedWorker.h"
#include "modules/mediasource/WebKitMediaSource.h"
#include "V8WebKitMediaSource.h"
#if ENABLE(WEB_AUDIO)
#include "modules/webaudio/AudioNode.h"
#include "V8AudioNode.h"
#endif
#include "core/page/Performance.h"
#include "V8Performance.h"
#include "modules/mediastream/RTCDataChannel.h"
#include "V8RTCDataChannel.h"
#include "core/dom/Node.h"
#include "V8Node.h"
#include "core/css/FontLoader.h"
#include "V8FontLoader.h"
#include "modules/mediasource/WebKitSourceBufferList.h"
#include "V8WebKitSourceBufferList.h"
#include "modules/speech/SpeechSynthesisUtterance.h"
#include "V8SpeechSynthesisUtterance.h"
#include "modules/indexeddb/IDBOpenDBRequest.h"
#include "V8IDBOpenDBRequest.h"
#include "modules/indexeddb/IDBTransaction.h"
#include "V8IDBTransaction.h"
#include "core/workers/Worker.h"
#include "V8Worker.h"
#include "modules/indexeddb/IDBRequest.h"
#include "V8IDBRequest.h"
#include "core/page/EventSource.h"
#include "V8EventSource.h"
#include "modules/speech/SpeechRecognition.h"
#include "V8SpeechRecognition.h"
#if ENABLE(NOTIFICATIONS)
#include "modules/notifications/Notification.h"
#include "V8Notification.h"
#endif
#include "modules/mediasource/MediaSource.h"
#include "V8MediaSource.h"
#include "core/html/MediaController.h"
#include "V8MediaController.h"
#include "modules/websockets/WebSocket.h"
#include "V8WebSocket.h"
#include "core/html/track/TextTrackCue.h"
#include "V8TextTrackCue.h"
#include "core/svg/SVGElementInstance.h"
#include "V8SVGElementInstance.h"
#include "core/html/track/TextTrack.h"
#include "V8TextTrack.h"
#include "modules/webmidi/MIDIInput.h"
#include "V8MIDIInput.h"
#include "core/loader/appcache/DOMApplicationCache.h"
#include "V8DOMApplicationCache.h"
#include "core/xml/XMLHttpRequestUpload.h"
#include "V8XMLHttpRequestUpload.h"
#include "core/page/DOMWindow.h"
#include "V8Window.h"
#if ENABLE(WEB_AUDIO)
#include "modules/webaudio/AudioContext.h"
#include "V8AudioContext.h"
#endif
#include "modules/mediastream/RTCDTMFSender.h"
#include "V8RTCDTMFSender.h"
#include "modules/mediastream/MediaStream.h"
#include "V8MediaStream.h"
#if ENABLE(ENCRYPTED_MEDIA_V2)
#include "modules/encryptedmedia/MediaKeySession.h"
#include "V8MediaKeySession.h"
#endif
#include "modules/mediastream/MediaStreamTrack.h"
#include "V8MediaStreamTrack.h"
#include "modules/indexeddb/IDBDatabase.h"
#include "V8IDBDatabase.h"
#include "core/fileapi/FileReader.h"
#include "V8FileReader.h"
#include "core/dom/NamedFlow.h"
#include "V8WebKitNamedFlow.h"
#include "modules/mediasource/SourceBufferList.h"
#include "V8SourceBufferList.h"
#include "core/workers/DedicatedWorkerGlobalScope.h"
#include "V8DedicatedWorkerGlobalScope.h"
#include "core/workers/SharedWorkerGlobalScope.h"
#include "V8SharedWorkerGlobalScope.h"
#include "modules/filesystem/FileWriter.h"
#include "V8FileWriter.h"
#include "core/html/track/TextTrackList.h"
#include "V8TextTrackList.h"
#include "modules/mediastream/RTCPeerConnection.h"
#include "V8RTCPeerConnection.h"
#include "core/dom/MessagePort.h"
#include "V8MessagePort.h"
#include "modules/mediasource/SourceBuffer.h"
#include "V8SourceBuffer.h"

#endif // EventTargetHeaders_h

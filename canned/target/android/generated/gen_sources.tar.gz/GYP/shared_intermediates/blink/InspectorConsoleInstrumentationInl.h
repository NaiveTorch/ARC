// Code generated from InspectorInstrumentation.idl

#ifndef InspectorConsoleInstrumentationInl_h
#define InspectorConsoleInstrumentationInl_h

#include "core/inspector/InspectorInstrumentation.h"
#include "core/inspector/ScriptArguments.h"
#include "core/inspector/ScriptCallStack.h"
#include "core/inspector/ScriptProfile.h"

namespace WebCore {

namespace InspectorInstrumentation {

void addMessageToConsoleImpl(InstrumentingAgents*, MessageSource, MessageType, MessageLevel, const String&, PassRefPtr<ScriptCallStack>, unsigned long);

inline void addMessageToConsole(Page* page, MessageSource source, MessageType type, MessageLevel level, const String& message, PassRefPtr<ScriptCallStack> callStack, unsigned long requestIdentifier = 0)
{   
    if (InstrumentingAgents* agents = instrumentingAgentsForPage(page))
        addMessageToConsoleImpl(agents, source, type, level, message, callStack, requestIdentifier);
}

void addMessageToConsoleImpl(InstrumentingAgents*, MessageSource, MessageType, MessageLevel, const String&, ScriptState*, PassRefPtr<ScriptArguments>, unsigned long);

inline void addMessageToConsole(Page* page, MessageSource source, MessageType type, MessageLevel level, const String& message, ScriptState* state, PassRefPtr<ScriptArguments> arguments, unsigned long requestIdentifier = 0)
{   
    if (InstrumentingAgents* agents = instrumentingAgentsForPage(page))
        addMessageToConsoleImpl(agents, source, type, level, message, state, arguments, requestIdentifier);
}

void addMessageToConsoleImpl(InstrumentingAgents*, MessageSource, MessageType, MessageLevel, const String&, const String&, unsigned, unsigned, ScriptState*, unsigned long);

inline void addMessageToConsole(Page* page, MessageSource source, MessageType type, MessageLevel level, const String& message, const String& scriptId, unsigned lineNumber, unsigned columnNumber = 0, ScriptState* state = 0, unsigned long requestIdentifier = 0)
{   
    if (InstrumentingAgents* agents = instrumentingAgentsForPage(page))
        addMessageToConsoleImpl(agents, source, type, level, message, scriptId, lineNumber, columnNumber, state, requestIdentifier);
}

void addMessageToConsoleImpl(InstrumentingAgents*, MessageSource, MessageType, MessageLevel, const String&, PassRefPtr<ScriptCallStack>, unsigned long);

inline void addMessageToConsole(WorkerGlobalScope* workerGlobalScope, MessageSource source, MessageType type, MessageLevel level, const String& message, PassRefPtr<ScriptCallStack> callStack, unsigned long requestIdentifier = 0)
{   
    if (InstrumentingAgents* agents = instrumentingAgentsForWorkerGlobalScope(workerGlobalScope))
        addMessageToConsoleImpl(agents, source, type, level, message, callStack, requestIdentifier);
}

void addMessageToConsoleImpl(InstrumentingAgents*, MessageSource, MessageType, MessageLevel, const String&, const String&, unsigned, unsigned, ScriptState*, unsigned long);

inline void addMessageToConsole(WorkerGlobalScope* workerGlobalScope, MessageSource source, MessageType type, MessageLevel level, const String& message, const String& scriptId, unsigned lineNumber, unsigned columnNumber, ScriptState* state, unsigned long requestIdentifier = 0)
{   
    if (InstrumentingAgents* agents = instrumentingAgentsForWorkerGlobalScope(workerGlobalScope))
        addMessageToConsoleImpl(agents, source, type, level, message, scriptId, lineNumber, columnNumber, state, requestIdentifier);
}

void consoleCountImpl(InstrumentingAgents*, ScriptState*, PassRefPtr<ScriptArguments>);

inline void consoleCount(Page* page, ScriptState* state, PassRefPtr<ScriptArguments> arguments)
{   
    if (InstrumentingAgents* agents = instrumentingAgentsForPage(page))
        consoleCountImpl(agents, state, arguments);
}

void startConsoleTimingImpl(InstrumentingAgents*, Frame*, const String&);

inline void startConsoleTiming(Frame* frame, const String& title)
{   
    if (InstrumentingAgents* agents = instrumentingAgentsForFrame(frame))
        startConsoleTimingImpl(agents, frame, title);
}

void stopConsoleTimingImpl(InstrumentingAgents*, Frame*, const String&, PassRefPtr<ScriptCallStack>);

inline void stopConsoleTiming(Frame* frame, const String& title, PassRefPtr<ScriptCallStack> stack)
{   
    if (InstrumentingAgents* agents = instrumentingAgentsForFrame(frame))
        stopConsoleTimingImpl(agents, frame, title, stack);
}

void consoleTimeStampImpl(InstrumentingAgents*, Frame*, PassRefPtr<ScriptArguments>);

inline void consoleTimeStamp(Frame* frame, PassRefPtr<ScriptArguments> arguments)
{   
    FAST_RETURN_IF_NO_FRONTENDS(void());
    if (InstrumentingAgents* agents = instrumentingAgentsForFrame(frame))
        consoleTimeStampImpl(agents, frame, arguments);
}

void addStartProfilingMessageToConsoleImpl(InstrumentingAgents*, const String&, unsigned, const String&);

inline void addStartProfilingMessageToConsole(Page* page, const String& title, unsigned lineNumber, const String& sourceURL)
{   
    if (InstrumentingAgents* agents = instrumentingAgentsForPage(page))
        addStartProfilingMessageToConsoleImpl(agents, title, lineNumber, sourceURL);
}

void addProfileImpl(InstrumentingAgents*, PassRefPtr<ScriptProfile>, PassRefPtr<ScriptCallStack>);

inline void addProfile(Page* page, PassRefPtr<ScriptProfile> profile, PassRefPtr<ScriptCallStack> callStack)
{   
    if (InstrumentingAgents* agents = instrumentingAgentsForPage(page))
        addProfileImpl(agents, profile, callStack);
}

} // namespace InspectorInstrumentation

} // namespace WebCore

#endif // !defined(InspectorConsoleInstrumentationInl_h)

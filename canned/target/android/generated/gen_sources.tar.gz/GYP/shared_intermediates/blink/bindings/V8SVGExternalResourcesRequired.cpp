/*
    This file is generated just to tell build scripts that V8SVGExternalResourcesRequired.h and
    V8SVGExternalResourcesRequired.cpp are created for SVGExternalResourcesRequired.idl, and thus
    prevent the build scripts from trying to generate V8SVGExternalResourcesRequired.h and
    V8SVGExternalResourcesRequired.cpp at every build. This file must not be tried to compile.
*/

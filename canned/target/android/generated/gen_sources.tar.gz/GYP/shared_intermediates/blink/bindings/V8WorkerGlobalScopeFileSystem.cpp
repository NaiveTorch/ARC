/*
    This file is generated just to tell build scripts that V8WorkerGlobalScopeFileSystem.h and
    V8WorkerGlobalScopeFileSystem.cpp are created for WorkerGlobalScopeFileSystem.idl, and thus
    prevent the build scripts from trying to generate V8WorkerGlobalScopeFileSystem.h and
    V8WorkerGlobalScopeFileSystem.cpp at every build. This file must not be tried to compile.
*/

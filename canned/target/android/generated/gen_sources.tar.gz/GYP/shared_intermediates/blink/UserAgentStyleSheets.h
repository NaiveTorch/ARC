namespace WebCore {
extern const char htmlUserAgentStyleSheet[16396];
extern const char quirksUserAgentStyleSheet[345];
extern const char sourceUserAgentStyleSheet[1975];
extern const char themeChromiumUserAgentStyleSheet[71];
extern const char themeChromiumAndroidUserAgentStyleSheet[178];
extern const char themeChromiumLinuxUserAgentStyleSheet[219];
extern const char themeChromiumSkiaUserAgentStyleSheet[42];
extern const char themeWinUserAgentStyleSheet[1519];
extern const char themeWinQuirksUserAgentStyleSheet[34];
extern const char svgUserAgentStyleSheet[399];
extern const char mediaControlsUserAgentStyleSheet[7909];
extern const char mediaControlsAndroidUserAgentStyleSheet[1857];
extern const char fullscreenUserAgentStyleSheet[1145];
}

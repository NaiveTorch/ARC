/*
 * THIS FILE WAS AUTOMATICALLY GENERATED, DO NOT EDIT.
 *
 * Copyright (C) 2011 Google Inc.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY GOOGLE, INC. ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL APPLE COMPUTER, INC. OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef InternalSettingsGenerated_h
#define InternalSettingsGenerated_h

#include "core/platform/RefCountedSupplement.h"
#include "wtf/PassRefPtr.h"
#include "wtf/RefCounted.h"
#include "wtf/text/WTFString.h"

namespace WebCore {

class Page;

class InternalSettingsGenerated : public RefCounted<InternalSettingsGenerated> {
public:
    explicit InternalSettingsGenerated(Page*);
    virtual ~InternalSettingsGenerated();
    void resetToConsistentState();
    void setDOMPasteAllowed(bool DOMPasteAllowed);
    void setAccelerated2dCanvasEnabled(bool accelerated2dCanvasEnabled);
    void setAcceleratedCompositingEnabled(bool acceleratedCompositingEnabled);
    void setAcceleratedCompositingFor3DTransformsEnabled(bool acceleratedCompositingFor3DTransformsEnabled);
    void setAcceleratedCompositingForAnimationEnabled(bool acceleratedCompositingForAnimationEnabled);
    void setAcceleratedCompositingForCanvasEnabled(bool acceleratedCompositingForCanvasEnabled);
    void setAcceleratedCompositingForFiltersEnabled(bool acceleratedCompositingForFiltersEnabled);
    void setAcceleratedCompositingForFixedPositionEnabled(bool acceleratedCompositingForFixedPositionEnabled);
    void setAcceleratedCompositingForFixedRootBackgroundEnabled(bool acceleratedCompositingForFixedRootBackgroundEnabled);
    void setAcceleratedCompositingForOverflowScrollEnabled(bool acceleratedCompositingForOverflowScrollEnabled);
    void setAcceleratedCompositingForPluginsEnabled(bool acceleratedCompositingForPluginsEnabled);
    void setAcceleratedCompositingForScrollableFramesEnabled(bool acceleratedCompositingForScrollableFramesEnabled);
    void setAcceleratedCompositingForTransitionEnabled(bool acceleratedCompositingForTransitionEnabled);
    void setAcceleratedCompositingForVideoEnabled(bool acceleratedCompositingForVideoEnabled);
    void setAcceleratedFiltersEnabled(bool acceleratedFiltersEnabled);
    void setAllowCustomScrollbarInMainFrame(bool allowCustomScrollbarInMainFrame);
    void setAllowDisplayOfInsecureContent(bool allowDisplayOfInsecureContent);
    void setAllowFileAccessFromFileURLs(bool allowFileAccessFromFileURLs);
    void setAllowRunningOfInsecureContent(bool allowRunningOfInsecureContent);
    void setAllowScriptsToCloseWindows(bool allowScriptsToCloseWindows);
    void setAllowUniversalAccessFromFileURLs(bool allowUniversalAccessFromFileURLs);
    void setAntialiased2dCanvasEnabled(bool antialiased2dCanvasEnabled);
    void setApplyPageScaleFactorInCompositor(bool applyPageScaleFactorInCompositor);
    void setAsynchronousSpellCheckingEnabled(bool asynchronousSpellCheckingEnabled);
    void setAuthorAndUserStylesEnabled(bool authorAndUserStylesEnabled);
    void setCaretBrowsingEnabled(bool caretBrowsingEnabled);
    void setCompositedScrollingForFramesEnabled(bool compositedScrollingForFramesEnabled);
    void setCompositorTouchHitTesting(bool compositorTouchHitTesting);
    void setCookieEnabled(bool cookieEnabled);
    void setDefaultFixedFontSize(int defaultFixedFontSize);
    void setDefaultFontSize(int defaultFontSize);
    void setDefaultTextEncodingName(const String& defaultTextEncodingName);
    void setDefaultVideoPosterURL(const String& defaultVideoPosterURL);
    void setDeviceSupportsMouse(bool deviceSupportsMouse);
    void setDeviceSupportsTouch(bool deviceSupportsTouch);
    void setDownloadableBinaryFontsEnabled(bool downloadableBinaryFontsEnabled);
    void setExperimentalWebSocketEnabled(bool experimentalWebSocketEnabled);
    void setFixedPositionCreatesStackingContext(bool fixedPositionCreatesStackingContext);
    void setForceCompositingMode(bool forceCompositingMode);
    void setFullScreenEnabled(bool fullScreenEnabled);
    void setHyperlinkAuditingEnabled(bool hyperlinkAuditingEnabled);
    void setIgnoreMainFrameOverflowHiddenQuirk(bool ignoreMainFrameOverflowHiddenQuirk);
    void setJavaScriptCanAccessClipboard(bool javaScriptCanAccessClipboard);
    void setJavaScriptCanOpenWindowsAutomatically(bool javaScriptCanOpenWindowsAutomatically);
    void setLayoutFallbackWidth(int layoutFallbackWidth);
    void setLocalStorageEnabled(bool localStorageEnabled);
    void setMediaEnabled(bool mediaEnabled);
    void setMediaPlaybackRequiresUserGesture(bool mediaPlaybackRequiresUserGesture);
    void setMemoryInfoEnabled(bool memoryInfoEnabled);
    void setMinimumAccelerated2dCanvasSize(int minimumAccelerated2dCanvasSize);
    void setMinimumFontSize(int minimumFontSize);
    void setMinimumLogicalFontSize(int minimumLogicalFontSize);
    void setNeedsSiteSpecificQuirks(bool needsSiteSpecificQuirks);
    void setOfflineWebApplicationCacheEnabled(bool offlineWebApplicationCacheEnabled);
    void setPageCacheSupportsPlugins(bool pageCacheSupportsPlugins);
    void setPasswordEchoDurationInSeconds(double passwordEchoDurationInSeconds);
    void setPasswordEchoEnabled(bool passwordEchoEnabled);
    void setPinchVirtualViewportEnabled(bool pinchVirtualViewportEnabled);
    void setPrivilegedWebGLExtensionsEnabled(bool privilegedWebGLExtensionsEnabled);
    void setRegionBasedColumnsEnabled(bool regionBasedColumnsEnabled);
    void setReportScreenSizeInPhysicalPixelsQuirk(bool reportScreenSizeInPhysicalPixelsQuirk);
    void setScrollAnimatorEnabled(bool scrollAnimatorEnabled);
    void setScrollingCoordinatorEnabled(bool scrollingCoordinatorEnabled);
    void setSelectTrailingWhitespaceEnabled(bool selectTrailingWhitespaceEnabled);
    void setSelectionIncludesAltImageText(bool selectionIncludesAltImageText);
    void setShouldClearDocumentBackground(bool shouldClearDocumentBackground);
    void setShouldDisplayCaptions(bool shouldDisplayCaptions);
    void setShouldDisplaySubtitles(bool shouldDisplaySubtitles);
    void setShouldDisplayTextDescriptions(bool shouldDisplayTextDescriptions);
    void setShouldPrintBackgrounds(bool shouldPrintBackgrounds);
    void setShouldRespectImageOrientation(bool shouldRespectImageOrientation);
    void setShowRepaintCounter(bool showRepaintCounter);
    void setShrinksStandaloneImagesToFit(bool shrinksStandaloneImagesToFit);
    void setSmartInsertDeleteEnabled(bool smartInsertDeleteEnabled);
    void setSpatialNavigationEnabled(bool spatialNavigationEnabled);
    void setSupportsMultipleWindows(bool supportsMultipleWindows);
    void setSyncXHRInDocumentsEnabled(bool syncXHRInDocumentsEnabled);
    void setTextAreasAreResizable(bool textAreasAreResizable);
    void setThreadedHTMLParser(bool threadedHTMLParser);
    void setTouchAdjustmentEnabled(bool touchAdjustmentEnabled);
    void setTouchDragDropEnabled(bool touchDragDropEnabled);
    void setTouchEditingEnabled(bool touchEditingEnabled);
    void setUnifiedTextCheckerEnabled(bool unifiedTextCheckerEnabled);
    void setUnsafePluginPastingEnabled(bool unsafePluginPastingEnabled);
    void setUseLegacyBackgroundSizeShorthandBehavior(bool useLegacyBackgroundSizeShorthandBehavior);
    void setUseThreadedHTMLParserForDataURLs(bool useThreadedHTMLParserForDataURLs);
    void setUsesEncodingDetector(bool usesEncodingDetector);
    void setValidationMessageTimerMagnification(int validationMessageTimerMagnification);
    void setViewportMetaMergeQuirk(bool viewportMetaMergeQuirk);
    void setViewportMetaZeroValuesQuirk(bool viewportMetaZeroValuesQuirk);
    void setVisualWordMovementEnabled(bool visualWordMovementEnabled);
    void setWebAudioEnabled(bool webAudioEnabled);
    void setWebGLEnabled(bool webGLEnabled);
    void setWebGLErrorsToConsoleEnabled(bool webGLErrorsToConsoleEnabled);
    void setWebSecurityEnabled(bool webSecurityEnabled);
    void setWideViewportQuirkEnabled(bool wideViewportQuirkEnabled);
    void setXSSAuditorEnabled(bool xssAuditorEnabled);

private:
    Page* m_page;

    bool m_DOMPasteAllowed;
    bool m_accelerated2dCanvasEnabled;
    bool m_acceleratedCompositingEnabled;
    bool m_acceleratedCompositingFor3DTransformsEnabled;
    bool m_acceleratedCompositingForAnimationEnabled;
    bool m_acceleratedCompositingForCanvasEnabled;
    bool m_acceleratedCompositingForFiltersEnabled;
    bool m_acceleratedCompositingForFixedPositionEnabled;
    bool m_acceleratedCompositingForFixedRootBackgroundEnabled;
    bool m_acceleratedCompositingForOverflowScrollEnabled;
    bool m_acceleratedCompositingForPluginsEnabled;
    bool m_acceleratedCompositingForScrollableFramesEnabled;
    bool m_acceleratedCompositingForTransitionEnabled;
    bool m_acceleratedCompositingForVideoEnabled;
    bool m_acceleratedFiltersEnabled;
    bool m_allowCustomScrollbarInMainFrame;
    bool m_allowDisplayOfInsecureContent;
    bool m_allowFileAccessFromFileURLs;
    bool m_allowRunningOfInsecureContent;
    bool m_allowScriptsToCloseWindows;
    bool m_allowUniversalAccessFromFileURLs;
    bool m_antialiased2dCanvasEnabled;
    bool m_applyPageScaleFactorInCompositor;
    bool m_asynchronousSpellCheckingEnabled;
    bool m_authorAndUserStylesEnabled;
    bool m_caretBrowsingEnabled;
    bool m_compositedScrollingForFramesEnabled;
    bool m_compositorTouchHitTesting;
    bool m_cookieEnabled;
    int m_defaultFixedFontSize;
    int m_defaultFontSize;
    String m_defaultTextEncodingName;
    String m_defaultVideoPosterURL;
    bool m_deviceSupportsMouse;
    bool m_deviceSupportsTouch;
    bool m_downloadableBinaryFontsEnabled;
    bool m_experimentalWebSocketEnabled;
    bool m_fixedPositionCreatesStackingContext;
    bool m_forceCompositingMode;
    bool m_fullScreenEnabled;
    bool m_hyperlinkAuditingEnabled;
    bool m_ignoreMainFrameOverflowHiddenQuirk;
    bool m_javaScriptCanAccessClipboard;
    bool m_javaScriptCanOpenWindowsAutomatically;
    int m_layoutFallbackWidth;
    bool m_localStorageEnabled;
    bool m_mediaEnabled;
    bool m_mediaPlaybackRequiresUserGesture;
    bool m_memoryInfoEnabled;
    int m_minimumAccelerated2dCanvasSize;
    int m_minimumFontSize;
    int m_minimumLogicalFontSize;
    bool m_needsSiteSpecificQuirks;
    bool m_offlineWebApplicationCacheEnabled;
    bool m_pageCacheSupportsPlugins;
    double m_passwordEchoDurationInSeconds;
    bool m_passwordEchoEnabled;
    bool m_pinchVirtualViewportEnabled;
    bool m_privilegedWebGLExtensionsEnabled;
    bool m_regionBasedColumnsEnabled;
    bool m_reportScreenSizeInPhysicalPixelsQuirk;
    bool m_scrollAnimatorEnabled;
    bool m_scrollingCoordinatorEnabled;
    bool m_selectTrailingWhitespaceEnabled;
    bool m_selectionIncludesAltImageText;
    bool m_shouldClearDocumentBackground;
    bool m_shouldDisplayCaptions;
    bool m_shouldDisplaySubtitles;
    bool m_shouldDisplayTextDescriptions;
    bool m_shouldPrintBackgrounds;
    bool m_shouldRespectImageOrientation;
    bool m_showRepaintCounter;
    bool m_shrinksStandaloneImagesToFit;
    bool m_smartInsertDeleteEnabled;
    bool m_spatialNavigationEnabled;
    bool m_supportsMultipleWindows;
    bool m_syncXHRInDocumentsEnabled;
    bool m_textAreasAreResizable;
    bool m_threadedHTMLParser;
    bool m_touchAdjustmentEnabled;
    bool m_touchDragDropEnabled;
    bool m_touchEditingEnabled;
    bool m_unifiedTextCheckerEnabled;
    bool m_unsafePluginPastingEnabled;
    bool m_useLegacyBackgroundSizeShorthandBehavior;
    bool m_useThreadedHTMLParserForDataURLs;
    bool m_usesEncodingDetector;
    int m_validationMessageTimerMagnification;
    bool m_viewportMetaMergeQuirk;
    bool m_viewportMetaZeroValuesQuirk;
    bool m_visualWordMovementEnabled;
    bool m_webAudioEnabled;
    bool m_webGLEnabled;
    bool m_webGLErrorsToConsoleEnabled;
    bool m_webSecurityEnabled;
    bool m_wideViewportQuirkEnabled;
    bool m_xssAuditorEnabled;
};

} // namespace WebCore
#endif // InternalSettingsGenerated_h

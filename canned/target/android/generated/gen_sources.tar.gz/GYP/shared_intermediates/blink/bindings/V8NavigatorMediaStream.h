/*
    This file is generated just to tell build scripts that V8NavigatorMediaStream.h and
    V8NavigatorMediaStream.cpp are created for NavigatorMediaStream.idl, and thus
    prevent the build scripts from trying to generate V8NavigatorMediaStream.h and
    V8NavigatorMediaStream.cpp at every build. This file must not be tried to compile.
*/

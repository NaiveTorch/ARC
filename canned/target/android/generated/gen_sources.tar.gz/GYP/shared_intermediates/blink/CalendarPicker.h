#if ENABLE(CALENDAR_PICKER)
namespace WebCore {
extern const char calendarPickerCss[4044];
extern const char calendarPickerJs[87747];
extern const char calendarPickerChromiumCss[368];
extern const char pickerCommonChromiumCss[1321];
extern const char suggestionPickerCss[856];
extern const char suggestionPickerJs[9657];
}
#endif

/*
 * Copyright (C) 2013 Google Inc. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 *
 *     * Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following disclaimer
 * in the documentation and/or other materials provided with the
 * distribution.
 *     * Neither the name of Google Inc. nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "config.h"
#include "RuntimeEnabledFeatures.h"

namespace WebCore {


void RuntimeEnabledFeatures::setStableFeaturesEnabled(bool enable)
{
    setApplicationCacheEnabled(enable);
    setDatabaseEnabled(enable);
    setDataListElementEnabled(enable);
    setDeviceOrientationEnabled(enable);
    setDirectoryUploadEnabled(enable);
    setEncryptedMediaAnyVersionEnabled(enable);
    setFileSystemEnabled(enable);
    setFullscreenEnabled(enable);
    setGamepadEnabled(enable);
    setGeolocationEnabled(enable);
    setIndexedDBEnabled(enable);
    setInputTypeColorEnabled(enable);
    setInputTypeWeekEnabled(enable);
    setLegacyEncryptedMediaEnabled(enable);
    setLocalStorageEnabled(enable);
    setMediaEnabled(enable);
    setMediaStreamEnabled(enable);
    setNotificationsEnabled(enable);
    setPagePopupEnabled(enable);
    setPeerConnectionEnabled(enable);
    setQuotaEnabled(enable);
    setScriptedSpeechEnabled(enable);
    setSessionStorageEnabled(enable);
    setSpeechInputEnabled(enable);
    setTouchEnabled(enable);
    setVideoTrackEnabled(enable);
    setWebAudioEnabled(enable);
    setWebKitMediaSourceEnabled(enable);
}

void RuntimeEnabledFeatures::setExperimentalFeaturesEnabled(bool enable)
{
    setAnimatedWebPEnabled(enable);
    setCSSCompositingEnabled(enable);
    setCSSExclusionsEnabled(enable);
    setCSSGridLayoutEnabled(enable);
    setCSSRegionsEnabled(enable);
    setCSSVariablesEnabled(enable);
    setCSS3TextEnabled(enable);
    setCSS3TextDecorationsEnabled(enable);
    setCustomDOMElementsEnabled(enable);
    setDialogElementEnabled(enable);
    setEncodingAPIEnabled(enable);
    setEncryptedMediaEnabled(enable);
    setExperimentalContentSecurityPolicyFeaturesEnabled(enable);
    setFontLoadEventsEnabled(enable);
    setCSSViewportEnabled(enable);
    setHighResolutionTimeInWorkersEnabled(enable);
    setMediaSourceEnabled(enable);
    setPromiseEnabled(enable);
    setSeamlessIFramesEnabled(enable);
    setShadowDOMEnabled(enable);
    setSpeechSynthesisEnabled(enable);
    setStreamEnabled(enable);
    setStyleScopedEnabled(enable);
    setUserSelectAllEnabled(enable);
    setVibrationEnabled(enable);
    setWebGLDraftExtensionsEnabled(enable);
    setWOFF2Enabled(enable);
}

void RuntimeEnabledFeatures::setTestFeaturesEnabled(bool enable)
{
    setCryptoEnabled(enable);
    setCSSTouchActionEnabled(enable);
    setDeviceMotionEnabled(enable);
    setExperimentalCanvasFeaturesEnabled(enable);
    setHTMLImportsEnabled(enable);
    setIMEAPIEnabled(enable);
    setInputModeAttributeEnabled(enable);
    setProgrammaticScrollNotificationsEnabled(enable);
    setRequestAutocompleteEnabled(enable);
    setRowSpanLogicalHeightSpreadingEnabled(enable);
    setWebMIDIEnabled(enable);
}

bool RuntimeEnabledFeatures::isAnimatedWebPEnabled = false;
bool RuntimeEnabledFeatures::isApplicationCacheEnabled = false;
bool RuntimeEnabledFeatures::isAuthorShadowDOMForAnyElementEnabled = false;
bool RuntimeEnabledFeatures::isCryptoEnabled = false;
bool RuntimeEnabledFeatures::isCSSCompositingEnabled = false;
bool RuntimeEnabledFeatures::isCSSExclusionsEnabled = false;
bool RuntimeEnabledFeatures::isCSSGridLayoutEnabled = false;
bool RuntimeEnabledFeatures::isCSSRegionsEnabled = false;
bool RuntimeEnabledFeatures::isCSSTouchActionEnabled = false;
bool RuntimeEnabledFeatures::isCSSVariablesEnabled = false;
bool RuntimeEnabledFeatures::isCSS3TextEnabled = false;
bool RuntimeEnabledFeatures::isCSS3TextDecorationsEnabled = false;
bool RuntimeEnabledFeatures::isCustomDOMElementsEnabled = false;
bool RuntimeEnabledFeatures::isDatabaseEnabled = false;
bool RuntimeEnabledFeatures::isDataListElementEnabled = false;
bool RuntimeEnabledFeatures::isDeviceMotionEnabled = false;
bool RuntimeEnabledFeatures::isDeviceOrientationEnabled = false;
bool RuntimeEnabledFeatures::isDialogElementEnabled = false;
bool RuntimeEnabledFeatures::isDirectoryUploadEnabled = false;
bool RuntimeEnabledFeatures::isEmbedderCustomElementsEnabled = false;
bool RuntimeEnabledFeatures::isEncodingAPIEnabled = false;
bool RuntimeEnabledFeatures::isEncryptedMediaEnabled = false;
bool RuntimeEnabledFeatures::isEncryptedMediaAnyVersionEnabled = false;
bool RuntimeEnabledFeatures::isExperimentalCanvasFeaturesEnabled = false;
bool RuntimeEnabledFeatures::isExperimentalContentSecurityPolicyFeaturesEnabled = false;
bool RuntimeEnabledFeatures::isFileSystemEnabled = false;
bool RuntimeEnabledFeatures::isFontLoadEventsEnabled = false;
bool RuntimeEnabledFeatures::isFullscreenEnabled = false;
bool RuntimeEnabledFeatures::isCSSViewportEnabled = false;
bool RuntimeEnabledFeatures::isGamepadEnabled = false;
bool RuntimeEnabledFeatures::isGeolocationEnabled = false;
bool RuntimeEnabledFeatures::isHTMLImportsEnabled = false;
bool RuntimeEnabledFeatures::isHighResolutionTimeInWorkersEnabled = false;
bool RuntimeEnabledFeatures::isIMEAPIEnabled = false;
bool RuntimeEnabledFeatures::isIndexedDBEnabled = false;
bool RuntimeEnabledFeatures::isInputModeAttributeEnabled = false;
bool RuntimeEnabledFeatures::isInputTypeColorEnabled = false;
bool RuntimeEnabledFeatures::isInputTypeWeekEnabled = false;
bool RuntimeEnabledFeatures::isLangAttributeAwareFormControlUIEnabled = false;
bool RuntimeEnabledFeatures::isLazyLayoutEnabled = false;
bool RuntimeEnabledFeatures::isLegacyEncryptedMediaEnabled = false;
bool RuntimeEnabledFeatures::isLocalStorageEnabled = false;
bool RuntimeEnabledFeatures::isMediaEnabled = false;
bool RuntimeEnabledFeatures::isMediaSourceEnabled = false;
bool RuntimeEnabledFeatures::isMediaStreamEnabled = false;
bool RuntimeEnabledFeatures::isNotificationsEnabled = false;
bool RuntimeEnabledFeatures::isPagePopupEnabled = false;
bool RuntimeEnabledFeatures::isParseSVGAsHTMLEnabled = false;
bool RuntimeEnabledFeatures::isPathOpsSVGClippingEnabled = false;
bool RuntimeEnabledFeatures::isPeerConnectionEnabled = false;
bool RuntimeEnabledFeatures::isProgrammaticScrollNotificationsEnabled = false;
bool RuntimeEnabledFeatures::isPromiseEnabled = false;
bool RuntimeEnabledFeatures::isQuotaEnabled = false;
bool RuntimeEnabledFeatures::isOverlayScrollbarsEnabled = false;
bool RuntimeEnabledFeatures::isRequestAutocompleteEnabled = false;
bool RuntimeEnabledFeatures::isRowSpanLogicalHeightSpreadingEnabled = false;
bool RuntimeEnabledFeatures::isScriptedSpeechEnabled = false;
bool RuntimeEnabledFeatures::isSeamlessIFramesEnabled = false;
bool RuntimeEnabledFeatures::isSessionStorageEnabled = false;
bool RuntimeEnabledFeatures::isShadowDOMEnabled = false;
bool RuntimeEnabledFeatures::isSpeechInputEnabled = false;
bool RuntimeEnabledFeatures::isSpeechSynthesisEnabled = false;
bool RuntimeEnabledFeatures::isStreamEnabled = false;
bool RuntimeEnabledFeatures::isStyleScopedEnabled = false;
bool RuntimeEnabledFeatures::isTouchEnabled = false;
bool RuntimeEnabledFeatures::isUserSelectAllEnabled = false;
bool RuntimeEnabledFeatures::isVibrationEnabled = false;
bool RuntimeEnabledFeatures::isVideoTrackEnabled = false;
bool RuntimeEnabledFeatures::isWebAnimationsEnabled = false;
bool RuntimeEnabledFeatures::isWebAnimationsCSSEnabled = false;
bool RuntimeEnabledFeatures::isWebAnimationsSVGEnabled = false;
#if ENABLE(WEB_AUDIO)
bool RuntimeEnabledFeatures::isWebAudioEnabled = false;
#endif
bool RuntimeEnabledFeatures::isWebGLDraftExtensionsEnabled = false;
bool RuntimeEnabledFeatures::isWebMIDIEnabled = false;
bool RuntimeEnabledFeatures::isWebKitMediaSourceEnabled = false;
bool RuntimeEnabledFeatures::isWOFF2Enabled = false;

} // namespace WebCore

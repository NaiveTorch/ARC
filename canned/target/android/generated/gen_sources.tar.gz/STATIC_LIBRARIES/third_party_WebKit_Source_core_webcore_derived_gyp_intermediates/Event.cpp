/*
 * Copyright (C) 2013 Google Inc. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 *
 *     * Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following disclaimer
 * in the documentation and/or other materials provided with the
 * distribution.
 *     * Neither the name of Google Inc. nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "config.h"
#include "EventFactory.h"

#include "EventHeaders.h"
#include "RuntimeEnabledFeatures.h"

namespace WebCore {

PassRefPtr<Event> EventFactory::create(const String& type)
{
    if (type == "CSSFontFaceLoadEvent" && RuntimeEnabledFeatures::fontLoadEventsEnabled())
        return CSSFontFaceLoadEvent::create();
    if (type == "AutocompleteErrorEvent")
        return AutocompleteErrorEvent::create();
    if (type == "BeforeLoadEvent")
        return BeforeLoadEvent::create();
    if (type == "CompositionEvent")
        return CompositionEvent::create();
    if (type == "CustomEvent")
        return CustomEvent::create();
    if (type == "ErrorEvent")
        return ErrorEvent::create();
    if (type == "Event")
        return Event::create();
    if (type == "FocusEvent")
        return FocusEvent::create();
    if (type == "HashChangeEvent")
        return HashChangeEvent::create();
    if (type == "KeyboardEvent")
        return KeyboardEvent::create();
    if (type == "MessageEvent")
        return MessageEvent::create();
    if (type == "MouseEvent")
        return MouseEvent::create();
    if (type == "MutationEvent")
        return MutationEvent::create();
    if (type == "OverflowEvent")
        return OverflowEvent::create();
    if (type == "PageTransitionEvent")
        return PageTransitionEvent::create();
    if (type == "PopStateEvent")
        return PopStateEvent::create();
    if (type == "ProgressEvent")
        return ProgressEvent::create();
    if (type == "ResourceProgressEvent")
        return ResourceProgressEvent::create();
    if (type == "SecurityPolicyViolationEvent" && RuntimeEnabledFeatures::experimentalContentSecurityPolicyFeaturesEnabled())
        return SecurityPolicyViolationEvent::create();
    if (type == "TextEvent")
        return TextEvent::create();
    if (type == "TouchEvent" && RuntimeEnabledFeatures::touchEnabled())
        return TouchEvent::create();
    if (type == "TransitionEvent")
        return TransitionEvent::create();
    if (type == "UIEvent")
        return UIEvent::create();
    if (type == "WebKitAnimationEvent")
        return AnimationEvent::create();
    if (type == "WheelEvent")
        return WheelEvent::create();
    if (type == "MediaKeyEvent" && RuntimeEnabledFeatures::legacyEncryptedMediaEnabled())
        return MediaKeyEvent::create();
    if (type == "WebGLContextEvent")
        return WebGLContextEvent::create();
    if (type == "TrackEvent" && RuntimeEnabledFeatures::videoTrackEnabled())
        return TrackEvent::create();
#if ENABLE(INPUT_SPEECH)
    if (type == "SpeechInputEvent")
        return SpeechInputEvent::create();
#endif
    if (type == "StorageEvent")
        return StorageEvent::create();
    if (type == "SVGZoomEvent")
        return SVGZoomEvent::create();
    if (type == "XMLHttpRequestProgressEvent")
        return XMLHttpRequestProgressEvent::create();
    if (type == "DeviceMotionEvent" && RuntimeEnabledFeatures::deviceMotionEnabled())
        return DeviceMotionEvent::create();
    if (type == "DeviceOrientationEvent")
        return DeviceOrientationEvent::create();
#if ENABLE(ENCRYPTED_MEDIA_V2)
    if (type == "MediaKeyMessageEvent" && RuntimeEnabledFeatures::encryptedMediaEnabled())
        return MediaKeyMessageEvent::create();
#endif
#if ENABLE(ENCRYPTED_MEDIA_V2)
    if (type == "MediaKeyNeededEvent" && RuntimeEnabledFeatures::encryptedMediaEnabled())
        return MediaKeyNeededEvent::create();
#endif
    if (type == "IDBVersionChangeEvent")
        return IDBVersionChangeEvent::create();
    if (type == "MediaStreamEvent")
        return MediaStreamEvent::create();
    if (type == "MediaStreamTrackEvent")
        return MediaStreamTrackEvent::create();
    if (type == "RTCDTMFToneChangeEvent")
        return RTCDTMFToneChangeEvent::create();
    if (type == "RTCDataChannelEvent")
        return RTCDataChannelEvent::create();
    if (type == "RTCIceCandidateEvent")
        return RTCIceCandidateEvent::create();
    if (type == "SpeechRecognitionError")
        return SpeechRecognitionError::create();
    if (type == "SpeechRecognitionEvent")
        return SpeechRecognitionEvent::create();
    if (type == "SpeechSynthesisEvent" && RuntimeEnabledFeatures::speechSynthesisEnabled())
        return SpeechSynthesisEvent::create();
#if ENABLE(WEB_AUDIO)
    if (type == "AudioProcessingEvent")
        return AudioProcessingEvent::create();
#endif
#if ENABLE(WEB_AUDIO)
    if (type == "OfflineAudioCompletionEvent")
        return OfflineAudioCompletionEvent::create();
#endif
    if (type == "MIDIConnectionEvent" && RuntimeEnabledFeatures::webMIDIEnabled())
        return MIDIConnectionEvent::create();
    if (type == "MIDIMessageEvent" && RuntimeEnabledFeatures::webMIDIEnabled())
        return MIDIMessageEvent::create();
    if (type == "CloseEvent")
        return CloseEvent::create();
    if (type == "Events")
        return Event::create();
    if (type == "HTMLEvents")
        return Event::create();
    if (type == "KeyboardEvents")
        return KeyboardEvent::create();
    if (type == "MouseEvents")
        return MouseEvent::create();
    if (type == "MutationEvents")
        return MutationEvent::create();
#if ENABLE(ORIENTATION_EVENTS)
    if (type == "OrientationEvent")
        return Event::create();
#endif
    if (type == "SVGEvents")
        return Event::create();
    if (type == "SVGZoomEvents")
        return SVGZoomEvent::create();
    if (type == "UIEvents")
        return UIEvent::create();
    if (type == "WebKitTransitionEvent")
        return TransitionEvent::create();
    return 0;
}

} // namespace WebCore

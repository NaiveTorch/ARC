/*
 * (C) 1999-2003 Lars Knoll (knoll@kde.org)
 * Copyright (C) 2004, 2005, 2006, 2007, 2008 Apple Inc. All rights reserved.
 * Copyright (C) 2013 Intel Corporation. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public License
 * along with this library; see the file COPYING.LIB.  If not, write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA 02110-1301, USA.
 */

#include "config.h"
#include "StylePropertyShorthand.h"
#include "RuntimeEnabledFeatures.h"

#include "wtf/HashMap.h"
#include "wtf/StdLibExtras.h"

namespace WebCore {

const StylePropertyShorthand& backgroundRepeatShorthand()
{
    static const CSSPropertyID backgroundRepeatProperties[] = {
        CSSPropertyBackgroundRepeatX,
        CSSPropertyBackgroundRepeatY,
    };
    DEFINE_STATIC_LOCAL(StylePropertyShorthand, backgroundRepeatLonghands, (CSSPropertyBackgroundRepeat, backgroundRepeatProperties, WTF_ARRAY_LENGTH(backgroundRepeatProperties)));
    return backgroundRepeatLonghands;
}

const StylePropertyShorthand& flexShorthand()
{
    static const CSSPropertyID flexProperties[] = {
        CSSPropertyFlexGrow,
        CSSPropertyFlexShrink,
        CSSPropertyFlexBasis,
    };
    DEFINE_STATIC_LOCAL(StylePropertyShorthand, flexLonghands, (CSSPropertyFlex, flexProperties, WTF_ARRAY_LENGTH(flexProperties)));
    return flexLonghands;
}

const StylePropertyShorthand& borderStyleShorthand()
{
    static const CSSPropertyID borderStyleProperties[] = {
        CSSPropertyBorderTopStyle,
        CSSPropertyBorderRightStyle,
        CSSPropertyBorderBottomStyle,
        CSSPropertyBorderLeftStyle,
    };
    DEFINE_STATIC_LOCAL(StylePropertyShorthand, borderStyleLonghands, (CSSPropertyBorderStyle, borderStyleProperties, WTF_ARRAY_LENGTH(borderStyleProperties)));
    return borderStyleLonghands;
}

const StylePropertyShorthand& flexFlowShorthand()
{
    static const CSSPropertyID flexFlowProperties[] = {
        CSSPropertyFlexDirection,
        CSSPropertyFlexWrap,
    };
    DEFINE_STATIC_LOCAL(StylePropertyShorthand, flexFlowLonghands, (CSSPropertyFlexFlow, flexFlowProperties, WTF_ARRAY_LENGTH(flexFlowProperties)));
    return flexFlowLonghands;
}

const StylePropertyShorthand& webkitMarqueeShorthand()
{
    static const CSSPropertyID webkitMarqueeProperties[] = {
        CSSPropertyWebkitMarqueeDirection,
        CSSPropertyWebkitMarqueeIncrement,
        CSSPropertyWebkitMarqueeRepetition,
        CSSPropertyWebkitMarqueeStyle,
        CSSPropertyWebkitMarqueeSpeed,
    };
    DEFINE_STATIC_LOCAL(StylePropertyShorthand, webkitMarqueeLonghands, (CSSPropertyWebkitMarquee, webkitMarqueeProperties, WTF_ARRAY_LENGTH(webkitMarqueeProperties)));
    return webkitMarqueeLonghands;
}

const StylePropertyShorthand& outlineShorthand()
{
    static const CSSPropertyID outlineProperties[] = {
        CSSPropertyOutlineColor,
        CSSPropertyOutlineStyle,
        CSSPropertyOutlineWidth,
    };
    DEFINE_STATIC_LOCAL(StylePropertyShorthand, outlineLonghands, (CSSPropertyOutline, outlineProperties, WTF_ARRAY_LENGTH(outlineProperties)));
    return outlineLonghands;
}

const StylePropertyShorthand& webkitColumnsShorthand()
{
    static const CSSPropertyID webkitColumnsProperties[] = {
        CSSPropertyWebkitColumnWidth,
        CSSPropertyWebkitColumnCount,
    };
    DEFINE_STATIC_LOCAL(StylePropertyShorthand, webkitColumnsLonghands, (CSSPropertyWebkitColumns, webkitColumnsProperties, WTF_ARRAY_LENGTH(webkitColumnsProperties)));
    return webkitColumnsLonghands;
}

const StylePropertyShorthand& overflowShorthand()
{
    static const CSSPropertyID overflowProperties[] = {
        CSSPropertyOverflowX,
        CSSPropertyOverflowY,
    };
    DEFINE_STATIC_LOCAL(StylePropertyShorthand, overflowLonghands, (CSSPropertyOverflow, overflowProperties, WTF_ARRAY_LENGTH(overflowProperties)));
    return overflowLonghands;
}

const StylePropertyShorthand& webkitTextStrokeShorthand()
{
    static const CSSPropertyID webkitTextStrokeProperties[] = {
        CSSPropertyWebkitTextStrokeWidth,
        CSSPropertyWebkitTextStrokeColor,
    };
    DEFINE_STATIC_LOCAL(StylePropertyShorthand, webkitTextStrokeLonghands, (CSSPropertyWebkitTextStroke, webkitTextStrokeProperties, WTF_ARRAY_LENGTH(webkitTextStrokeProperties)));
    return webkitTextStrokeLonghands;
}

const StylePropertyShorthand& webkitBorderRadiusShorthand()
{
    static const CSSPropertyID webkitBorderRadiusProperties[] = {
        CSSPropertyBorderTopLeftRadius,
        CSSPropertyBorderTopRightRadius,
        CSSPropertyBorderBottomRightRadius,
        CSSPropertyBorderBottomLeftRadius,
    };
    DEFINE_STATIC_LOCAL(StylePropertyShorthand, webkitBorderRadiusLonghands, (CSSPropertyWebkitBorderRadius, webkitBorderRadiusProperties, WTF_ARRAY_LENGTH(webkitBorderRadiusProperties)));
    return webkitBorderRadiusLonghands;
}

const StylePropertyShorthand& gridColumnShorthand()
{
    static const CSSPropertyID gridColumnProperties[] = {
        CSSPropertyGridColumnStart,
        CSSPropertyGridColumnEnd,
    };
    DEFINE_STATIC_LOCAL(StylePropertyShorthand, gridColumnLonghands, (CSSPropertyGridColumn, gridColumnProperties, WTF_ARRAY_LENGTH(gridColumnProperties)));
    return gridColumnLonghands;
}

const StylePropertyShorthand& webkitTransitionShorthand()
{
    static const CSSPropertyID webkitTransitionProperties[] = {
        CSSPropertyWebkitTransitionProperty,
        CSSPropertyWebkitTransitionDuration,
        CSSPropertyWebkitTransitionTimingFunction,
        CSSPropertyWebkitTransitionDelay,
    };
    DEFINE_STATIC_LOCAL(StylePropertyShorthand, webkitTransitionLonghands, (CSSPropertyWebkitTransition, webkitTransitionProperties, WTF_ARRAY_LENGTH(webkitTransitionProperties)));
    return webkitTransitionLonghands;
}

const StylePropertyShorthand& markerShorthand()
{
    static const CSSPropertyID markerProperties[] = {
        CSSPropertyMarkerStart,
        CSSPropertyMarkerMid,
        CSSPropertyMarkerEnd,
    };
    DEFINE_STATIC_LOCAL(StylePropertyShorthand, markerLonghands, (CSSPropertyMarker, markerProperties, WTF_ARRAY_LENGTH(markerProperties)));
    return markerLonghands;
}

const StylePropertyShorthand& webkitMarginCollapseShorthand()
{
    static const CSSPropertyID webkitMarginCollapseProperties[] = {
        CSSPropertyWebkitMarginBeforeCollapse,
        CSSPropertyWebkitMarginAfterCollapse,
    };
    DEFINE_STATIC_LOCAL(StylePropertyShorthand, webkitMarginCollapseLonghands, (CSSPropertyWebkitMarginCollapse, webkitMarginCollapseProperties, WTF_ARRAY_LENGTH(webkitMarginCollapseProperties)));
    return webkitMarginCollapseLonghands;
}

const StylePropertyShorthand& marginShorthand()
{
    static const CSSPropertyID marginProperties[] = {
        CSSPropertyMarginTop,
        CSSPropertyMarginRight,
        CSSPropertyMarginBottom,
        CSSPropertyMarginLeft,
    };
    DEFINE_STATIC_LOCAL(StylePropertyShorthand, marginLonghands, (CSSPropertyMargin, marginProperties, WTF_ARRAY_LENGTH(marginProperties)));
    return marginLonghands;
}

const StylePropertyShorthand& webkitTextEmphasisShorthand()
{
    static const CSSPropertyID webkitTextEmphasisProperties[] = {
        CSSPropertyWebkitTextEmphasisStyle,
        CSSPropertyWebkitTextEmphasisColor,
    };
    DEFINE_STATIC_LOCAL(StylePropertyShorthand, webkitTextEmphasisLonghands, (CSSPropertyWebkitTextEmphasis, webkitTextEmphasisProperties, WTF_ARRAY_LENGTH(webkitTextEmphasisProperties)));
    return webkitTextEmphasisLonghands;
}

const StylePropertyShorthand& borderSpacingShorthand()
{
    static const CSSPropertyID borderSpacingProperties[] = {
        CSSPropertyWebkitBorderHorizontalSpacing,
        CSSPropertyWebkitBorderVerticalSpacing,
    };
    DEFINE_STATIC_LOCAL(StylePropertyShorthand, borderSpacingLonghands, (CSSPropertyBorderSpacing, borderSpacingProperties, WTF_ARRAY_LENGTH(borderSpacingProperties)));
    return borderSpacingLonghands;
}

const StylePropertyShorthand& borderRightShorthand()
{
    static const CSSPropertyID borderRightProperties[] = {
        CSSPropertyBorderRightWidth,
        CSSPropertyBorderRightStyle,
        CSSPropertyBorderRightColor,
    };
    DEFINE_STATIC_LOCAL(StylePropertyShorthand, borderRightLonghands, (CSSPropertyBorderRight, borderRightProperties, WTF_ARRAY_LENGTH(borderRightProperties)));
    return borderRightLonghands;
}

const StylePropertyShorthand& heightShorthand()
{
    static const CSSPropertyID heightProperties[] = {
        CSSPropertyMinHeight,
        CSSPropertyMaxHeight,
    };
    DEFINE_STATIC_LOCAL(StylePropertyShorthand, heightLonghands, (CSSPropertyHeight, heightProperties, WTF_ARRAY_LENGTH(heightProperties)));
    return heightLonghands;
}

const StylePropertyShorthand& backgroundShorthand()
{
    static const CSSPropertyID backgroundProperties[] = {
        CSSPropertyBackgroundImage,
        CSSPropertyBackgroundPositionX,
        CSSPropertyBackgroundPositionY,
        CSSPropertyBackgroundSize,
        CSSPropertyBackgroundRepeatX,
        CSSPropertyBackgroundRepeatY,
        CSSPropertyBackgroundAttachment,
        CSSPropertyBackgroundOrigin,
        CSSPropertyBackgroundClip,
        CSSPropertyBackgroundColor,
    };
    DEFINE_STATIC_LOCAL(StylePropertyShorthand, backgroundLonghands, (CSSPropertyBackground, backgroundProperties, WTF_ARRAY_LENGTH(backgroundProperties)));
    return backgroundLonghands;
}

const StylePropertyShorthand& webkitMaskRepeatShorthand()
{
    static const CSSPropertyID webkitMaskRepeatProperties[] = {
        CSSPropertyWebkitMaskRepeatX,
        CSSPropertyWebkitMaskRepeatY,
    };
    DEFINE_STATIC_LOCAL(StylePropertyShorthand, webkitMaskRepeatLonghands, (CSSPropertyWebkitMaskRepeat, webkitMaskRepeatProperties, WTF_ARRAY_LENGTH(webkitMaskRepeatProperties)));
    return webkitMaskRepeatLonghands;
}

const StylePropertyShorthand& webkitBorderEndShorthand()
{
    static const CSSPropertyID webkitBorderEndProperties[] = {
        CSSPropertyWebkitBorderEndWidth,
        CSSPropertyWebkitBorderEndStyle,
        CSSPropertyWebkitBorderEndColor,
    };
    DEFINE_STATIC_LOCAL(StylePropertyShorthand, webkitBorderEndLonghands, (CSSPropertyWebkitBorderEnd, webkitBorderEndProperties, WTF_ARRAY_LENGTH(webkitBorderEndProperties)));
    return webkitBorderEndLonghands;
}

const StylePropertyShorthand& borderTopShorthand()
{
    static const CSSPropertyID borderTopProperties[] = {
        CSSPropertyBorderTopWidth,
        CSSPropertyBorderTopStyle,
        CSSPropertyBorderTopColor,
    };
    DEFINE_STATIC_LOCAL(StylePropertyShorthand, borderTopLonghands, (CSSPropertyBorderTop, borderTopProperties, WTF_ARRAY_LENGTH(borderTopProperties)));
    return borderTopLonghands;
}

const StylePropertyShorthand& webkitBorderAfterShorthand()
{
    static const CSSPropertyID webkitBorderAfterProperties[] = {
        CSSPropertyWebkitBorderAfterWidth,
        CSSPropertyWebkitBorderAfterStyle,
        CSSPropertyWebkitBorderAfterColor,
    };
    DEFINE_STATIC_LOCAL(StylePropertyShorthand, webkitBorderAfterLonghands, (CSSPropertyWebkitBorderAfter, webkitBorderAfterProperties, WTF_ARRAY_LENGTH(webkitBorderAfterProperties)));
    return webkitBorderAfterLonghands;
}

const StylePropertyShorthand& fontShorthand()
{
    static const CSSPropertyID fontProperties[] = {
        CSSPropertyFontFamily,
        CSSPropertyFontSize,
        CSSPropertyFontStyle,
        CSSPropertyFontVariant,
        CSSPropertyFontWeight,
        CSSPropertyLineHeight,
    };
    DEFINE_STATIC_LOCAL(StylePropertyShorthand, fontLonghands, (CSSPropertyFont, fontProperties, WTF_ARRAY_LENGTH(fontProperties)));
    return fontLonghands;
}

const StylePropertyShorthand& webkitTransformOriginShorthand()
{
    static const CSSPropertyID webkitTransformOriginProperties[] = {
        CSSPropertyWebkitTransformOriginX,
        CSSPropertyWebkitTransformOriginY,
        CSSPropertyWebkitTransformOriginZ,
    };
    DEFINE_STATIC_LOCAL(StylePropertyShorthand, webkitTransformOriginLonghands, (CSSPropertyWebkitTransformOrigin, webkitTransformOriginProperties, WTF_ARRAY_LENGTH(webkitTransformOriginProperties)));
    return webkitTransformOriginLonghands;
}

const StylePropertyShorthand& webkitBorderBeforeShorthand()
{
    static const CSSPropertyID webkitBorderBeforeProperties[] = {
        CSSPropertyWebkitBorderBeforeWidth,
        CSSPropertyWebkitBorderBeforeStyle,
        CSSPropertyWebkitBorderBeforeColor,
    };
    DEFINE_STATIC_LOCAL(StylePropertyShorthand, webkitBorderBeforeLonghands, (CSSPropertyWebkitBorderBefore, webkitBorderBeforeProperties, WTF_ARRAY_LENGTH(webkitBorderBeforeProperties)));
    return webkitBorderBeforeLonghands;
}

const StylePropertyShorthand& paddingShorthand()
{
    static const CSSPropertyID paddingProperties[] = {
        CSSPropertyPaddingTop,
        CSSPropertyPaddingRight,
        CSSPropertyPaddingBottom,
        CSSPropertyPaddingLeft,
    };
    DEFINE_STATIC_LOCAL(StylePropertyShorthand, paddingLonghands, (CSSPropertyPadding, paddingProperties, WTF_ARRAY_LENGTH(paddingProperties)));
    return paddingLonghands;
}

const StylePropertyShorthand& webkitMaskPositionShorthand()
{
    static const CSSPropertyID webkitMaskPositionProperties[] = {
        CSSPropertyWebkitMaskPositionX,
        CSSPropertyWebkitMaskPositionY,
    };
    DEFINE_STATIC_LOCAL(StylePropertyShorthand, webkitMaskPositionLonghands, (CSSPropertyWebkitMaskPosition, webkitMaskPositionProperties, WTF_ARRAY_LENGTH(webkitMaskPositionProperties)));
    return webkitMaskPositionLonghands;
}

const StylePropertyShorthand& borderLeftShorthand()
{
    static const CSSPropertyID borderLeftProperties[] = {
        CSSPropertyBorderLeftWidth,
        CSSPropertyBorderLeftStyle,
        CSSPropertyBorderLeftColor,
    };
    DEFINE_STATIC_LOCAL(StylePropertyShorthand, borderLeftLonghands, (CSSPropertyBorderLeft, borderLeftProperties, WTF_ARRAY_LENGTH(borderLeftProperties)));
    return borderLeftLonghands;
}

const StylePropertyShorthand& webkitMaskShorthand()
{
    static const CSSPropertyID webkitMaskProperties[] = {
        CSSPropertyWebkitMaskImage,
        CSSPropertyWebkitMaskPositionX,
        CSSPropertyWebkitMaskPositionY,
        CSSPropertyWebkitMaskSize,
        CSSPropertyWebkitMaskRepeatX,
        CSSPropertyWebkitMaskRepeatY,
        CSSPropertyWebkitMaskOrigin,
        CSSPropertyWebkitMaskClip,
    };
    DEFINE_STATIC_LOCAL(StylePropertyShorthand, webkitMaskLonghands, (CSSPropertyWebkitMask, webkitMaskProperties, WTF_ARRAY_LENGTH(webkitMaskProperties)));
    return webkitMaskLonghands;
}

const StylePropertyShorthand& listStyleShorthand()
{
    static const CSSPropertyID listStyleProperties[] = {
        CSSPropertyListStyleType,
        CSSPropertyListStylePosition,
        CSSPropertyListStyleImage,
    };
    DEFINE_STATIC_LOCAL(StylePropertyShorthand, listStyleLonghands, (CSSPropertyListStyle, listStyleProperties, WTF_ARRAY_LENGTH(listStyleProperties)));
    return listStyleLonghands;
}

const StylePropertyShorthand& webkitBorderStartShorthand()
{
    static const CSSPropertyID webkitBorderStartProperties[] = {
        CSSPropertyWebkitBorderStartWidth,
        CSSPropertyWebkitBorderStartStyle,
        CSSPropertyWebkitBorderStartColor,
    };
    DEFINE_STATIC_LOCAL(StylePropertyShorthand, webkitBorderStartLonghands, (CSSPropertyWebkitBorderStart, webkitBorderStartProperties, WTF_ARRAY_LENGTH(webkitBorderStartProperties)));
    return webkitBorderStartLonghands;
}

const StylePropertyShorthand& transitionShorthand()
{
    static const CSSPropertyID transitionProperties[] = {
        CSSPropertyTransitionProperty,
        CSSPropertyTransitionDuration,
        CSSPropertyTransitionTimingFunction,
        CSSPropertyTransitionDelay,
    };
    DEFINE_STATIC_LOCAL(StylePropertyShorthand, transitionLonghands, (CSSPropertyTransition, transitionProperties, WTF_ARRAY_LENGTH(transitionProperties)));
    return transitionLonghands;
}

const StylePropertyShorthand& borderColorShorthand()
{
    static const CSSPropertyID borderColorProperties[] = {
        CSSPropertyBorderTopColor,
        CSSPropertyBorderRightColor,
        CSSPropertyBorderBottomColor,
        CSSPropertyBorderLeftColor,
    };
    DEFINE_STATIC_LOCAL(StylePropertyShorthand, borderColorLonghands, (CSSPropertyBorderColor, borderColorProperties, WTF_ARRAY_LENGTH(borderColorProperties)));
    return borderColorLonghands;
}

const StylePropertyShorthand& borderWidthShorthand()
{
    static const CSSPropertyID borderWidthProperties[] = {
        CSSPropertyBorderTopWidth,
        CSSPropertyBorderRightWidth,
        CSSPropertyBorderBottomWidth,
        CSSPropertyBorderLeftWidth,
    };
    DEFINE_STATIC_LOCAL(StylePropertyShorthand, borderWidthLonghands, (CSSPropertyBorderWidth, borderWidthProperties, WTF_ARRAY_LENGTH(borderWidthProperties)));
    return borderWidthLonghands;
}

const StylePropertyShorthand& webkitAnimationShorthand()
{
    static const CSSPropertyID webkitAnimationProperties[] = {
        CSSPropertyWebkitAnimationName,
        CSSPropertyWebkitAnimationDuration,
        CSSPropertyWebkitAnimationTimingFunction,
        CSSPropertyWebkitAnimationDelay,
        CSSPropertyWebkitAnimationIterationCount,
        CSSPropertyWebkitAnimationDirection,
        CSSPropertyWebkitAnimationFillMode,
    };
    DEFINE_STATIC_LOCAL(StylePropertyShorthand, webkitAnimationLonghands, (CSSPropertyWebkitAnimation, webkitAnimationProperties, WTF_ARRAY_LENGTH(webkitAnimationProperties)));
    return webkitAnimationLonghands;
}

const StylePropertyShorthand& backgroundPositionShorthand()
{
    static const CSSPropertyID backgroundPositionProperties[] = {
        CSSPropertyBackgroundPositionX,
        CSSPropertyBackgroundPositionY,
    };
    DEFINE_STATIC_LOCAL(StylePropertyShorthand, backgroundPositionLonghands, (CSSPropertyBackgroundPosition, backgroundPositionProperties, WTF_ARRAY_LENGTH(backgroundPositionProperties)));
    return backgroundPositionLonghands;
}

const StylePropertyShorthand& borderShorthand()
{
    static const CSSPropertyID borderProperties[] = {
        CSSPropertyBorderTopColor,
        CSSPropertyBorderTopStyle,
        CSSPropertyBorderTopWidth,
        CSSPropertyBorderRightColor,
        CSSPropertyBorderRightStyle,
        CSSPropertyBorderRightWidth,
        CSSPropertyBorderBottomColor,
        CSSPropertyBorderBottomStyle,
        CSSPropertyBorderBottomWidth,
        CSSPropertyBorderLeftColor,
        CSSPropertyBorderLeftStyle,
        CSSPropertyBorderLeftWidth,
    };
    DEFINE_STATIC_LOCAL(StylePropertyShorthand, borderLonghands, (CSSPropertyBorder, borderProperties, WTF_ARRAY_LENGTH(borderProperties)));
    return borderLonghands;
}

const StylePropertyShorthand& borderBottomShorthand()
{
    static const CSSPropertyID borderBottomProperties[] = {
        CSSPropertyBorderBottomWidth,
        CSSPropertyBorderBottomStyle,
        CSSPropertyBorderBottomColor,
    };
    DEFINE_STATIC_LOCAL(StylePropertyShorthand, borderBottomLonghands, (CSSPropertyBorderBottom, borderBottomProperties, WTF_ARRAY_LENGTH(borderBottomProperties)));
    return borderBottomLonghands;
}

const StylePropertyShorthand& gridRowShorthand()
{
    static const CSSPropertyID gridRowProperties[] = {
        CSSPropertyGridRowStart,
        CSSPropertyGridRowEnd,
    };
    DEFINE_STATIC_LOCAL(StylePropertyShorthand, gridRowLonghands, (CSSPropertyGridRow, gridRowProperties, WTF_ARRAY_LENGTH(gridRowProperties)));
    return gridRowLonghands;
}

const StylePropertyShorthand& widthShorthand()
{
    static const CSSPropertyID widthProperties[] = {
        CSSPropertyMinWidth,
        CSSPropertyMaxWidth,
    };
    DEFINE_STATIC_LOCAL(StylePropertyShorthand, widthLonghands, (CSSPropertyWidth, widthProperties, WTF_ARRAY_LENGTH(widthProperties)));
    return widthLonghands;
}

const StylePropertyShorthand& borderRadiusShorthand()
{
    static const CSSPropertyID borderRadiusProperties[] = {
        CSSPropertyBorderTopLeftRadius,
        CSSPropertyBorderTopRightRadius,
        CSSPropertyBorderBottomRightRadius,
        CSSPropertyBorderBottomLeftRadius,
    };
    DEFINE_STATIC_LOCAL(StylePropertyShorthand, borderRadiusLonghands, (CSSPropertyBorderRadius, borderRadiusProperties, WTF_ARRAY_LENGTH(borderRadiusProperties)));
    return borderRadiusLonghands;
}

const StylePropertyShorthand& gridAreaShorthand()
{
    static const CSSPropertyID gridAreaProperties[] = {
        CSSPropertyGridRowStart,
        CSSPropertyGridColumnStart,
        CSSPropertyGridRowEnd,
        CSSPropertyGridColumnEnd,
    };
    DEFINE_STATIC_LOCAL(StylePropertyShorthand, gridAreaLonghands, (CSSPropertyGridArea, gridAreaProperties, WTF_ARRAY_LENGTH(gridAreaProperties)));
    return gridAreaLonghands;
}

const StylePropertyShorthand& webkitColumnRuleShorthand()
{
    static const CSSPropertyID webkitColumnRuleProperties[] = {
        CSSPropertyWebkitColumnRuleWidth,
        CSSPropertyWebkitColumnRuleStyle,
        CSSPropertyWebkitColumnRuleColor,
    };
    DEFINE_STATIC_LOCAL(StylePropertyShorthand, webkitColumnRuleLonghands, (CSSPropertyWebkitColumnRule, webkitColumnRuleProperties, WTF_ARRAY_LENGTH(webkitColumnRuleProperties)));
    return webkitColumnRuleLonghands;
}

const StylePropertyShorthand& borderImageShorthand()
{
    static const CSSPropertyID borderImageProperties[] = {
        CSSPropertyBorderImageSource,
        CSSPropertyBorderImageSlice,
        CSSPropertyBorderImageWidth,
        CSSPropertyBorderImageOutset,
        CSSPropertyBorderImageRepeat,
    };
    DEFINE_STATIC_LOCAL(StylePropertyShorthand, borderImageLonghands, (CSSPropertyBorderImage, borderImageProperties, WTF_ARRAY_LENGTH(borderImageProperties)));
    return borderImageLonghands;
}

// Returns an empty list if the property is not a shorthand
const StylePropertyShorthand& shorthandForProperty(CSSPropertyID propertyID)
{
    DEFINE_STATIC_LOCAL(StylePropertyShorthand, emptyShorthand, ());
    switch (propertyID) {
        case CSSPropertyBackgroundRepeat:
            return backgroundRepeatShorthand();
        case CSSPropertyFlex:
            return flexShorthand();
        case CSSPropertyBorderStyle:
            return borderStyleShorthand();
        case CSSPropertyFlexFlow:
            return flexFlowShorthand();
        case CSSPropertyWebkitMarquee:
            return webkitMarqueeShorthand();
        case CSSPropertyOutline:
            return outlineShorthand();
        case CSSPropertyWebkitColumns:
            return webkitColumnsShorthand();
        case CSSPropertyOverflow:
            return overflowShorthand();
        case CSSPropertyWebkitTextStroke:
            return webkitTextStrokeShorthand();
        case CSSPropertyWebkitBorderRadius:
            return webkitBorderRadiusShorthand();
        case CSSPropertyGridColumn:
            return gridColumnShorthand();
        case CSSPropertyWebkitTransition:
            return webkitTransitionShorthand();
        case CSSPropertyWebkitMarginCollapse:
            return webkitMarginCollapseShorthand();
        case CSSPropertyMargin:
            return marginShorthand();
        case CSSPropertyWebkitTextEmphasis:
            return webkitTextEmphasisShorthand();
        case CSSPropertyBorderSpacing:
            return borderSpacingShorthand();
        case CSSPropertyBorderRight:
            return borderRightShorthand();
        case CSSPropertyBackground:
            return backgroundShorthand();
        case CSSPropertyWebkitMaskRepeat:
            return webkitMaskRepeatShorthand();
        case CSSPropertyWebkitBorderEnd:
            return webkitBorderEndShorthand();
        case CSSPropertyBorderTop:
            return borderTopShorthand();
        case CSSPropertyWebkitBorderAfter:
            return webkitBorderAfterShorthand();
        case CSSPropertyFont:
            return fontShorthand();
        case CSSPropertyWebkitTransformOrigin:
            return webkitTransformOriginShorthand();
        case CSSPropertyWebkitBorderBefore:
            return webkitBorderBeforeShorthand();
        case CSSPropertyPadding:
            return paddingShorthand();
        case CSSPropertyWebkitMaskPosition:
            return webkitMaskPositionShorthand();
        case CSSPropertyBorderLeft:
            return borderLeftShorthand();
        case CSSPropertyWebkitMask:
            return webkitMaskShorthand();
        case CSSPropertyListStyle:
            return listStyleShorthand();
        case CSSPropertyWebkitBorderStart:
            return webkitBorderStartShorthand();
        case CSSPropertyTransition:
            return transitionShorthand();
        case CSSPropertyBorderColor:
            return borderColorShorthand();
        case CSSPropertyBorderWidth:
            return borderWidthShorthand();
        case CSSPropertyWebkitAnimation:
            return webkitAnimationShorthand();
        case CSSPropertyBackgroundPosition:
            return backgroundPositionShorthand();
        case CSSPropertyBorder:
            return borderShorthand();
        case CSSPropertyBorderBottom:
            return borderBottomShorthand();
        case CSSPropertyGridRow:
            return gridRowShorthand();
        case CSSPropertyBorderRadius:
            return borderRadiusShorthand();
        case CSSPropertyGridArea:
            return gridAreaShorthand();
        case CSSPropertyWebkitColumnRule:
            return webkitColumnRuleShorthand();
        case CSSPropertyBorderImage:
            return borderImageShorthand();
    default: {
        return emptyShorthand;
    }
    }
}

typedef HashMap<CSSPropertyID, Vector<StylePropertyShorthand> > longhandsMap;
const Vector<StylePropertyShorthand> matchingShorthandsForLonghand(CSSPropertyID propertyID)
{
    DEFINE_STATIC_LOCAL(longhandsMap, map, ());
    if (map.isEmpty()) {

        Vector<StylePropertyShorthand, 1> CSSPropertyWebkitBorderEndColorShorthands;
        CSSPropertyWebkitBorderEndColorShorthands.uncheckedAppend(webkitBorderEndShorthand());
        map.set(CSSPropertyWebkitBorderEndColor, CSSPropertyWebkitBorderEndColorShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyFlexWrapShorthands;
        CSSPropertyFlexWrapShorthands.uncheckedAppend(flexFlowShorthand());
        map.set(CSSPropertyFlexWrap, CSSPropertyFlexWrapShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyWebkitBorderHorizontalSpacingShorthands;
        CSSPropertyWebkitBorderHorizontalSpacingShorthands.uncheckedAppend(borderSpacingShorthand());
        map.set(CSSPropertyWebkitBorderHorizontalSpacing, CSSPropertyWebkitBorderHorizontalSpacingShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyWebkitAnimationFillModeShorthands;
        CSSPropertyWebkitAnimationFillModeShorthands.uncheckedAppend(webkitAnimationShorthand());
        map.set(CSSPropertyWebkitAnimationFillMode, CSSPropertyWebkitAnimationFillModeShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyWebkitBorderEndWidthShorthands;
        CSSPropertyWebkitBorderEndWidthShorthands.uncheckedAppend(webkitBorderEndShorthand());
        map.set(CSSPropertyWebkitBorderEndWidth, CSSPropertyWebkitBorderEndWidthShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyFlexBasisShorthands;
        CSSPropertyFlexBasisShorthands.uncheckedAppend(flexShorthand());
        map.set(CSSPropertyFlexBasis, CSSPropertyFlexBasisShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyWebkitMarqueeSpeedShorthands;
        CSSPropertyWebkitMarqueeSpeedShorthands.uncheckedAppend(webkitMarqueeShorthand());
        map.set(CSSPropertyWebkitMarqueeSpeed, CSSPropertyWebkitMarqueeSpeedShorthands);

        Vector<StylePropertyShorthand, 3> CSSPropertyBorderLeftColorShorthands;
        CSSPropertyBorderLeftColorShorthands.uncheckedAppend(borderShorthand());
        CSSPropertyBorderLeftColorShorthands.uncheckedAppend(borderColorShorthand());
        CSSPropertyBorderLeftColorShorthands.uncheckedAppend(borderLeftShorthand());
        map.set(CSSPropertyBorderLeftColor, CSSPropertyBorderLeftColorShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyWebkitAnimationDelayShorthands;
        CSSPropertyWebkitAnimationDelayShorthands.uncheckedAppend(webkitAnimationShorthand());
        map.set(CSSPropertyWebkitAnimationDelay, CSSPropertyWebkitAnimationDelayShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyWebkitBorderBeforeStyleShorthands;
        CSSPropertyWebkitBorderBeforeStyleShorthands.uncheckedAppend(webkitBorderBeforeShorthand());
        map.set(CSSPropertyWebkitBorderBeforeStyle, CSSPropertyWebkitBorderBeforeStyleShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyMaxHeightShorthands;
        CSSPropertyMaxHeightShorthands.uncheckedAppend(heightShorthand());
        map.set(CSSPropertyMaxHeight, CSSPropertyMaxHeightShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyWebkitBorderStartColorShorthands;
        CSSPropertyWebkitBorderStartColorShorthands.uncheckedAppend(webkitBorderStartShorthand());
        map.set(CSSPropertyWebkitBorderStartColor, CSSPropertyWebkitBorderStartColorShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyFlexShrinkShorthands;
        CSSPropertyFlexShrinkShorthands.uncheckedAppend(flexShorthand());
        map.set(CSSPropertyFlexShrink, CSSPropertyFlexShrinkShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyTransitionDelayShorthands;
        CSSPropertyTransitionDelayShorthands.uncheckedAppend(transitionShorthand());
        map.set(CSSPropertyTransitionDelay, CSSPropertyTransitionDelayShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyWebkitTransformOriginXShorthands;
        CSSPropertyWebkitTransformOriginXShorthands.uncheckedAppend(webkitTransformOriginShorthand());
        map.set(CSSPropertyWebkitTransformOriginX, CSSPropertyWebkitTransformOriginXShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyPaddingLeftShorthands;
        CSSPropertyPaddingLeftShorthands.uncheckedAppend(paddingShorthand());
        map.set(CSSPropertyPaddingLeft, CSSPropertyPaddingLeftShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyBackgroundClipShorthands;
        CSSPropertyBackgroundClipShorthands.uncheckedAppend(backgroundShorthand());
        map.set(CSSPropertyBackgroundClip, CSSPropertyBackgroundClipShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyWebkitBorderEndStyleShorthands;
        CSSPropertyWebkitBorderEndStyleShorthands.uncheckedAppend(webkitBorderEndShorthand());
        map.set(CSSPropertyWebkitBorderEndStyle, CSSPropertyWebkitBorderEndStyleShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyWebkitTransitionDelayShorthands;
        CSSPropertyWebkitTransitionDelayShorthands.uncheckedAppend(webkitTransitionShorthand());
        map.set(CSSPropertyWebkitTransitionDelay, CSSPropertyWebkitTransitionDelayShorthands);

        Vector<StylePropertyShorthand, 2> CSSPropertyBackgroundPositionYShorthands;
        CSSPropertyBackgroundPositionYShorthands.uncheckedAppend(backgroundShorthand());
        CSSPropertyBackgroundPositionYShorthands.uncheckedAppend(backgroundPositionShorthand());
        map.set(CSSPropertyBackgroundPositionY, CSSPropertyBackgroundPositionYShorthands);

        Vector<StylePropertyShorthand, 2> CSSPropertyBackgroundPositionXShorthands;
        CSSPropertyBackgroundPositionXShorthands.uncheckedAppend(backgroundShorthand());
        CSSPropertyBackgroundPositionXShorthands.uncheckedAppend(backgroundPositionShorthand());
        map.set(CSSPropertyBackgroundPositionX, CSSPropertyBackgroundPositionXShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyWebkitColumnCountShorthands;
        CSSPropertyWebkitColumnCountShorthands.uncheckedAppend(webkitColumnsShorthand());
        map.set(CSSPropertyWebkitColumnCount, CSSPropertyWebkitColumnCountShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyWebkitMarginAfterCollapseShorthands;
        CSSPropertyWebkitMarginAfterCollapseShorthands.uncheckedAppend(webkitMarginCollapseShorthand());
        map.set(CSSPropertyWebkitMarginAfterCollapse, CSSPropertyWebkitMarginAfterCollapseShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyOutlineWidthShorthands;
        CSSPropertyOutlineWidthShorthands.uncheckedAppend(outlineShorthand());
        map.set(CSSPropertyOutlineWidth, CSSPropertyOutlineWidthShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyWebkitMaskOriginShorthands;
        CSSPropertyWebkitMaskOriginShorthands.uncheckedAppend(webkitMaskShorthand());
        map.set(CSSPropertyWebkitMaskOrigin, CSSPropertyWebkitMaskOriginShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyOutlineStyleShorthands;
        CSSPropertyOutlineStyleShorthands.uncheckedAppend(outlineShorthand());
        map.set(CSSPropertyOutlineStyle, CSSPropertyOutlineStyleShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyWebkitTransitionPropertyShorthands;
        CSSPropertyWebkitTransitionPropertyShorthands.uncheckedAppend(webkitTransitionShorthand());
        map.set(CSSPropertyWebkitTransitionProperty, CSSPropertyWebkitTransitionPropertyShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyWebkitAnimationNameShorthands;
        CSSPropertyWebkitAnimationNameShorthands.uncheckedAppend(webkitAnimationShorthand());
        map.set(CSSPropertyWebkitAnimationName, CSSPropertyWebkitAnimationNameShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyMarkerEndShorthands;
        CSSPropertyMarkerEndShorthands.uncheckedAppend(markerShorthand());
        map.set(CSSPropertyMarkerEnd, CSSPropertyMarkerEndShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyBackgroundOriginShorthands;
        CSSPropertyBackgroundOriginShorthands.uncheckedAppend(backgroundShorthand());
        map.set(CSSPropertyBackgroundOrigin, CSSPropertyBackgroundOriginShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyWebkitColumnRuleStyleShorthands;
        CSSPropertyWebkitColumnRuleStyleShorthands.uncheckedAppend(webkitColumnRuleShorthand());
        map.set(CSSPropertyWebkitColumnRuleStyle, CSSPropertyWebkitColumnRuleStyleShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyWebkitColumnWidthShorthands;
        CSSPropertyWebkitColumnWidthShorthands.uncheckedAppend(webkitColumnsShorthand());
        map.set(CSSPropertyWebkitColumnWidth, CSSPropertyWebkitColumnWidthShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyWebkitMarqueeRepetitionShorthands;
        CSSPropertyWebkitMarqueeRepetitionShorthands.uncheckedAppend(webkitMarqueeShorthand());
        map.set(CSSPropertyWebkitMarqueeRepetition, CSSPropertyWebkitMarqueeRepetitionShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyWebkitMarqueeDirectionShorthands;
        CSSPropertyWebkitMarqueeDirectionShorthands.uncheckedAppend(webkitMarqueeShorthand());
        map.set(CSSPropertyWebkitMarqueeDirection, CSSPropertyWebkitMarqueeDirectionShorthands);

        Vector<StylePropertyShorthand, 3> CSSPropertyBorderRightColorShorthands;
        CSSPropertyBorderRightColorShorthands.uncheckedAppend(borderShorthand());
        CSSPropertyBorderRightColorShorthands.uncheckedAppend(borderColorShorthand());
        CSSPropertyBorderRightColorShorthands.uncheckedAppend(borderRightShorthand());
        map.set(CSSPropertyBorderRightColor, CSSPropertyBorderRightColorShorthands);

        Vector<StylePropertyShorthand, 3> CSSPropertyBorderBottomStyleShorthands;
        CSSPropertyBorderBottomStyleShorthands.uncheckedAppend(borderShorthand());
        CSSPropertyBorderBottomStyleShorthands.uncheckedAppend(borderBottomShorthand());
        CSSPropertyBorderBottomStyleShorthands.uncheckedAppend(borderStyleShorthand());
        map.set(CSSPropertyBorderBottomStyle, CSSPropertyBorderBottomStyleShorthands);

        Vector<StylePropertyShorthand, 3> CSSPropertyBorderBottomWidthShorthands;
        CSSPropertyBorderBottomWidthShorthands.uncheckedAppend(borderShorthand());
        CSSPropertyBorderBottomWidthShorthands.uncheckedAppend(borderBottomShorthand());
        CSSPropertyBorderBottomWidthShorthands.uncheckedAppend(borderWidthShorthand());
        map.set(CSSPropertyBorderBottomWidth, CSSPropertyBorderBottomWidthShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyMinHeightShorthands;
        CSSPropertyMinHeightShorthands.uncheckedAppend(heightShorthand());
        map.set(CSSPropertyMinHeight, CSSPropertyMinHeightShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyFontStyleShorthands;
        CSSPropertyFontStyleShorthands.uncheckedAppend(fontShorthand());
        map.set(CSSPropertyFontStyle, CSSPropertyFontStyleShorthands);

        Vector<StylePropertyShorthand, 3> CSSPropertyBorderRightStyleShorthands;
        CSSPropertyBorderRightStyleShorthands.uncheckedAppend(borderShorthand());
        CSSPropertyBorderRightStyleShorthands.uncheckedAppend(borderRightShorthand());
        CSSPropertyBorderRightStyleShorthands.uncheckedAppend(borderStyleShorthand());
        map.set(CSSPropertyBorderRightStyle, CSSPropertyBorderRightStyleShorthands);

        Vector<StylePropertyShorthand, 2> CSSPropertyBorderBottomRightRadiusShorthands;
        CSSPropertyBorderBottomRightRadiusShorthands.uncheckedAppend(borderRadiusShorthand());
        CSSPropertyBorderBottomRightRadiusShorthands.uncheckedAppend(webkitBorderRadiusShorthand());
        map.set(CSSPropertyBorderBottomRightRadius, CSSPropertyBorderBottomRightRadiusShorthands);

        Vector<StylePropertyShorthand, 3> CSSPropertyBorderRightWidthShorthands;
        CSSPropertyBorderRightWidthShorthands.uncheckedAppend(borderShorthand());
        CSSPropertyBorderRightWidthShorthands.uncheckedAppend(borderRightShorthand());
        CSSPropertyBorderRightWidthShorthands.uncheckedAppend(borderWidthShorthand());
        map.set(CSSPropertyBorderRightWidth, CSSPropertyBorderRightWidthShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyWebkitBorderAfterStyleShorthands;
        CSSPropertyWebkitBorderAfterStyleShorthands.uncheckedAppend(webkitBorderAfterShorthand());
        map.set(CSSPropertyWebkitBorderAfterStyle, CSSPropertyWebkitBorderAfterStyleShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyBorderImageSourceShorthands;
        CSSPropertyBorderImageSourceShorthands.uncheckedAppend(borderImageShorthand());
        map.set(CSSPropertyBorderImageSource, CSSPropertyBorderImageSourceShorthands);

        Vector<StylePropertyShorthand, 2> CSSPropertyBorderTopLeftRadiusShorthands;
        CSSPropertyBorderTopLeftRadiusShorthands.uncheckedAppend(borderRadiusShorthand());
        CSSPropertyBorderTopLeftRadiusShorthands.uncheckedAppend(webkitBorderRadiusShorthand());
        map.set(CSSPropertyBorderTopLeftRadius, CSSPropertyBorderTopLeftRadiusShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyWebkitAnimationTimingFunctionShorthands;
        CSSPropertyWebkitAnimationTimingFunctionShorthands.uncheckedAppend(webkitAnimationShorthand());
        map.set(CSSPropertyWebkitAnimationTimingFunction, CSSPropertyWebkitAnimationTimingFunctionShorthands);

        Vector<StylePropertyShorthand, 2> CSSPropertyBorderBottomLeftRadiusShorthands;
        CSSPropertyBorderBottomLeftRadiusShorthands.uncheckedAppend(borderRadiusShorthand());
        CSSPropertyBorderBottomLeftRadiusShorthands.uncheckedAppend(webkitBorderRadiusShorthand());
        map.set(CSSPropertyBorderBottomLeftRadius, CSSPropertyBorderBottomLeftRadiusShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyFontVariantShorthands;
        CSSPropertyFontVariantShorthands.uncheckedAppend(fontShorthand());
        map.set(CSSPropertyFontVariant, CSSPropertyFontVariantShorthands);

        Vector<StylePropertyShorthand, 2> CSSPropertyGridRowEndShorthands;
        CSSPropertyGridRowEndShorthands.uncheckedAppend(gridAreaShorthand());
        CSSPropertyGridRowEndShorthands.uncheckedAppend(gridRowShorthand());
        map.set(CSSPropertyGridRowEnd, CSSPropertyGridRowEndShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyBackgroundAttachmentShorthands;
        CSSPropertyBackgroundAttachmentShorthands.uncheckedAppend(backgroundShorthand());
        map.set(CSSPropertyBackgroundAttachment, CSSPropertyBackgroundAttachmentShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyMinWidthShorthands;
        CSSPropertyMinWidthShorthands.uncheckedAppend(widthShorthand());
        map.set(CSSPropertyMinWidth, CSSPropertyMinWidthShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyWebkitAnimationDirectionShorthands;
        CSSPropertyWebkitAnimationDirectionShorthands.uncheckedAppend(webkitAnimationShorthand());
        map.set(CSSPropertyWebkitAnimationDirection, CSSPropertyWebkitAnimationDirectionShorthands);

        Vector<StylePropertyShorthand, 3> CSSPropertyBorderLeftWidthShorthands;
        CSSPropertyBorderLeftWidthShorthands.uncheckedAppend(borderShorthand());
        CSSPropertyBorderLeftWidthShorthands.uncheckedAppend(borderLeftShorthand());
        CSSPropertyBorderLeftWidthShorthands.uncheckedAppend(borderWidthShorthand());
        map.set(CSSPropertyBorderLeftWidth, CSSPropertyBorderLeftWidthShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyPaddingBottomShorthands;
        CSSPropertyPaddingBottomShorthands.uncheckedAppend(paddingShorthand());
        map.set(CSSPropertyPaddingBottom, CSSPropertyPaddingBottomShorthands);

        Vector<StylePropertyShorthand, 2> CSSPropertyWebkitMaskPositionXShorthands;
        CSSPropertyWebkitMaskPositionXShorthands.uncheckedAppend(webkitMaskShorthand());
        CSSPropertyWebkitMaskPositionXShorthands.uncheckedAppend(webkitMaskPositionShorthand());
        map.set(CSSPropertyWebkitMaskPositionX, CSSPropertyWebkitMaskPositionXShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyMarkerStartShorthands;
        CSSPropertyMarkerStartShorthands.uncheckedAppend(markerShorthand());
        map.set(CSSPropertyMarkerStart, CSSPropertyMarkerStartShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyWebkitMarqueeIncrementShorthands;
        CSSPropertyWebkitMarqueeIncrementShorthands.uncheckedAppend(webkitMarqueeShorthand());
        map.set(CSSPropertyWebkitMarqueeIncrement, CSSPropertyWebkitMarqueeIncrementShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyBackgroundImageShorthands;
        CSSPropertyBackgroundImageShorthands.uncheckedAppend(backgroundShorthand());
        map.set(CSSPropertyBackgroundImage, CSSPropertyBackgroundImageShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyWebkitBorderAfterColorShorthands;
        CSSPropertyWebkitBorderAfterColorShorthands.uncheckedAppend(webkitBorderAfterShorthand());
        map.set(CSSPropertyWebkitBorderAfterColor, CSSPropertyWebkitBorderAfterColorShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyWebkitMaskClipShorthands;
        CSSPropertyWebkitMaskClipShorthands.uncheckedAppend(webkitMaskShorthand());
        map.set(CSSPropertyWebkitMaskClip, CSSPropertyWebkitMaskClipShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyBorderImageSliceShorthands;
        CSSPropertyBorderImageSliceShorthands.uncheckedAppend(borderImageShorthand());
        map.set(CSSPropertyBorderImageSlice, CSSPropertyBorderImageSliceShorthands);

        Vector<StylePropertyShorthand, 2> CSSPropertyBackgroundRepeatXShorthands;
        CSSPropertyBackgroundRepeatXShorthands.uncheckedAppend(backgroundShorthand());
        CSSPropertyBackgroundRepeatXShorthands.uncheckedAppend(backgroundRepeatShorthand());
        map.set(CSSPropertyBackgroundRepeatX, CSSPropertyBackgroundRepeatXShorthands);

        Vector<StylePropertyShorthand, 3> CSSPropertyBorderTopColorShorthands;
        CSSPropertyBorderTopColorShorthands.uncheckedAppend(borderShorthand());
        CSSPropertyBorderTopColorShorthands.uncheckedAppend(borderColorShorthand());
        CSSPropertyBorderTopColorShorthands.uncheckedAppend(borderTopShorthand());
        map.set(CSSPropertyBorderTopColor, CSSPropertyBorderTopColorShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyWebkitAnimationIterationCountShorthands;
        CSSPropertyWebkitAnimationIterationCountShorthands.uncheckedAppend(webkitAnimationShorthand());
        map.set(CSSPropertyWebkitAnimationIterationCount, CSSPropertyWebkitAnimationIterationCountShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyBackgroundColorShorthands;
        CSSPropertyBackgroundColorShorthands.uncheckedAppend(backgroundShorthand());
        map.set(CSSPropertyBackgroundColor, CSSPropertyBackgroundColorShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyOutlineColorShorthands;
        CSSPropertyOutlineColorShorthands.uncheckedAppend(outlineShorthand());
        map.set(CSSPropertyOutlineColor, CSSPropertyOutlineColorShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyPaddingTopShorthands;
        CSSPropertyPaddingTopShorthands.uncheckedAppend(paddingShorthand());
        map.set(CSSPropertyPaddingTop, CSSPropertyPaddingTopShorthands);

        Vector<StylePropertyShorthand, 3> CSSPropertyBorderTopWidthShorthands;
        CSSPropertyBorderTopWidthShorthands.uncheckedAppend(borderShorthand());
        CSSPropertyBorderTopWidthShorthands.uncheckedAppend(borderTopShorthand());
        CSSPropertyBorderTopWidthShorthands.uncheckedAppend(borderWidthShorthand());
        map.set(CSSPropertyBorderTopWidth, CSSPropertyBorderTopWidthShorthands);

        Vector<StylePropertyShorthand, 2> CSSPropertyGridColumnStartShorthands;
        CSSPropertyGridColumnStartShorthands.uncheckedAppend(gridAreaShorthand());
        CSSPropertyGridColumnStartShorthands.uncheckedAppend(gridColumnShorthand());
        map.set(CSSPropertyGridColumnStart, CSSPropertyGridColumnStartShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyWebkitTransitionTimingFunctionShorthands;
        CSSPropertyWebkitTransitionTimingFunctionShorthands.uncheckedAppend(webkitTransitionShorthand());
        map.set(CSSPropertyWebkitTransitionTimingFunction, CSSPropertyWebkitTransitionTimingFunctionShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyMarginBottomShorthands;
        CSSPropertyMarginBottomShorthands.uncheckedAppend(marginShorthand());
        map.set(CSSPropertyMarginBottom, CSSPropertyMarginBottomShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyListStylePositionShorthands;
        CSSPropertyListStylePositionShorthands.uncheckedAppend(listStyleShorthand());
        map.set(CSSPropertyListStylePosition, CSSPropertyListStylePositionShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyWebkitAnimationDurationShorthands;
        CSSPropertyWebkitAnimationDurationShorthands.uncheckedAppend(webkitAnimationShorthand());
        map.set(CSSPropertyWebkitAnimationDuration, CSSPropertyWebkitAnimationDurationShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyWebkitTextEmphasisColorShorthands;
        CSSPropertyWebkitTextEmphasisColorShorthands.uncheckedAppend(webkitTextEmphasisShorthand());
        map.set(CSSPropertyWebkitTextEmphasisColor, CSSPropertyWebkitTextEmphasisColorShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyWebkitTransitionDurationShorthands;
        CSSPropertyWebkitTransitionDurationShorthands.uncheckedAppend(webkitTransitionShorthand());
        map.set(CSSPropertyWebkitTransitionDuration, CSSPropertyWebkitTransitionDurationShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyWebkitTextEmphasisStyleShorthands;
        CSSPropertyWebkitTextEmphasisStyleShorthands.uncheckedAppend(webkitTextEmphasisShorthand());
        map.set(CSSPropertyWebkitTextEmphasisStyle, CSSPropertyWebkitTextEmphasisStyleShorthands);

        Vector<StylePropertyShorthand, 2> CSSPropertyWebkitMaskPositionYShorthands;
        CSSPropertyWebkitMaskPositionYShorthands.uncheckedAppend(webkitMaskShorthand());
        CSSPropertyWebkitMaskPositionYShorthands.uncheckedAppend(webkitMaskPositionShorthand());
        map.set(CSSPropertyWebkitMaskPositionY, CSSPropertyWebkitMaskPositionYShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyWebkitMaskSizeShorthands;
        CSSPropertyWebkitMaskSizeShorthands.uncheckedAppend(webkitMaskShorthand());
        map.set(CSSPropertyWebkitMaskSize, CSSPropertyWebkitMaskSizeShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyMarginTopShorthands;
        CSSPropertyMarginTopShorthands.uncheckedAppend(marginShorthand());
        map.set(CSSPropertyMarginTop, CSSPropertyMarginTopShorthands);

        Vector<StylePropertyShorthand, 3> CSSPropertyBorderTopStyleShorthands;
        CSSPropertyBorderTopStyleShorthands.uncheckedAppend(borderShorthand());
        CSSPropertyBorderTopStyleShorthands.uncheckedAppend(borderStyleShorthand());
        CSSPropertyBorderTopStyleShorthands.uncheckedAppend(borderTopShorthand());
        map.set(CSSPropertyBorderTopStyle, CSSPropertyBorderTopStyleShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyWebkitMarqueeStyleShorthands;
        CSSPropertyWebkitMarqueeStyleShorthands.uncheckedAppend(webkitMarqueeShorthand());
        map.set(CSSPropertyWebkitMarqueeStyle, CSSPropertyWebkitMarqueeStyleShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyWebkitBorderBeforeWidthShorthands;
        CSSPropertyWebkitBorderBeforeWidthShorthands.uncheckedAppend(webkitBorderBeforeShorthand());
        map.set(CSSPropertyWebkitBorderBeforeWidth, CSSPropertyWebkitBorderBeforeWidthShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyMaxWidthShorthands;
        CSSPropertyMaxWidthShorthands.uncheckedAppend(widthShorthand());
        map.set(CSSPropertyMaxWidth, CSSPropertyMaxWidthShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyBorderImageOutsetShorthands;
        CSSPropertyBorderImageOutsetShorthands.uncheckedAppend(borderImageShorthand());
        map.set(CSSPropertyBorderImageOutset, CSSPropertyBorderImageOutsetShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyFontFamilyShorthands;
        CSSPropertyFontFamilyShorthands.uncheckedAppend(fontShorthand());
        map.set(CSSPropertyFontFamily, CSSPropertyFontFamilyShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyBorderImageWidthShorthands;
        CSSPropertyBorderImageWidthShorthands.uncheckedAppend(borderImageShorthand());
        map.set(CSSPropertyBorderImageWidth, CSSPropertyBorderImageWidthShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyFlexGrowShorthands;
        CSSPropertyFlexGrowShorthands.uncheckedAppend(flexShorthand());
        map.set(CSSPropertyFlexGrow, CSSPropertyFlexGrowShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyWebkitBorderBeforeColorShorthands;
        CSSPropertyWebkitBorderBeforeColorShorthands.uncheckedAppend(webkitBorderBeforeShorthand());
        map.set(CSSPropertyWebkitBorderBeforeColor, CSSPropertyWebkitBorderBeforeColorShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyListStyleImageShorthands;
        CSSPropertyListStyleImageShorthands.uncheckedAppend(listStyleShorthand());
        map.set(CSSPropertyListStyleImage, CSSPropertyListStyleImageShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyWebkitMarginBeforeCollapseShorthands;
        CSSPropertyWebkitMarginBeforeCollapseShorthands.uncheckedAppend(webkitMarginCollapseShorthand());
        map.set(CSSPropertyWebkitMarginBeforeCollapse, CSSPropertyWebkitMarginBeforeCollapseShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyWebkitMaskImageShorthands;
        CSSPropertyWebkitMaskImageShorthands.uncheckedAppend(webkitMaskShorthand());
        map.set(CSSPropertyWebkitMaskImage, CSSPropertyWebkitMaskImageShorthands);

        Vector<StylePropertyShorthand, 2> CSSPropertyBorderTopRightRadiusShorthands;
        CSSPropertyBorderTopRightRadiusShorthands.uncheckedAppend(borderRadiusShorthand());
        CSSPropertyBorderTopRightRadiusShorthands.uncheckedAppend(webkitBorderRadiusShorthand());
        map.set(CSSPropertyBorderTopRightRadius, CSSPropertyBorderTopRightRadiusShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyWebkitColumnRuleWidthShorthands;
        CSSPropertyWebkitColumnRuleWidthShorthands.uncheckedAppend(webkitColumnRuleShorthand());
        map.set(CSSPropertyWebkitColumnRuleWidth, CSSPropertyWebkitColumnRuleWidthShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyFlexDirectionShorthands;
        CSSPropertyFlexDirectionShorthands.uncheckedAppend(flexFlowShorthand());
        map.set(CSSPropertyFlexDirection, CSSPropertyFlexDirectionShorthands);

        Vector<StylePropertyShorthand, 2> CSSPropertyWebkitMaskRepeatYShorthands;
        CSSPropertyWebkitMaskRepeatYShorthands.uncheckedAppend(webkitMaskShorthand());
        CSSPropertyWebkitMaskRepeatYShorthands.uncheckedAppend(webkitMaskRepeatShorthand());
        map.set(CSSPropertyWebkitMaskRepeatY, CSSPropertyWebkitMaskRepeatYShorthands);

        Vector<StylePropertyShorthand, 2> CSSPropertyWebkitMaskRepeatXShorthands;
        CSSPropertyWebkitMaskRepeatXShorthands.uncheckedAppend(webkitMaskShorthand());
        CSSPropertyWebkitMaskRepeatXShorthands.uncheckedAppend(webkitMaskRepeatShorthand());
        map.set(CSSPropertyWebkitMaskRepeatX, CSSPropertyWebkitMaskRepeatXShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyBorderImageRepeatShorthands;
        CSSPropertyBorderImageRepeatShorthands.uncheckedAppend(borderImageShorthand());
        map.set(CSSPropertyBorderImageRepeat, CSSPropertyBorderImageRepeatShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyWebkitBorderStartStyleShorthands;
        CSSPropertyWebkitBorderStartStyleShorthands.uncheckedAppend(webkitBorderStartShorthand());
        map.set(CSSPropertyWebkitBorderStartStyle, CSSPropertyWebkitBorderStartStyleShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyListStyleTypeShorthands;
        CSSPropertyListStyleTypeShorthands.uncheckedAppend(listStyleShorthand());
        map.set(CSSPropertyListStyleType, CSSPropertyListStyleTypeShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyOverflowXShorthands;
        CSSPropertyOverflowXShorthands.uncheckedAppend(overflowShorthand());
        map.set(CSSPropertyOverflowX, CSSPropertyOverflowXShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyFontWeightShorthands;
        CSSPropertyFontWeightShorthands.uncheckedAppend(fontShorthand());
        map.set(CSSPropertyFontWeight, CSSPropertyFontWeightShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyTransitionTimingFunctionShorthands;
        CSSPropertyTransitionTimingFunctionShorthands.uncheckedAppend(transitionShorthand());
        map.set(CSSPropertyTransitionTimingFunction, CSSPropertyTransitionTimingFunctionShorthands);

        Vector<StylePropertyShorthand, 3> CSSPropertyBorderLeftStyleShorthands;
        CSSPropertyBorderLeftStyleShorthands.uncheckedAppend(borderShorthand());
        CSSPropertyBorderLeftStyleShorthands.uncheckedAppend(borderLeftShorthand());
        CSSPropertyBorderLeftStyleShorthands.uncheckedAppend(borderStyleShorthand());
        map.set(CSSPropertyBorderLeftStyle, CSSPropertyBorderLeftStyleShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyOverflowYShorthands;
        CSSPropertyOverflowYShorthands.uncheckedAppend(overflowShorthand());
        map.set(CSSPropertyOverflowY, CSSPropertyOverflowYShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyMarkerMidShorthands;
        CSSPropertyMarkerMidShorthands.uncheckedAppend(markerShorthand());
        map.set(CSSPropertyMarkerMid, CSSPropertyMarkerMidShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyMarginRightShorthands;
        CSSPropertyMarginRightShorthands.uncheckedAppend(marginShorthand());
        map.set(CSSPropertyMarginRight, CSSPropertyMarginRightShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyWebkitBorderStartWidthShorthands;
        CSSPropertyWebkitBorderStartWidthShorthands.uncheckedAppend(webkitBorderStartShorthand());
        map.set(CSSPropertyWebkitBorderStartWidth, CSSPropertyWebkitBorderStartWidthShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyWebkitColumnRuleColorShorthands;
        CSSPropertyWebkitColumnRuleColorShorthands.uncheckedAppend(webkitColumnRuleShorthand());
        map.set(CSSPropertyWebkitColumnRuleColor, CSSPropertyWebkitColumnRuleColorShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyWebkitTransformOriginZShorthands;
        CSSPropertyWebkitTransformOriginZShorthands.uncheckedAppend(webkitTransformOriginShorthand());
        map.set(CSSPropertyWebkitTransformOriginZ, CSSPropertyWebkitTransformOriginZShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyWebkitTransformOriginYShorthands;
        CSSPropertyWebkitTransformOriginYShorthands.uncheckedAppend(webkitTransformOriginShorthand());
        map.set(CSSPropertyWebkitTransformOriginY, CSSPropertyWebkitTransformOriginYShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyWebkitTextStrokeColorShorthands;
        CSSPropertyWebkitTextStrokeColorShorthands.uncheckedAppend(webkitTextStrokeShorthand());
        map.set(CSSPropertyWebkitTextStrokeColor, CSSPropertyWebkitTextStrokeColorShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyLineHeightShorthands;
        CSSPropertyLineHeightShorthands.uncheckedAppend(fontShorthand());
        map.set(CSSPropertyLineHeight, CSSPropertyLineHeightShorthands);

        Vector<StylePropertyShorthand, 2> CSSPropertyBackgroundRepeatYShorthands;
        CSSPropertyBackgroundRepeatYShorthands.uncheckedAppend(backgroundShorthand());
        CSSPropertyBackgroundRepeatYShorthands.uncheckedAppend(backgroundRepeatShorthand());
        map.set(CSSPropertyBackgroundRepeatY, CSSPropertyBackgroundRepeatYShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyWebkitBorderAfterWidthShorthands;
        CSSPropertyWebkitBorderAfterWidthShorthands.uncheckedAppend(webkitBorderAfterShorthand());
        map.set(CSSPropertyWebkitBorderAfterWidth, CSSPropertyWebkitBorderAfterWidthShorthands);

        Vector<StylePropertyShorthand, 3> CSSPropertyBorderBottomColorShorthands;
        CSSPropertyBorderBottomColorShorthands.uncheckedAppend(borderShorthand());
        CSSPropertyBorderBottomColorShorthands.uncheckedAppend(borderBottomShorthand());
        CSSPropertyBorderBottomColorShorthands.uncheckedAppend(borderColorShorthand());
        map.set(CSSPropertyBorderBottomColor, CSSPropertyBorderBottomColorShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyFontSizeShorthands;
        CSSPropertyFontSizeShorthands.uncheckedAppend(fontShorthand());
        map.set(CSSPropertyFontSize, CSSPropertyFontSizeShorthands);

        Vector<StylePropertyShorthand, 2> CSSPropertyGridColumnEndShorthands;
        CSSPropertyGridColumnEndShorthands.uncheckedAppend(gridAreaShorthand());
        CSSPropertyGridColumnEndShorthands.uncheckedAppend(gridColumnShorthand());
        map.set(CSSPropertyGridColumnEnd, CSSPropertyGridColumnEndShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyBackgroundSizeShorthands;
        CSSPropertyBackgroundSizeShorthands.uncheckedAppend(backgroundShorthand());
        map.set(CSSPropertyBackgroundSize, CSSPropertyBackgroundSizeShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyPaddingRightShorthands;
        CSSPropertyPaddingRightShorthands.uncheckedAppend(paddingShorthand());
        map.set(CSSPropertyPaddingRight, CSSPropertyPaddingRightShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyWebkitBorderVerticalSpacingShorthands;
        CSSPropertyWebkitBorderVerticalSpacingShorthands.uncheckedAppend(borderSpacingShorthand());
        map.set(CSSPropertyWebkitBorderVerticalSpacing, CSSPropertyWebkitBorderVerticalSpacingShorthands);

        Vector<StylePropertyShorthand, 2> CSSPropertyGridRowStartShorthands;
        CSSPropertyGridRowStartShorthands.uncheckedAppend(gridAreaShorthand());
        CSSPropertyGridRowStartShorthands.uncheckedAppend(gridRowShorthand());
        map.set(CSSPropertyGridRowStart, CSSPropertyGridRowStartShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyTransitionDurationShorthands;
        CSSPropertyTransitionDurationShorthands.uncheckedAppend(transitionShorthand());
        map.set(CSSPropertyTransitionDuration, CSSPropertyTransitionDurationShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyTransitionPropertyShorthands;
        CSSPropertyTransitionPropertyShorthands.uncheckedAppend(transitionShorthand());
        map.set(CSSPropertyTransitionProperty, CSSPropertyTransitionPropertyShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyMarginLeftShorthands;
        CSSPropertyMarginLeftShorthands.uncheckedAppend(marginShorthand());
        map.set(CSSPropertyMarginLeft, CSSPropertyMarginLeftShorthands);

        Vector<StylePropertyShorthand, 1> CSSPropertyWebkitTextStrokeWidthShorthands;
        CSSPropertyWebkitTextStrokeWidthShorthands.uncheckedAppend(webkitTextStrokeShorthand());
        map.set(CSSPropertyWebkitTextStrokeWidth, CSSPropertyWebkitTextStrokeWidthShorthands);
    }
    return map.get(propertyID);
}

} // namespace WebCore

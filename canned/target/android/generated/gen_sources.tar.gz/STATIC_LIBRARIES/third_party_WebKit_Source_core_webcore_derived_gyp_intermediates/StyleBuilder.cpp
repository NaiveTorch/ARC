/*
 * Copyright (C) 2013 Google Inc. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 *
 *     * Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following disclaimer
 * in the documentation and/or other materials provided with the
 * distribution.
 *     * Neither the name of Google Inc. nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "config.h"
#include "core/css/resolver/StyleBuilder.h"

#include "StyleBuilderFunctions.h"
#include "core/css/CSSPrimitiveValueMappings.h"
#include "core/css/resolver/StyleResolverState.h"

// FIXME: currently we're just generating a switch statement, but we should
//   test other variations for performance once we have more properties here.

namespace WebCore {
void StyleBuilderFunctions::applyInitialCSSPropertyWebkitShapeOutside(StyleResolverState& state)
{
    state.style()->setShapeOutside(RenderStyle::initialShapeOutside());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitShapeOutside(StyleResolverState& state)
{
    state.style()->setShapeOutside(state.parentStyle()->shapeOutside());
}

void StyleBuilderFunctions::applyInitialCSSPropertyPosition(StyleResolverState& state)
{
    state.style()->setPosition(RenderStyle::initialPosition());
}

void StyleBuilderFunctions::applyInheritCSSPropertyPosition(StyleResolverState& state)
{
    state.style()->setPosition(state.parentStyle()->position());
}

void StyleBuilderFunctions::applyValueCSSPropertyPosition(StyleResolverState& state, CSSValue* value)
{
    state.style()->setPosition(static_cast<EPosition>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyTextAnchor(StyleResolverState& state)
{
    state.style()->accessSVGStyle()->setTextAnchor(SVGRenderStyle::initialTextAnchor());
}

void StyleBuilderFunctions::applyInheritCSSPropertyTextAnchor(StyleResolverState& state)
{
    state.style()->accessSVGStyle()->setTextAnchor(state.parentStyle()->svgStyle()->textAnchor());
}

void StyleBuilderFunctions::applyValueCSSPropertyTextAnchor(StyleResolverState& state, CSSValue* value)
{
    state.style()->accessSVGStyle()->setTextAnchor(static_cast<ETextAnchor>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyFlexWrap(StyleResolverState& state)
{
    state.style()->setFlexWrap(RenderStyle::initialFlexWrap());
}

void StyleBuilderFunctions::applyInheritCSSPropertyFlexWrap(StyleResolverState& state)
{
    state.style()->setFlexWrap(state.parentStyle()->flexWrap());
}

void StyleBuilderFunctions::applyValueCSSPropertyFlexWrap(StyleResolverState& state, CSSValue* value)
{
    state.style()->setFlexWrap(static_cast<EFlexWrap>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitBorderHorizontalSpacing(StyleResolverState& state)
{
    state.style()->setHorizontalBorderSpacing(RenderStyle::initialHorizontalBorderSpacing());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitBorderHorizontalSpacing(StyleResolverState& state)
{
    state.style()->setHorizontalBorderSpacing(state.parentStyle()->horizontalBorderSpacing());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitBorderHorizontalSpacing(StyleResolverState& state, CSSValue* value)
{
    state.style()->setHorizontalBorderSpacing(StyleBuilderConverter::convertComputedLength<short>(state, value));
}

void StyleBuilderFunctions::applyInitialCSSPropertyFillRule(StyleResolverState& state)
{
    state.style()->accessSVGStyle()->setFillRule(SVGRenderStyle::initialFillRule());
}

void StyleBuilderFunctions::applyInheritCSSPropertyFillRule(StyleResolverState& state)
{
    state.style()->accessSVGStyle()->setFillRule(state.parentStyle()->svgStyle()->fillRule());
}

void StyleBuilderFunctions::applyValueCSSPropertyFillRule(StyleResolverState& state, CSSValue* value)
{
    state.style()->accessSVGStyle()->setFillRule(static_cast<WindRule>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyCaptionSide(StyleResolverState& state)
{
    state.style()->setCaptionSide(RenderStyle::initialCaptionSide());
}

void StyleBuilderFunctions::applyInheritCSSPropertyCaptionSide(StyleResolverState& state)
{
    state.style()->setCaptionSide(state.parentStyle()->captionSide());
}

void StyleBuilderFunctions::applyValueCSSPropertyCaptionSide(StyleResolverState& state, CSSValue* value)
{
    state.style()->setCaptionSide(static_cast<ECaptionSide>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitMarqueeSpeed(StyleResolverState& state)
{
    state.style()->setMarqueeSpeed(RenderStyle::initialMarqueeSpeed());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitMarqueeSpeed(StyleResolverState& state)
{
    state.style()->setMarqueeSpeed(state.parentStyle()->marqueeSpeed());
}

void StyleBuilderFunctions::applyInitialCSSPropertyTextDecoration(StyleResolverState& state)
{
    state.style()->setTextDecoration(RenderStyle::initialTextDecoration());
}

void StyleBuilderFunctions::applyInheritCSSPropertyTextDecoration(StyleResolverState& state)
{
    state.style()->setTextDecoration(state.parentStyle()->textDecoration());
}

void StyleBuilderFunctions::applyInitialCSSPropertyColorRendering(StyleResolverState& state)
{
    state.style()->accessSVGStyle()->setColorRendering(SVGRenderStyle::initialColorRendering());
}

void StyleBuilderFunctions::applyInheritCSSPropertyColorRendering(StyleResolverState& state)
{
    state.style()->accessSVGStyle()->setColorRendering(state.parentStyle()->svgStyle()->colorRendering());
}

void StyleBuilderFunctions::applyValueCSSPropertyColorRendering(StyleResolverState& state, CSSValue* value)
{
    state.style()->accessSVGStyle()->setColorRendering(static_cast<EColorRendering>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitPrintColorAdjust(StyleResolverState& state)
{
    state.style()->setPrintColorAdjust(RenderStyle::initialPrintColorAdjust());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitPrintColorAdjust(StyleResolverState& state)
{
    state.style()->setPrintColorAdjust(state.parentStyle()->printColorAdjust());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitPrintColorAdjust(StyleResolverState& state, CSSValue* value)
{
    state.style()->setPrintColorAdjust(static_cast<PrintColorAdjust>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyClipRule(StyleResolverState& state)
{
    state.style()->accessSVGStyle()->setClipRule(SVGRenderStyle::initialClipRule());
}

void StyleBuilderFunctions::applyInheritCSSPropertyClipRule(StyleResolverState& state)
{
    state.style()->accessSVGStyle()->setClipRule(state.parentStyle()->svgStyle()->clipRule());
}

void StyleBuilderFunctions::applyValueCSSPropertyClipRule(StyleResolverState& state, CSSValue* value)
{
    state.style()->accessSVGStyle()->setClipRule(static_cast<WindRule>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyMaxHeight(StyleResolverState& state)
{
    state.style()->setMaxHeight(RenderStyle::initialMaxSize());
}

void StyleBuilderFunctions::applyInheritCSSPropertyMaxHeight(StyleResolverState& state)
{
    state.style()->setMaxHeight(state.parentStyle()->maxHeight());
}

void StyleBuilderFunctions::applyValueCSSPropertyMaxHeight(StyleResolverState& state, CSSValue* value)
{
    state.style()->setMaxHeight(StyleBuilderConverter::convertLengthMaxSizing(state, value));
}

void StyleBuilderFunctions::applyInitialCSSPropertyFlexBasis(StyleResolverState& state)
{
    state.style()->setFlexBasis(RenderStyle::initialFlexBasis());
}

void StyleBuilderFunctions::applyInheritCSSPropertyFlexBasis(StyleResolverState& state)
{
    state.style()->setFlexBasis(state.parentStyle()->flexBasis());
}

void StyleBuilderFunctions::applyValueCSSPropertyFlexBasis(StyleResolverState& state, CSSValue* value)
{
    state.style()->setFlexBasis(StyleBuilderConverter::convertLengthOrAuto(state, value));
}

void StyleBuilderFunctions::applyInitialCSSPropertyMixBlendMode(StyleResolverState& state)
{
    state.style()->setBlendMode(RenderStyle::initialBlendMode());
}

void StyleBuilderFunctions::applyInheritCSSPropertyMixBlendMode(StyleResolverState& state)
{
    state.style()->setBlendMode(state.parentStyle()->blendMode());
}

void StyleBuilderFunctions::applyValueCSSPropertyMixBlendMode(StyleResolverState& state, CSSValue* value)
{
    state.style()->setBlendMode(static_cast<BlendMode>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitRubyPosition(StyleResolverState& state)
{
    state.style()->setRubyPosition(RenderStyle::initialRubyPosition());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitRubyPosition(StyleResolverState& state)
{
    state.style()->setRubyPosition(state.parentStyle()->rubyPosition());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitRubyPosition(StyleResolverState& state, CSSValue* value)
{
    state.style()->setRubyPosition(static_cast<RubyPosition>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyBufferedRendering(StyleResolverState& state)
{
    state.style()->accessSVGStyle()->setBufferedRendering(SVGRenderStyle::initialBufferedRendering());
}

void StyleBuilderFunctions::applyInheritCSSPropertyBufferedRendering(StyleResolverState& state)
{
    state.style()->accessSVGStyle()->setBufferedRendering(state.parentStyle()->svgStyle()->bufferedRendering());
}

void StyleBuilderFunctions::applyValueCSSPropertyBufferedRendering(StyleResolverState& state, CSSValue* value)
{
    state.style()->accessSVGStyle()->setBufferedRendering(static_cast<EBufferedRendering>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyFlexShrink(StyleResolverState& state)
{
    state.style()->setFlexShrink(RenderStyle::initialFlexShrink());
}

void StyleBuilderFunctions::applyInheritCSSPropertyFlexShrink(StyleResolverState& state)
{
    state.style()->setFlexShrink(state.parentStyle()->flexShrink());
}

void StyleBuilderFunctions::applyValueCSSPropertyFlexShrink(StyleResolverState& state, CSSValue* value)
{
    state.style()->setFlexShrink(static_cast<float>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitTransformOriginX(StyleResolverState& state)
{
    state.style()->setTransformOriginX(RenderStyle::initialTransformOriginX());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitTransformOriginX(StyleResolverState& state)
{
    state.style()->setTransformOriginX(state.parentStyle()->transformOriginX());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitTransformOriginX(StyleResolverState& state, CSSValue* value)
{
    state.style()->setTransformOriginX(StyleBuilderConverter::convertLength(state, value));
}

void StyleBuilderFunctions::applyInitialCSSPropertyPaddingLeft(StyleResolverState& state)
{
    state.style()->setPaddingLeft(RenderStyle::initialPadding());
}

void StyleBuilderFunctions::applyInheritCSSPropertyPaddingLeft(StyleResolverState& state)
{
    state.style()->setPaddingLeft(state.parentStyle()->paddingLeft());
}

void StyleBuilderFunctions::applyValueCSSPropertyPaddingLeft(StyleResolverState& state, CSSValue* value)
{
    state.style()->setPaddingLeft(StyleBuilderConverter::convertLength(state, value));
}

void StyleBuilderFunctions::applyInitialCSSPropertyStrokeLinejoin(StyleResolverState& state)
{
    state.style()->accessSVGStyle()->setJoinStyle(SVGRenderStyle::initialJoinStyle());
}

void StyleBuilderFunctions::applyInheritCSSPropertyStrokeLinejoin(StyleResolverState& state)
{
    state.style()->accessSVGStyle()->setJoinStyle(state.parentStyle()->svgStyle()->joinStyle());
}

void StyleBuilderFunctions::applyValueCSSPropertyStrokeLinejoin(StyleResolverState& state, CSSValue* value)
{
    state.style()->accessSVGStyle()->setJoinStyle(static_cast<LineJoin>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWhiteSpace(StyleResolverState& state)
{
    state.style()->setWhiteSpace(RenderStyle::initialWhiteSpace());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWhiteSpace(StyleResolverState& state)
{
    state.style()->setWhiteSpace(state.parentStyle()->whiteSpace());
}

void StyleBuilderFunctions::applyValueCSSPropertyWhiteSpace(StyleResolverState& state, CSSValue* value)
{
    state.style()->setWhiteSpace(static_cast<EWhiteSpace>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWritingMode(StyleResolverState& state)
{
    state.style()->accessSVGStyle()->setWritingMode(SVGRenderStyle::initialWritingMode());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWritingMode(StyleResolverState& state)
{
    state.style()->accessSVGStyle()->setWritingMode(state.parentStyle()->svgStyle()->writingMode());
}

void StyleBuilderFunctions::applyValueCSSPropertyWritingMode(StyleResolverState& state, CSSValue* value)
{
    state.style()->accessSVGStyle()->setWritingMode(static_cast<SVGWritingMode>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitFlowInto(StyleResolverState& state)
{
    state.style()->setFlowThread(RenderStyle::initialFlowThread());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitFlowInto(StyleResolverState& state)
{
    state.style()->setFlowThread(state.parentStyle()->flowThread());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitFlowInto(StyleResolverState& state, CSSValue* value)
{
    state.style()->setFlowThread(StyleBuilderConverter::convertString<CSSValueNone>(state, value));
}

void StyleBuilderFunctions::applyInitialCSSPropertyOverflowWrap(StyleResolverState& state)
{
    state.style()->setOverflowWrap(RenderStyle::initialOverflowWrap());
}

void StyleBuilderFunctions::applyInheritCSSPropertyOverflowWrap(StyleResolverState& state)
{
    state.style()->setOverflowWrap(state.parentStyle()->overflowWrap());
}

void StyleBuilderFunctions::applyValueCSSPropertyOverflowWrap(StyleResolverState& state, CSSValue* value)
{
    state.style()->setOverflowWrap(static_cast<EOverflowWrap>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyVerticalAlign(StyleResolverState& state)
{
    state.style()->setVerticalAlign(RenderStyle::initialVerticalAlign());
}

void StyleBuilderFunctions::applyInheritCSSPropertyVerticalAlign(StyleResolverState& state)
{
    state.style()->setVerticalAlign(state.parentStyle()->verticalAlign());
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitColumnBreakAfter(StyleResolverState& state)
{
    state.style()->setColumnBreakAfter(RenderStyle::initialPageBreak());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitColumnBreakAfter(StyleResolverState& state)
{
    state.style()->setColumnBreakAfter(state.parentStyle()->columnBreakAfter());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitColumnBreakAfter(StyleResolverState& state, CSSValue* value)
{
    state.style()->setColumnBreakAfter(static_cast<EPageBreak>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitBoxPack(StyleResolverState& state)
{
    state.style()->setBoxPack(RenderStyle::initialBoxPack());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitBoxPack(StyleResolverState& state)
{
    state.style()->setBoxPack(state.parentStyle()->boxPack());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitBoxPack(StyleResolverState& state, CSSValue* value)
{
    state.style()->setBoxPack(static_cast<EBoxPack>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitColumnProgression(StyleResolverState& state)
{
    state.style()->setColumnProgression(RenderStyle::initialColumnProgression());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitColumnProgression(StyleResolverState& state)
{
    state.style()->setColumnProgression(state.parentStyle()->columnProgression());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitColumnProgression(StyleResolverState& state, CSSValue* value)
{
    state.style()->setColumnProgression(static_cast<ColumnProgression>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyAlignmentBaseline(StyleResolverState& state)
{
    state.style()->accessSVGStyle()->setAlignmentBaseline(SVGRenderStyle::initialAlignmentBaseline());
}

void StyleBuilderFunctions::applyInheritCSSPropertyAlignmentBaseline(StyleResolverState& state)
{
    state.style()->accessSVGStyle()->setAlignmentBaseline(state.parentStyle()->svgStyle()->alignmentBaseline());
}

void StyleBuilderFunctions::applyValueCSSPropertyAlignmentBaseline(StyleResolverState& state, CSSValue* value)
{
    state.style()->accessSVGStyle()->setAlignmentBaseline(static_cast<EAlignmentBaseline>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitMarginAfterCollapse(StyleResolverState& state)
{
    state.style()->setMarginAfterCollapse(RenderStyle::initialMarginAfterCollapse());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitMarginAfterCollapse(StyleResolverState& state)
{
    state.style()->setMarginAfterCollapse(state.parentStyle()->marginAfterCollapse());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitMarginAfterCollapse(StyleResolverState& state, CSSValue* value)
{
    state.style()->setMarginAfterCollapse(static_cast<EMarginCollapse>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyOutlineWidth(StyleResolverState& state)
{
    state.style()->setOutlineWidth(RenderStyle::initialOutlineWidth());
}

void StyleBuilderFunctions::applyInheritCSSPropertyOutlineWidth(StyleResolverState& state)
{
    state.style()->setOutlineWidth(state.parentStyle()->outlineWidth());
}

void StyleBuilderFunctions::applyValueCSSPropertyOutlineWidth(StyleResolverState& state, CSSValue* value)
{
    state.style()->setOutlineWidth(StyleBuilderConverter::convertLineWidth<unsigned short>(state, value));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitClipPath(StyleResolverState& state)
{
    state.style()->setClipPath(RenderStyle::initialClipPath());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitClipPath(StyleResolverState& state)
{
    state.style()->setClipPath(state.parentStyle()->clipPath());
}

void StyleBuilderFunctions::applyInitialCSSPropertyWordSpacing(StyleResolverState& state)
{
    state.style()->setWordSpacing(RenderStyle::initialLetterWordSpacing());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWordSpacing(StyleResolverState& state)
{
    state.style()->setWordSpacing(state.parentStyle()->wordSpacing());
}

void StyleBuilderFunctions::applyValueCSSPropertyWordSpacing(StyleResolverState& state, CSSValue* value)
{
    state.style()->setWordSpacing(StyleBuilderConverter::convertSpacing(state, value));
}

void StyleBuilderFunctions::applyInitialCSSPropertyPageBreakAfter(StyleResolverState& state)
{
    state.style()->setPageBreakAfter(RenderStyle::initialPageBreak());
}

void StyleBuilderFunctions::applyInheritCSSPropertyPageBreakAfter(StyleResolverState& state)
{
    state.style()->setPageBreakAfter(state.parentStyle()->pageBreakAfter());
}

void StyleBuilderFunctions::applyValueCSSPropertyPageBreakAfter(StyleResolverState& state, CSSValue* value)
{
    state.style()->setPageBreakAfter(static_cast<EPageBreak>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyMinWidth(StyleResolverState& state)
{
    state.style()->setMinWidth(RenderStyle::initialMinSize());
}

void StyleBuilderFunctions::applyInheritCSSPropertyMinWidth(StyleResolverState& state)
{
    state.style()->setMinWidth(state.parentStyle()->minWidth());
}

void StyleBuilderFunctions::applyValueCSSPropertyMinWidth(StyleResolverState& state, CSSValue* value)
{
    state.style()->setMinWidth(StyleBuilderConverter::convertLengthSizing(state, value));
}

void StyleBuilderFunctions::applyInitialCSSPropertyGridAutoFlow(StyleResolverState& state)
{
    state.style()->setGridAutoFlow(RenderStyle::initialGridAutoFlow());
}

void StyleBuilderFunctions::applyInheritCSSPropertyGridAutoFlow(StyleResolverState& state)
{
    state.style()->setGridAutoFlow(state.parentStyle()->gridAutoFlow());
}

void StyleBuilderFunctions::applyValueCSSPropertyGridAutoFlow(StyleResolverState& state, CSSValue* value)
{
    state.style()->setGridAutoFlow(static_cast<GridAutoFlow>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyMaskType(StyleResolverState& state)
{
    state.style()->accessSVGStyle()->setMaskType(SVGRenderStyle::initialMaskType());
}

void StyleBuilderFunctions::applyInheritCSSPropertyMaskType(StyleResolverState& state)
{
    state.style()->accessSVGStyle()->setMaskType(state.parentStyle()->svgStyle()->maskType());
}

void StyleBuilderFunctions::applyValueCSSPropertyMaskType(StyleResolverState& state, CSSValue* value)
{
    state.style()->accessSVGStyle()->setMaskType(static_cast<EMaskType>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitShapeMargin(StyleResolverState& state)
{
    state.style()->setShapeMargin(RenderStyle::initialShapeMargin());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitShapeMargin(StyleResolverState& state)
{
    state.style()->setShapeMargin(state.parentStyle()->shapeMargin());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitShapeMargin(StyleResolverState& state, CSSValue* value)
{
    state.style()->setShapeMargin(StyleBuilderConverter::convertLength(state, value));
}

void StyleBuilderFunctions::applyInitialCSSPropertyBorderBottomRightRadius(StyleResolverState& state)
{
    state.style()->setBorderBottomRightRadius(RenderStyle::initialBorderRadius());
}

void StyleBuilderFunctions::applyInheritCSSPropertyBorderBottomRightRadius(StyleResolverState& state)
{
    state.style()->setBorderBottomRightRadius(state.parentStyle()->borderBottomRightRadius());
}

void StyleBuilderFunctions::applyValueCSSPropertyBorderBottomRightRadius(StyleResolverState& state, CSSValue* value)
{
    state.style()->setBorderBottomRightRadius(StyleBuilderConverter::convertRadius(state, value));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitMarqueeRepetition(StyleResolverState& state)
{
    state.style()->setMarqueeLoopCount(RenderStyle::initialMarqueeLoopCount());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitMarqueeRepetition(StyleResolverState& state)
{
    state.style()->setMarqueeLoopCount(state.parentStyle()->marqueeLoopCount());
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitPerspectiveOriginY(StyleResolverState& state)
{
    state.style()->setPerspectiveOriginY(RenderStyle::initialPerspectiveOriginY());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitPerspectiveOriginY(StyleResolverState& state)
{
    state.style()->setPerspectiveOriginY(state.parentStyle()->perspectiveOriginY());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitPerspectiveOriginY(StyleResolverState& state, CSSValue* value)
{
    state.style()->setPerspectiveOriginY(StyleBuilderConverter::convertLength(state, value));
}

void StyleBuilderFunctions::applyInitialCSSPropertyTextAlignLast(StyleResolverState& state)
{
    state.style()->setTextAlignLast(RenderStyle::initialTextAlignLast());
}

void StyleBuilderFunctions::applyInheritCSSPropertyTextAlignLast(StyleResolverState& state)
{
    state.style()->setTextAlignLast(state.parentStyle()->textAlignLast());
}

void StyleBuilderFunctions::applyValueCSSPropertyTextAlignLast(StyleResolverState& state, CSSValue* value)
{
    state.style()->setTextAlignLast(static_cast<TextAlignLast>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitWrapThrough(StyleResolverState& state)
{
    state.style()->setWrapThrough(RenderStyle::initialWrapThrough());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitWrapThrough(StyleResolverState& state)
{
    state.style()->setWrapThrough(state.parentStyle()->wrapThrough());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitWrapThrough(StyleResolverState& state, CSSValue* value)
{
    state.style()->setWrapThrough(static_cast<WrapThrough>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitLineClamp(StyleResolverState& state)
{
    state.style()->setLineClamp(RenderStyle::initialLineClamp());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitLineClamp(StyleResolverState& state)
{
    state.style()->setLineClamp(state.parentStyle()->lineClamp());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitLineClamp(StyleResolverState& state, CSSValue* value)
{
    state.style()->setLineClamp(static_cast<LineClampValue>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyPageBreakInside(StyleResolverState& state)
{
    state.style()->setPageBreakInside(RenderStyle::initialPageBreak());
}

void StyleBuilderFunctions::applyInheritCSSPropertyPageBreakInside(StyleResolverState& state)
{
    state.style()->setPageBreakInside(state.parentStyle()->pageBreakInside());
}

void StyleBuilderFunctions::applyValueCSSPropertyPageBreakInside(StyleResolverState& state, CSSValue* value)
{
    state.style()->setPageBreakInside(static_cast<EPageBreak>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyMinHeight(StyleResolverState& state)
{
    state.style()->setMinHeight(RenderStyle::initialMinSize());
}

void StyleBuilderFunctions::applyInheritCSSPropertyMinHeight(StyleResolverState& state)
{
    state.style()->setMinHeight(state.parentStyle()->minHeight());
}

void StyleBuilderFunctions::applyValueCSSPropertyMinHeight(StyleResolverState& state, CSSValue* value)
{
    state.style()->setMinHeight(StyleBuilderConverter::convertLengthSizing(state, value));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitBoxLines(StyleResolverState& state)
{
    state.style()->setBoxLines(RenderStyle::initialBoxLines());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitBoxLines(StyleResolverState& state)
{
    state.style()->setBoxLines(state.parentStyle()->boxLines());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitBoxLines(StyleResolverState& state, CSSValue* value)
{
    state.style()->setBoxLines(static_cast<EBoxLines>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyTabSize(StyleResolverState& state)
{
    state.style()->setTabSize(RenderStyle::initialTabSize());
}

void StyleBuilderFunctions::applyInheritCSSPropertyTabSize(StyleResolverState& state)
{
    state.style()->setTabSize(state.parentStyle()->tabSize());
}

void StyleBuilderFunctions::applyValueCSSPropertyTabSize(StyleResolverState& state, CSSValue* value)
{
    state.style()->setTabSize(static_cast<unsigned>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyBorderBottomStyle(StyleResolverState& state)
{
    state.style()->setBorderBottomStyle(RenderStyle::initialBorderStyle());
}

void StyleBuilderFunctions::applyInheritCSSPropertyBorderBottomStyle(StyleResolverState& state)
{
    state.style()->setBorderBottomStyle(state.parentStyle()->borderBottomStyle());
}

void StyleBuilderFunctions::applyValueCSSPropertyBorderBottomStyle(StyleResolverState& state, CSSValue* value)
{
    state.style()->setBorderBottomStyle(static_cast<EBorderStyle>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyColorInterpolationFilters(StyleResolverState& state)
{
    state.style()->accessSVGStyle()->setColorInterpolationFilters(SVGRenderStyle::initialColorInterpolationFilters());
}

void StyleBuilderFunctions::applyInheritCSSPropertyColorInterpolationFilters(StyleResolverState& state)
{
    state.style()->accessSVGStyle()->setColorInterpolationFilters(state.parentStyle()->svgStyle()->colorInterpolationFilters());
}

void StyleBuilderFunctions::applyValueCSSPropertyColorInterpolationFilters(StyleResolverState& state, CSSValue* value)
{
    state.style()->accessSVGStyle()->setColorInterpolationFilters(static_cast<EColorInterpolation>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyHeight(StyleResolverState& state)
{
    state.style()->setHeight(RenderStyle::initialSize());
}

void StyleBuilderFunctions::applyInheritCSSPropertyHeight(StyleResolverState& state)
{
    state.style()->setHeight(state.parentStyle()->height());
}

void StyleBuilderFunctions::applyValueCSSPropertyHeight(StyleResolverState& state, CSSValue* value)
{
    state.style()->setHeight(StyleBuilderConverter::convertLengthSizing(state, value));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitShapeInside(StyleResolverState& state)
{
    state.style()->setShapeInside(RenderStyle::initialShapeInside());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitShapeInside(StyleResolverState& state)
{
    state.style()->setShapeInside(state.parentStyle()->shapeInside());
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitLineGrid(StyleResolverState& state)
{
    state.style()->setLineGrid(RenderStyle::initialLineGrid());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitLineGrid(StyleResolverState& state)
{
    state.style()->setLineGrid(state.parentStyle()->lineGrid());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitLineGrid(StyleResolverState& state, CSSValue* value)
{
    state.style()->setLineGrid(StyleBuilderConverter::convertString<CSSValueNone>(state, value));
}

void StyleBuilderFunctions::applyInitialCSSPropertyBorderBottomWidth(StyleResolverState& state)
{
    state.style()->setBorderBottomWidth(RenderStyle::initialBorderWidth());
}

void StyleBuilderFunctions::applyInheritCSSPropertyBorderBottomWidth(StyleResolverState& state)
{
    state.style()->setBorderBottomWidth(state.parentStyle()->borderBottomWidth());
}

void StyleBuilderFunctions::applyValueCSSPropertyBorderBottomWidth(StyleResolverState& state, CSSValue* value)
{
    state.style()->setBorderBottomWidth(StyleBuilderConverter::convertLineWidth<unsigned>(state, value));
}

void StyleBuilderFunctions::applyInitialCSSPropertyTableLayout(StyleResolverState& state)
{
    state.style()->setTableLayout(RenderStyle::initialTableLayout());
}

void StyleBuilderFunctions::applyInheritCSSPropertyTableLayout(StyleResolverState& state)
{
    state.style()->setTableLayout(state.parentStyle()->tableLayout());
}

void StyleBuilderFunctions::applyValueCSSPropertyTableLayout(StyleResolverState& state, CSSValue* value)
{
    state.style()->setTableLayout(static_cast<ETableLayout>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyMaxWidth(StyleResolverState& state)
{
    state.style()->setMaxWidth(RenderStyle::initialMaxSize());
}

void StyleBuilderFunctions::applyInheritCSSPropertyMaxWidth(StyleResolverState& state)
{
    state.style()->setMaxWidth(state.parentStyle()->maxWidth());
}

void StyleBuilderFunctions::applyValueCSSPropertyMaxWidth(StyleResolverState& state, CSSValue* value)
{
    state.style()->setMaxWidth(StyleBuilderConverter::convertLengthMaxSizing(state, value));
}

void StyleBuilderFunctions::applyInitialCSSPropertyBorderRightStyle(StyleResolverState& state)
{
    state.style()->setBorderRightStyle(RenderStyle::initialBorderStyle());
}

void StyleBuilderFunctions::applyInheritCSSPropertyBorderRightStyle(StyleResolverState& state)
{
    state.style()->setBorderRightStyle(state.parentStyle()->borderRightStyle());
}

void StyleBuilderFunctions::applyValueCSSPropertyBorderRightStyle(StyleResolverState& state, CSSValue* value)
{
    state.style()->setBorderRightStyle(static_cast<EBorderStyle>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitHighlight(StyleResolverState& state)
{
    state.style()->setHighlight(RenderStyle::initialHighlight());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitHighlight(StyleResolverState& state)
{
    state.style()->setHighlight(state.parentStyle()->highlight());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitHighlight(StyleResolverState& state, CSSValue* value)
{
    state.style()->setHighlight(StyleBuilderConverter::convertString<CSSValueNone>(state, value));
}

void StyleBuilderFunctions::applyInitialCSSPropertyEmptyCells(StyleResolverState& state)
{
    state.style()->setEmptyCells(RenderStyle::initialEmptyCells());
}

void StyleBuilderFunctions::applyInheritCSSPropertyEmptyCells(StyleResolverState& state)
{
    state.style()->setEmptyCells(state.parentStyle()->emptyCells());
}

void StyleBuilderFunctions::applyValueCSSPropertyEmptyCells(StyleResolverState& state, CSSValue* value)
{
    state.style()->setEmptyCells(static_cast<EEmptyCell>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitRegionBreakBefore(StyleResolverState& state)
{
    state.style()->setRegionBreakBefore(RenderStyle::initialPageBreak());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitRegionBreakBefore(StyleResolverState& state)
{
    state.style()->setRegionBreakBefore(state.parentStyle()->regionBreakBefore());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitRegionBreakBefore(StyleResolverState& state, CSSValue* value)
{
    state.style()->setRegionBreakBefore(static_cast<EPageBreak>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyBorderRightWidth(StyleResolverState& state)
{
    state.style()->setBorderRightWidth(RenderStyle::initialBorderWidth());
}

void StyleBuilderFunctions::applyInheritCSSPropertyBorderRightWidth(StyleResolverState& state)
{
    state.style()->setBorderRightWidth(state.parentStyle()->borderRightWidth());
}

void StyleBuilderFunctions::applyValueCSSPropertyBorderRightWidth(StyleResolverState& state, CSSValue* value)
{
    state.style()->setBorderRightWidth(StyleBuilderConverter::convertLineWidth<unsigned>(state, value));
}

void StyleBuilderFunctions::applyInitialCSSPropertyBorderImageSource(StyleResolverState& state)
{
    state.style()->setBorderImageSource(RenderStyle::initialBorderImageSource());
}

void StyleBuilderFunctions::applyInheritCSSPropertyBorderImageSource(StyleResolverState& state)
{
    state.style()->setBorderImageSource(state.parentStyle()->borderImageSource());
}

void StyleBuilderFunctions::applyInitialCSSPropertyBorderTopLeftRadius(StyleResolverState& state)
{
    state.style()->setBorderTopLeftRadius(RenderStyle::initialBorderRadius());
}

void StyleBuilderFunctions::applyInheritCSSPropertyBorderTopLeftRadius(StyleResolverState& state)
{
    state.style()->setBorderTopLeftRadius(state.parentStyle()->borderTopLeftRadius());
}

void StyleBuilderFunctions::applyValueCSSPropertyBorderTopLeftRadius(StyleResolverState& state, CSSValue* value)
{
    state.style()->setBorderTopLeftRadius(StyleBuilderConverter::convertRadius(state, value));
}

void StyleBuilderFunctions::applyInitialCSSPropertyRight(StyleResolverState& state)
{
    state.style()->setRight(RenderStyle::initialOffset());
}

void StyleBuilderFunctions::applyInheritCSSPropertyRight(StyleResolverState& state)
{
    state.style()->setRight(state.parentStyle()->right());
}

void StyleBuilderFunctions::applyValueCSSPropertyRight(StyleResolverState& state, CSSValue* value)
{
    state.style()->setRight(StyleBuilderConverter::convertLengthOrAuto(state, value));
}

void StyleBuilderFunctions::applyInitialCSSPropertyBorderBottomLeftRadius(StyleResolverState& state)
{
    state.style()->setBorderBottomLeftRadius(RenderStyle::initialBorderRadius());
}

void StyleBuilderFunctions::applyInheritCSSPropertyBorderBottomLeftRadius(StyleResolverState& state)
{
    state.style()->setBorderBottomLeftRadius(state.parentStyle()->borderBottomLeftRadius());
}

void StyleBuilderFunctions::applyValueCSSPropertyBorderBottomLeftRadius(StyleResolverState& state, CSSValue* value)
{
    state.style()->setBorderBottomLeftRadius(StyleBuilderConverter::convertRadius(state, value));
}

void StyleBuilderFunctions::applyInitialCSSPropertyBoxSizing(StyleResolverState& state)
{
    state.style()->setBoxSizing(RenderStyle::initialBoxSizing());
}

void StyleBuilderFunctions::applyInheritCSSPropertyBoxSizing(StyleResolverState& state)
{
    state.style()->setBoxSizing(state.parentStyle()->boxSizing());
}

void StyleBuilderFunctions::applyValueCSSPropertyBoxSizing(StyleResolverState& state, CSSValue* value)
{
    state.style()->setBoxSizing(static_cast<EBoxSizing>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyTextOverflow(StyleResolverState& state)
{
    state.style()->setTextOverflow(RenderStyle::initialTextOverflow());
}

void StyleBuilderFunctions::applyInheritCSSPropertyTextOverflow(StyleResolverState& state)
{
    state.style()->setTextOverflow(state.parentStyle()->textOverflow());
}

void StyleBuilderFunctions::applyValueCSSPropertyTextOverflow(StyleResolverState& state, CSSValue* value)
{
    state.style()->setTextOverflow(static_cast<TextOverflow>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitRegionFragment(StyleResolverState& state)
{
    state.style()->setRegionFragment(RenderStyle::initialRegionFragment());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitRegionFragment(StyleResolverState& state)
{
    state.style()->setRegionFragment(state.parentStyle()->regionFragment());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitRegionFragment(StyleResolverState& state, CSSValue* value)
{
    state.style()->setRegionFragment(static_cast<RegionFragment>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitTextSecurity(StyleResolverState& state)
{
    state.style()->setTextSecurity(RenderStyle::initialTextSecurity());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitTextSecurity(StyleResolverState& state)
{
    state.style()->setTextSecurity(state.parentStyle()->textSecurity());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitTextSecurity(StyleResolverState& state, CSSValue* value)
{
    state.style()->setTextSecurity(static_cast<ETextSecurity>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyBorderLeftWidth(StyleResolverState& state)
{
    state.style()->setBorderLeftWidth(RenderStyle::initialBorderWidth());
}

void StyleBuilderFunctions::applyInheritCSSPropertyBorderLeftWidth(StyleResolverState& state)
{
    state.style()->setBorderLeftWidth(state.parentStyle()->borderLeftWidth());
}

void StyleBuilderFunctions::applyValueCSSPropertyBorderLeftWidth(StyleResolverState& state, CSSValue* value)
{
    state.style()->setBorderLeftWidth(StyleBuilderConverter::convertLineWidth<unsigned>(state, value));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitLineBreak(StyleResolverState& state)
{
    state.style()->setLineBreak(RenderStyle::initialLineBreak());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitLineBreak(StyleResolverState& state)
{
    state.style()->setLineBreak(state.parentStyle()->lineBreak());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitLineBreak(StyleResolverState& state, CSSValue* value)
{
    state.style()->setLineBreak(static_cast<LineBreak>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitMarqueeIncrement(StyleResolverState& state)
{
    state.style()->setMarqueeIncrement(RenderStyle::initialMarqueeIncrement());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitMarqueeIncrement(StyleResolverState& state)
{
    state.style()->setMarqueeIncrement(state.parentStyle()->marqueeIncrement());
}

void StyleBuilderFunctions::applyInitialCSSPropertyLeft(StyleResolverState& state)
{
    state.style()->setLeft(RenderStyle::initialOffset());
}

void StyleBuilderFunctions::applyInheritCSSPropertyLeft(StyleResolverState& state)
{
    state.style()->setLeft(state.parentStyle()->left());
}

void StyleBuilderFunctions::applyValueCSSPropertyLeft(StyleResolverState& state, CSSValue* value)
{
    state.style()->setLeft(StyleBuilderConverter::convertLengthOrAuto(state, value));
}

void StyleBuilderFunctions::applyInitialCSSPropertyTextDecorationStyle(StyleResolverState& state)
{
    state.style()->setTextDecorationStyle(RenderStyle::initialTextDecorationStyle());
}

void StyleBuilderFunctions::applyInheritCSSPropertyTextDecorationStyle(StyleResolverState& state)
{
    state.style()->setTextDecorationStyle(state.parentStyle()->textDecorationStyle());
}

void StyleBuilderFunctions::applyValueCSSPropertyTextDecorationStyle(StyleResolverState& state, CSSValue* value)
{
    state.style()->setTextDecorationStyle(static_cast<TextDecorationStyle>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitTextEmphasisPosition(StyleResolverState& state)
{
    state.style()->setTextEmphasisPosition(RenderStyle::initialTextEmphasisPosition());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitTextEmphasisPosition(StyleResolverState& state)
{
    state.style()->setTextEmphasisPosition(state.parentStyle()->textEmphasisPosition());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitTextEmphasisPosition(StyleResolverState& state, CSSValue* value)
{
    state.style()->setTextEmphasisPosition(static_cast<TextEmphasisPosition>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWidth(StyleResolverState& state)
{
    state.style()->setWidth(RenderStyle::initialSize());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWidth(StyleResolverState& state)
{
    state.style()->setWidth(state.parentStyle()->width());
}

void StyleBuilderFunctions::applyValueCSSPropertyWidth(StyleResolverState& state, CSSValue* value)
{
    state.style()->setWidth(StyleBuilderConverter::convertLengthSizing(state, value));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitLineAlign(StyleResolverState& state)
{
    state.style()->setLineAlign(RenderStyle::initialLineAlign());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitLineAlign(StyleResolverState& state)
{
    state.style()->setLineAlign(state.parentStyle()->lineAlign());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitLineAlign(StyleResolverState& state, CSSValue* value)
{
    state.style()->setLineAlign(static_cast<LineAlign>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyTouchAction(StyleResolverState& state)
{
    state.style()->setTouchAction(RenderStyle::initialTouchAction());
}

void StyleBuilderFunctions::applyInheritCSSPropertyTouchAction(StyleResolverState& state)
{
    state.style()->setTouchAction(state.parentStyle()->touchAction());
}

void StyleBuilderFunctions::applyValueCSSPropertyTouchAction(StyleResolverState& state, CSSValue* value)
{
    state.style()->setTouchAction(static_cast<TouchAction>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitMaskBoxImageSource(StyleResolverState& state)
{
    state.style()->setMaskBoxImageSource(RenderStyle::initialMaskBoxImageSource());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitMaskBoxImageSource(StyleResolverState& state)
{
    state.style()->setMaskBoxImageSource(state.parentStyle()->maskBoxImageSource());
}

void StyleBuilderFunctions::applyInitialCSSPropertyPaddingTop(StyleResolverState& state)
{
    state.style()->setPaddingTop(RenderStyle::initialPadding());
}

void StyleBuilderFunctions::applyInheritCSSPropertyPaddingTop(StyleResolverState& state)
{
    state.style()->setPaddingTop(state.parentStyle()->paddingTop());
}

void StyleBuilderFunctions::applyValueCSSPropertyPaddingTop(StyleResolverState& state, CSSValue* value)
{
    state.style()->setPaddingTop(StyleBuilderConverter::convertLength(state, value));
}

void StyleBuilderFunctions::applyInitialCSSPropertyBorderTopWidth(StyleResolverState& state)
{
    state.style()->setBorderTopWidth(RenderStyle::initialBorderWidth());
}

void StyleBuilderFunctions::applyInheritCSSPropertyBorderTopWidth(StyleResolverState& state)
{
    state.style()->setBorderTopWidth(state.parentStyle()->borderTopWidth());
}

void StyleBuilderFunctions::applyValueCSSPropertyBorderTopWidth(StyleResolverState& state, CSSValue* value)
{
    state.style()->setBorderTopWidth(StyleBuilderConverter::convertLineWidth<unsigned>(state, value));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitBorderVerticalSpacing(StyleResolverState& state)
{
    state.style()->setVerticalBorderSpacing(RenderStyle::initialVerticalBorderSpacing());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitBorderVerticalSpacing(StyleResolverState& state)
{
    state.style()->setVerticalBorderSpacing(state.parentStyle()->verticalBorderSpacing());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitBorderVerticalSpacing(StyleResolverState& state, CSSValue* value)
{
    state.style()->setVerticalBorderSpacing(StyleBuilderConverter::convertComputedLength<short>(state, value));
}

void StyleBuilderFunctions::applyInitialCSSPropertyBottom(StyleResolverState& state)
{
    state.style()->setBottom(RenderStyle::initialOffset());
}

void StyleBuilderFunctions::applyInheritCSSPropertyBottom(StyleResolverState& state)
{
    state.style()->setBottom(state.parentStyle()->bottom());
}

void StyleBuilderFunctions::applyValueCSSPropertyBottom(StyleResolverState& state, CSSValue* value)
{
    state.style()->setBottom(StyleBuilderConverter::convertLengthOrAuto(state, value));
}

void StyleBuilderFunctions::applyInitialCSSPropertyBorderCollapse(StyleResolverState& state)
{
    state.style()->setBorderCollapse(RenderStyle::initialBorderCollapse());
}

void StyleBuilderFunctions::applyInheritCSSPropertyBorderCollapse(StyleResolverState& state)
{
    state.style()->setBorderCollapse(state.parentStyle()->borderCollapse());
}

void StyleBuilderFunctions::applyValueCSSPropertyBorderCollapse(StyleResolverState& state, CSSValue* value)
{
    state.style()->setBorderCollapse(static_cast<EBorderCollapse>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitMarginTopCollapse(StyleResolverState& state)
{
    state.style()->setMarginBeforeCollapse(RenderStyle::initialMarginBeforeCollapse());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitMarginTopCollapse(StyleResolverState& state)
{
    state.style()->setMarginBeforeCollapse(state.parentStyle()->marginBeforeCollapse());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitMarginTopCollapse(StyleResolverState& state, CSSValue* value)
{
    state.style()->setMarginBeforeCollapse(static_cast<EMarginCollapse>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyTop(StyleResolverState& state)
{
    state.style()->setTop(RenderStyle::initialOffset());
}

void StyleBuilderFunctions::applyInheritCSSPropertyTop(StyleResolverState& state)
{
    state.style()->setTop(state.parentStyle()->top());
}

void StyleBuilderFunctions::applyValueCSSPropertyTop(StyleResolverState& state, CSSValue* value)
{
    state.style()->setTop(StyleBuilderConverter::convertLengthOrAuto(state, value));
}

void StyleBuilderFunctions::applyInitialCSSPropertyMarginBottom(StyleResolverState& state)
{
    state.style()->setMarginBottom(RenderStyle::initialMargin());
}

void StyleBuilderFunctions::applyInheritCSSPropertyMarginBottom(StyleResolverState& state)
{
    state.style()->setMarginBottom(state.parentStyle()->marginBottom());
}

void StyleBuilderFunctions::applyValueCSSPropertyMarginBottom(StyleResolverState& state, CSSValue* value)
{
    state.style()->setMarginBottom(StyleBuilderConverter::convertLengthOrAuto(state, value));
}

void StyleBuilderFunctions::applyInitialCSSPropertyImageRendering(StyleResolverState& state)
{
    state.style()->setImageRendering(RenderStyle::initialImageRendering());
}

void StyleBuilderFunctions::applyInheritCSSPropertyImageRendering(StyleResolverState& state)
{
    state.style()->setImageRendering(state.parentStyle()->imageRendering());
}

void StyleBuilderFunctions::applyValueCSSPropertyImageRendering(StyleResolverState& state, CSSValue* value)
{
    state.style()->setImageRendering(static_cast<EImageRendering>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitColumnRuleStyle(StyleResolverState& state)
{
    state.style()->setColumnRuleStyle(RenderStyle::initialBorderStyle());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitColumnRuleStyle(StyleResolverState& state)
{
    state.style()->setColumnRuleStyle(state.parentStyle()->columnRuleStyle());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitColumnRuleStyle(StyleResolverState& state, CSSValue* value)
{
    state.style()->setColumnRuleStyle(static_cast<EBorderStyle>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyListStylePosition(StyleResolverState& state)
{
    state.style()->setListStylePosition(RenderStyle::initialListStylePosition());
}

void StyleBuilderFunctions::applyInheritCSSPropertyListStylePosition(StyleResolverState& state)
{
    state.style()->setListStylePosition(state.parentStyle()->listStylePosition());
}

void StyleBuilderFunctions::applyValueCSSPropertyListStylePosition(StyleResolverState& state, CSSValue* value)
{
    state.style()->setListStylePosition(static_cast<EListStylePosition>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyUnicodeBidi(StyleResolverState& state)
{
    state.style()->setUnicodeBidi(RenderStyle::initialUnicodeBidi());
}

void StyleBuilderFunctions::applyInheritCSSPropertyUnicodeBidi(StyleResolverState& state)
{
    state.style()->setUnicodeBidi(state.parentStyle()->unicodeBidi());
}

void StyleBuilderFunctions::applyValueCSSPropertyUnicodeBidi(StyleResolverState& state, CSSValue* value)
{
    state.style()->setUnicodeBidi(static_cast<EUnicodeBidi>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyFloat(StyleResolverState& state)
{
    state.style()->setFloating(RenderStyle::initialFloating());
}

void StyleBuilderFunctions::applyInheritCSSPropertyFloat(StyleResolverState& state)
{
    state.style()->setFloating(state.parentStyle()->floating());
}

void StyleBuilderFunctions::applyValueCSSPropertyFloat(StyleResolverState& state, CSSValue* value)
{
    state.style()->setFloating(static_cast<EFloat>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitRtlOrdering(StyleResolverState& state)
{
    state.style()->setRTLOrdering(RenderStyle::initialRTLOrdering());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitRtlOrdering(StyleResolverState& state)
{
    state.style()->setRTLOrdering(state.parentStyle()->rtlOrdering());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitRtlOrdering(StyleResolverState& state, CSSValue* value)
{
    state.style()->setRTLOrdering(static_cast<Order>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyDisplay(StyleResolverState& state)
{
    state.style()->setDisplay(RenderStyle::initialDisplay());
}

void StyleBuilderFunctions::applyInitialCSSPropertyOutlineOffset(StyleResolverState& state)
{
    state.style()->setOutlineOffset(RenderStyle::initialOutlineOffset());
}

void StyleBuilderFunctions::applyInheritCSSPropertyOutlineOffset(StyleResolverState& state)
{
    state.style()->setOutlineOffset(state.parentStyle()->outlineOffset());
}

void StyleBuilderFunctions::applyValueCSSPropertyOutlineOffset(StyleResolverState& state, CSSValue* value)
{
    state.style()->setOutlineOffset(StyleBuilderConverter::convertComputedLength<int>(state, value));
}

void StyleBuilderFunctions::applyInitialCSSPropertyShapeRendering(StyleResolverState& state)
{
    state.style()->accessSVGStyle()->setShapeRendering(SVGRenderStyle::initialShapeRendering());
}

void StyleBuilderFunctions::applyInheritCSSPropertyShapeRendering(StyleResolverState& state)
{
    state.style()->accessSVGStyle()->setShapeRendering(state.parentStyle()->svgStyle()->shapeRendering());
}

void StyleBuilderFunctions::applyValueCSSPropertyShapeRendering(StyleResolverState& state, CSSValue* value)
{
    state.style()->accessSVGStyle()->setShapeRendering(static_cast<EShapeRendering>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitUserSelect(StyleResolverState& state)
{
    state.style()->setUserSelect(RenderStyle::initialUserSelect());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitUserSelect(StyleResolverState& state)
{
    state.style()->setUserSelect(state.parentStyle()->userSelect());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitUserSelect(StyleResolverState& state, CSSValue* value)
{
    state.style()->setUserSelect(static_cast<EUserSelect>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWordBreak(StyleResolverState& state)
{
    state.style()->setWordBreak(RenderStyle::initialWordBreak());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWordBreak(StyleResolverState& state)
{
    state.style()->setWordBreak(state.parentStyle()->wordBreak());
}

void StyleBuilderFunctions::applyValueCSSPropertyWordBreak(StyleResolverState& state, CSSValue* value)
{
    state.style()->setWordBreak(static_cast<EWordBreak>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitBorderFit(StyleResolverState& state)
{
    state.style()->setBorderFit(RenderStyle::initialBorderFit());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitBorderFit(StyleResolverState& state)
{
    state.style()->setBorderFit(state.parentStyle()->borderFit());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitBorderFit(StyleResolverState& state, CSSValue* value)
{
    state.style()->setBorderFit(static_cast<EBorderFit>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyMarginTop(StyleResolverState& state)
{
    state.style()->setMarginTop(RenderStyle::initialMargin());
}

void StyleBuilderFunctions::applyInheritCSSPropertyMarginTop(StyleResolverState& state)
{
    state.style()->setMarginTop(state.parentStyle()->marginTop());
}

void StyleBuilderFunctions::applyValueCSSPropertyMarginTop(StyleResolverState& state, CSSValue* value)
{
    state.style()->setMarginTop(StyleBuilderConverter::convertLengthOrAuto(state, value));
}

void StyleBuilderFunctions::applyInitialCSSPropertyBorderTopStyle(StyleResolverState& state)
{
    state.style()->setBorderTopStyle(RenderStyle::initialBorderStyle());
}

void StyleBuilderFunctions::applyInheritCSSPropertyBorderTopStyle(StyleResolverState& state)
{
    state.style()->setBorderTopStyle(state.parentStyle()->borderTopStyle());
}

void StyleBuilderFunctions::applyValueCSSPropertyBorderTopStyle(StyleResolverState& state, CSSValue* value)
{
    state.style()->setBorderTopStyle(static_cast<EBorderStyle>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyJustifyContent(StyleResolverState& state)
{
    state.style()->setJustifyContent(RenderStyle::initialJustifyContent());
}

void StyleBuilderFunctions::applyInheritCSSPropertyJustifyContent(StyleResolverState& state)
{
    state.style()->setJustifyContent(state.parentStyle()->justifyContent());
}

void StyleBuilderFunctions::applyValueCSSPropertyJustifyContent(StyleResolverState& state, CSSValue* value)
{
    state.style()->setJustifyContent(static_cast<EJustifyContent>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitMarqueeDirection(StyleResolverState& state)
{
    state.style()->setMarqueeDirection(RenderStyle::initialMarqueeDirection());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitMarqueeDirection(StyleResolverState& state)
{
    state.style()->setMarqueeDirection(state.parentStyle()->marqueeDirection());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitMarqueeDirection(StyleResolverState& state, CSSValue* value)
{
    state.style()->setMarqueeDirection(static_cast<EMarqueeDirection>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitMarqueeStyle(StyleResolverState& state)
{
    state.style()->setMarqueeBehavior(RenderStyle::initialMarqueeBehavior());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitMarqueeStyle(StyleResolverState& state)
{
    state.style()->setMarqueeBehavior(state.parentStyle()->marqueeBehavior());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitMarqueeStyle(StyleResolverState& state, CSSValue* value)
{
    state.style()->setMarqueeBehavior(static_cast<EMarqueeBehavior>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertySpeak(StyleResolverState& state)
{
    state.style()->setSpeak(RenderStyle::initialSpeak());
}

void StyleBuilderFunctions::applyInheritCSSPropertySpeak(StyleResolverState& state)
{
    state.style()->setSpeak(state.parentStyle()->speak());
}

void StyleBuilderFunctions::applyValueCSSPropertySpeak(StyleResolverState& state, CSSValue* value)
{
    state.style()->setSpeak(static_cast<ESpeak>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitFlowFrom(StyleResolverState& state)
{
    state.style()->setRegionThread(RenderStyle::initialRegionThread());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitFlowFrom(StyleResolverState& state)
{
    state.style()->setRegionThread(state.parentStyle()->regionThread());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitFlowFrom(StyleResolverState& state, CSSValue* value)
{
    state.style()->setRegionThread(StyleBuilderConverter::convertString<CSSValueNone>(state, value));
}

#if ENABLE(CSS3_TEXT)
void StyleBuilderFunctions::applyInitialCSSPropertyWebkitTextUnderlinePosition(StyleResolverState& state)
{
    state.style()->setTextUnderlinePosition(RenderStyle::initialTextUnderlinePosition());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitTextUnderlinePosition(StyleResolverState& state)
{
    state.style()->setTextUnderlinePosition(state.parentStyle()->textUnderlinePosition());
}

#endif
void StyleBuilderFunctions::applyInitialCSSPropertyFlexGrow(StyleResolverState& state)
{
    state.style()->setFlexGrow(RenderStyle::initialFlexGrow());
}

void StyleBuilderFunctions::applyInheritCSSPropertyFlexGrow(StyleResolverState& state)
{
    state.style()->setFlexGrow(state.parentStyle()->flexGrow());
}

void StyleBuilderFunctions::applyValueCSSPropertyFlexGrow(StyleResolverState& state, CSSValue* value)
{
    state.style()->setFlexGrow(static_cast<float>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyVisibility(StyleResolverState& state)
{
    state.style()->setVisibility(RenderStyle::initialVisibility());
}

void StyleBuilderFunctions::applyInheritCSSPropertyVisibility(StyleResolverState& state)
{
    state.style()->setVisibility(state.parentStyle()->visibility());
}

void StyleBuilderFunctions::applyValueCSSPropertyVisibility(StyleResolverState& state, CSSValue* value)
{
    state.style()->setVisibility(static_cast<EVisibility>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyListStyleImage(StyleResolverState& state)
{
    state.style()->setListStyleImage(RenderStyle::initialListStyleImage());
}

void StyleBuilderFunctions::applyInheritCSSPropertyListStyleImage(StyleResolverState& state)
{
    state.style()->setListStyleImage(state.parentStyle()->listStyleImage());
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitMarginBeforeCollapse(StyleResolverState& state)
{
    state.style()->setMarginBeforeCollapse(RenderStyle::initialMarginBeforeCollapse());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitMarginBeforeCollapse(StyleResolverState& state)
{
    state.style()->setMarginBeforeCollapse(state.parentStyle()->marginBeforeCollapse());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitMarginBeforeCollapse(StyleResolverState& state, CSSValue* value)
{
    state.style()->setMarginBeforeCollapse(static_cast<EMarginCollapse>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitAppearance(StyleResolverState& state)
{
    state.style()->setAppearance(RenderStyle::initialAppearance());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitAppearance(StyleResolverState& state)
{
    state.style()->setAppearance(state.parentStyle()->appearance());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitAppearance(StyleResolverState& state, CSSValue* value)
{
    state.style()->setAppearance(static_cast<ControlPart>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyBorderTopRightRadius(StyleResolverState& state)
{
    state.style()->setBorderTopRightRadius(RenderStyle::initialBorderRadius());
}

void StyleBuilderFunctions::applyInheritCSSPropertyBorderTopRightRadius(StyleResolverState& state)
{
    state.style()->setBorderTopRightRadius(state.parentStyle()->borderTopRightRadius());
}

void StyleBuilderFunctions::applyValueCSSPropertyBorderTopRightRadius(StyleResolverState& state, CSSValue* value)
{
    state.style()->setBorderTopRightRadius(StyleBuilderConverter::convertRadius(state, value));
}

void StyleBuilderFunctions::applyInitialCSSPropertyPointerEvents(StyleResolverState& state)
{
    state.style()->setPointerEvents(RenderStyle::initialPointerEvents());
}

void StyleBuilderFunctions::applyInheritCSSPropertyPointerEvents(StyleResolverState& state)
{
    state.style()->setPointerEvents(state.parentStyle()->pointerEvents());
}

void StyleBuilderFunctions::applyValueCSSPropertyPointerEvents(StyleResolverState& state, CSSValue* value)
{
    state.style()->setPointerEvents(static_cast<EPointerEvents>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitWrapFlow(StyleResolverState& state)
{
    state.style()->setWrapFlow(RenderStyle::initialWrapFlow());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitWrapFlow(StyleResolverState& state)
{
    state.style()->setWrapFlow(state.parentStyle()->wrapFlow());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitWrapFlow(StyleResolverState& state, CSSValue* value)
{
    state.style()->setWrapFlow(static_cast<WrapFlow>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitColumnRuleWidth(StyleResolverState& state)
{
    state.style()->setColumnRuleWidth(RenderStyle::initialColumnRuleWidth());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitColumnRuleWidth(StyleResolverState& state)
{
    state.style()->setColumnRuleWidth(state.parentStyle()->columnRuleWidth());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitColumnRuleWidth(StyleResolverState& state, CSSValue* value)
{
    state.style()->setColumnRuleWidth(StyleBuilderConverter::convertLineWidth<unsigned short>(state, value));
}

void StyleBuilderFunctions::applyInitialCSSPropertyFlexDirection(StyleResolverState& state)
{
    state.style()->setFlexDirection(RenderStyle::initialFlexDirection());
}

void StyleBuilderFunctions::applyInheritCSSPropertyFlexDirection(StyleResolverState& state)
{
    state.style()->setFlexDirection(state.parentStyle()->flexDirection());
}

void StyleBuilderFunctions::applyValueCSSPropertyFlexDirection(StyleResolverState& state, CSSValue* value)
{
    state.style()->setFlexDirection(static_cast<EFlexDirection>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitMaskBoxImage(StyleResolverState& state)
{
    state.style()->setMaskBoxImage(RenderStyle::initialNinePieceImage());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitMaskBoxImage(StyleResolverState& state)
{
    state.style()->setMaskBoxImage(state.parentStyle()->maskBoxImage());
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitBoxOrient(StyleResolverState& state)
{
    state.style()->setBoxOrient(RenderStyle::initialBoxOrient());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitBoxOrient(StyleResolverState& state)
{
    state.style()->setBoxOrient(state.parentStyle()->boxOrient());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitBoxOrient(StyleResolverState& state, CSSValue* value)
{
    state.style()->setBoxOrient(static_cast<EBoxOrient>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitBoxOrdinalGroup(StyleResolverState& state)
{
    state.style()->setBoxOrdinalGroup(RenderStyle::initialBoxOrdinalGroup());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitBoxOrdinalGroup(StyleResolverState& state)
{
    state.style()->setBoxOrdinalGroup(state.parentStyle()->boxOrdinalGroup());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitBoxOrdinalGroup(StyleResolverState& state, CSSValue* value)
{
    state.style()->setBoxOrdinalGroup(static_cast<unsigned int>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyVectorEffect(StyleResolverState& state)
{
    state.style()->accessSVGStyle()->setVectorEffect(SVGRenderStyle::initialVectorEffect());
}

void StyleBuilderFunctions::applyInheritCSSPropertyVectorEffect(StyleResolverState& state)
{
    state.style()->accessSVGStyle()->setVectorEffect(state.parentStyle()->svgStyle()->vectorEffect());
}

void StyleBuilderFunctions::applyValueCSSPropertyVectorEffect(StyleResolverState& state, CSSValue* value)
{
    state.style()->accessSVGStyle()->setVectorEffect(static_cast<EVectorEffect>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitColumnAxis(StyleResolverState& state)
{
    state.style()->setColumnAxis(RenderStyle::initialColumnAxis());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitColumnAxis(StyleResolverState& state)
{
    state.style()->setColumnAxis(state.parentStyle()->columnAxis());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitColumnAxis(StyleResolverState& state, CSSValue* value)
{
    state.style()->setColumnAxis(static_cast<ColumnAxis>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitBoxDirection(StyleResolverState& state)
{
    state.style()->setBoxDirection(RenderStyle::initialBoxDirection());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitBoxDirection(StyleResolverState& state)
{
    state.style()->setBoxDirection(state.parentStyle()->boxDirection());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitBoxDirection(StyleResolverState& state, CSSValue* value)
{
    state.style()->setBoxDirection(static_cast<EBoxDirection>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitUserModify(StyleResolverState& state)
{
    state.style()->setUserModify(RenderStyle::initialUserModify());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitUserModify(StyleResolverState& state)
{
    state.style()->setUserModify(state.parentStyle()->userModify());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitUserModify(StyleResolverState& state, CSSValue* value)
{
    state.style()->setUserModify(static_cast<EUserModify>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitBoxFlex(StyleResolverState& state)
{
    state.style()->setBoxFlex(RenderStyle::initialBoxFlex());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitBoxFlex(StyleResolverState& state)
{
    state.style()->setBoxFlex(state.parentStyle()->boxFlex());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitBoxFlex(StyleResolverState& state, CSSValue* value)
{
    state.style()->setBoxFlex(static_cast<float>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWordWrap(StyleResolverState& state)
{
    state.style()->setOverflowWrap(RenderStyle::initialOverflowWrap());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWordWrap(StyleResolverState& state)
{
    state.style()->setOverflowWrap(state.parentStyle()->overflowWrap());
}

void StyleBuilderFunctions::applyValueCSSPropertyWordWrap(StyleResolverState& state, CSSValue* value)
{
    state.style()->setOverflowWrap(static_cast<EOverflowWrap>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyStrokeLinecap(StyleResolverState& state)
{
    state.style()->accessSVGStyle()->setCapStyle(SVGRenderStyle::initialCapStyle());
}

void StyleBuilderFunctions::applyInheritCSSPropertyStrokeLinecap(StyleResolverState& state)
{
    state.style()->accessSVGStyle()->setCapStyle(state.parentStyle()->svgStyle()->capStyle());
}

void StyleBuilderFunctions::applyValueCSSPropertyStrokeLinecap(StyleResolverState& state, CSSValue* value)
{
    state.style()->accessSVGStyle()->setCapStyle(static_cast<LineCap>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitBoxDecorationBreak(StyleResolverState& state)
{
    state.style()->setBoxDecorationBreak(RenderStyle::initialBoxDecorationBreak());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitBoxDecorationBreak(StyleResolverState& state)
{
    state.style()->setBoxDecorationBreak(state.parentStyle()->boxDecorationBreak());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitBoxDecorationBreak(StyleResolverState& state, CSSValue* value)
{
    state.style()->setBoxDecorationBreak(static_cast<EBoxDecorationBreak>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyListStyleType(StyleResolverState& state)
{
    state.style()->setListStyleType(RenderStyle::initialListStyleType());
}

void StyleBuilderFunctions::applyInheritCSSPropertyListStyleType(StyleResolverState& state)
{
    state.style()->setListStyleType(state.parentStyle()->listStyleType());
}

void StyleBuilderFunctions::applyValueCSSPropertyListStyleType(StyleResolverState& state, CSSValue* value)
{
    state.style()->setListStyleType(static_cast<EListStyleType>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitMarginBottomCollapse(StyleResolverState& state)
{
    state.style()->setMarginAfterCollapse(RenderStyle::initialMarginAfterCollapse());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitMarginBottomCollapse(StyleResolverState& state)
{
    state.style()->setMarginAfterCollapse(state.parentStyle()->marginAfterCollapse());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitMarginBottomCollapse(StyleResolverState& state, CSSValue* value)
{
    state.style()->setMarginAfterCollapse(static_cast<EMarginCollapse>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyOverflowX(StyleResolverState& state)
{
    state.style()->setOverflowX(RenderStyle::initialOverflowX());
}

void StyleBuilderFunctions::applyInheritCSSPropertyOverflowX(StyleResolverState& state)
{
    state.style()->setOverflowX(state.parentStyle()->overflowX());
}

void StyleBuilderFunctions::applyValueCSSPropertyOverflowX(StyleResolverState& state, CSSValue* value)
{
    state.style()->setOverflowX(static_cast<EOverflow>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyBorderLeftStyle(StyleResolverState& state)
{
    state.style()->setBorderLeftStyle(RenderStyle::initialBorderStyle());
}

void StyleBuilderFunctions::applyInheritCSSPropertyBorderLeftStyle(StyleResolverState& state)
{
    state.style()->setBorderLeftStyle(state.parentStyle()->borderLeftStyle());
}

void StyleBuilderFunctions::applyValueCSSPropertyBorderLeftStyle(StyleResolverState& state, CSSValue* value)
{
    state.style()->setBorderLeftStyle(static_cast<EBorderStyle>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyOverflowY(StyleResolverState& state)
{
    state.style()->setOverflowY(RenderStyle::initialOverflowY());
}

void StyleBuilderFunctions::applyInheritCSSPropertyOverflowY(StyleResolverState& state)
{
    state.style()->setOverflowY(state.parentStyle()->overflowY());
}

void StyleBuilderFunctions::applyValueCSSPropertyOverflowY(StyleResolverState& state, CSSValue* value)
{
    state.style()->setOverflowY(static_cast<EOverflow>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyTextAlign(StyleResolverState& state)
{
    state.style()->setTextAlign(RenderStyle::initialTextAlign());
}

void StyleBuilderFunctions::applyInheritCSSPropertyTextAlign(StyleResolverState& state)
{
    state.style()->setTextAlign(state.parentStyle()->textAlign());
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitUserDrag(StyleResolverState& state)
{
    state.style()->setUserDrag(RenderStyle::initialUserDrag());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitUserDrag(StyleResolverState& state)
{
    state.style()->setUserDrag(state.parentStyle()->userDrag());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitUserDrag(StyleResolverState& state, CSSValue* value)
{
    state.style()->setUserDrag(static_cast<EUserDrag>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyMarginRight(StyleResolverState& state)
{
    state.style()->setMarginRight(RenderStyle::initialMargin());
}

void StyleBuilderFunctions::applyInheritCSSPropertyMarginRight(StyleResolverState& state)
{
    state.style()->setMarginRight(state.parentStyle()->marginRight());
}

void StyleBuilderFunctions::applyValueCSSPropertyMarginRight(StyleResolverState& state, CSSValue* value)
{
    state.style()->setMarginRight(StyleBuilderConverter::convertLengthOrAuto(state, value));
}

void StyleBuilderFunctions::applyInitialCSSPropertyPageBreakBefore(StyleResolverState& state)
{
    state.style()->setPageBreakBefore(RenderStyle::initialPageBreak());
}

void StyleBuilderFunctions::applyInheritCSSPropertyPageBreakBefore(StyleResolverState& state)
{
    state.style()->setPageBreakBefore(state.parentStyle()->pageBreakBefore());
}

void StyleBuilderFunctions::applyValueCSSPropertyPageBreakBefore(StyleResolverState& state, CSSValue* value)
{
    state.style()->setPageBreakBefore(static_cast<EPageBreak>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyAlignItems(StyleResolverState& state)
{
    state.style()->setAlignItems(RenderStyle::initialAlignItems());
}

void StyleBuilderFunctions::applyInheritCSSPropertyAlignItems(StyleResolverState& state)
{
    state.style()->setAlignItems(state.parentStyle()->alignItems());
}

void StyleBuilderFunctions::applyValueCSSPropertyAlignItems(StyleResolverState& state, CSSValue* value)
{
    state.style()->setAlignItems(static_cast<EAlignItems>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitColumnSpan(StyleResolverState& state)
{
    state.style()->setColumnSpan(RenderStyle::initialColumnSpan());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitColumnSpan(StyleResolverState& state)
{
    state.style()->setColumnSpan(state.parentStyle()->columnSpan());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitColumnSpan(StyleResolverState& state, CSSValue* value)
{
    state.style()->setColumnSpan(static_cast<ColumnSpan>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyResize(StyleResolverState& state)
{
    state.style()->setResize(RenderStyle::initialResize());
}

void StyleBuilderFunctions::applyInheritCSSPropertyResize(StyleResolverState& state)
{
    state.style()->setResize(state.parentStyle()->resize());
}

void StyleBuilderFunctions::applyInitialCSSPropertyLetterSpacing(StyleResolverState& state)
{
    state.style()->setLetterSpacing(RenderStyle::initialLetterWordSpacing());
}

void StyleBuilderFunctions::applyInheritCSSPropertyLetterSpacing(StyleResolverState& state)
{
    state.style()->setLetterSpacing(state.parentStyle()->letterSpacing());
}

void StyleBuilderFunctions::applyValueCSSPropertyLetterSpacing(StyleResolverState& state, CSSValue* value)
{
    state.style()->setLetterSpacing(StyleBuilderConverter::convertSpacing(state, value));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitTransformOriginZ(StyleResolverState& state)
{
    state.style()->setTransformOriginZ(RenderStyle::initialTransformOriginZ());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitTransformOriginZ(StyleResolverState& state)
{
    state.style()->setTransformOriginZ(state.parentStyle()->transformOriginZ());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitTransformOriginZ(StyleResolverState& state, CSSValue* value)
{
    state.style()->setTransformOriginZ(StyleBuilderConverter::convertComputedLength<float>(state, value));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitTransformStyle(StyleResolverState& state)
{
    state.style()->setTransformStyle3D(RenderStyle::initialTransformStyle3D());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitTransformStyle(StyleResolverState& state)
{
    state.style()->setTransformStyle3D(state.parentStyle()->transformStyle3D());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitTransformStyle(StyleResolverState& state, CSSValue* value)
{
    state.style()->setTransformStyle3D(static_cast<ETransformStyle3D>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitTransformOriginY(StyleResolverState& state)
{
    state.style()->setTransformOriginY(RenderStyle::initialTransformOriginY());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitTransformOriginY(StyleResolverState& state)
{
    state.style()->setTransformOriginY(state.parentStyle()->transformOriginY());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitTransformOriginY(StyleResolverState& state, CSSValue* value)
{
    state.style()->setTransformOriginY(StyleBuilderConverter::convertLength(state, value));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitLineSnap(StyleResolverState& state)
{
    state.style()->setLineSnap(RenderStyle::initialLineSnap());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitLineSnap(StyleResolverState& state)
{
    state.style()->setLineSnap(state.parentStyle()->lineSnap());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitLineSnap(StyleResolverState& state, CSSValue* value)
{
    state.style()->setLineSnap(static_cast<LineSnap>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyLineHeight(StyleResolverState& state)
{
    state.style()->setLineHeight(RenderStyle::initialLineHeight());
}

void StyleBuilderFunctions::applyInheritCSSPropertyLineHeight(StyleResolverState& state)
{
    state.style()->setLineHeight(state.parentStyle()->specifiedLineHeight());
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitTextCombine(StyleResolverState& state)
{
    state.style()->setTextCombine(RenderStyle::initialTextCombine());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitTextCombine(StyleResolverState& state)
{
    state.style()->setTextCombine(state.parentStyle()->textCombine());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitTextCombine(StyleResolverState& state, CSSValue* value)
{
    state.style()->setTextCombine(static_cast<TextCombine>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitBoxFlexGroup(StyleResolverState& state)
{
    state.style()->setBoxFlexGroup(RenderStyle::initialBoxFlexGroup());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitBoxFlexGroup(StyleResolverState& state)
{
    state.style()->setBoxFlexGroup(state.parentStyle()->boxFlexGroup());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitBoxFlexGroup(StyleResolverState& state, CSSValue* value)
{
    state.style()->setBoxFlexGroup(static_cast<unsigned int>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitPerspectiveOriginX(StyleResolverState& state)
{
    state.style()->setPerspectiveOriginX(RenderStyle::initialPerspectiveOriginX());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitPerspectiveOriginX(StyleResolverState& state)
{
    state.style()->setPerspectiveOriginX(state.parentStyle()->perspectiveOriginX());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitPerspectiveOriginX(StyleResolverState& state, CSSValue* value)
{
    state.style()->setPerspectiveOriginX(StyleBuilderConverter::convertLength(state, value));
}

void StyleBuilderFunctions::applyInitialCSSPropertyOpacity(StyleResolverState& state)
{
    state.style()->setOpacity(RenderStyle::initialOpacity());
}

void StyleBuilderFunctions::applyInheritCSSPropertyOpacity(StyleResolverState& state)
{
    state.style()->setOpacity(state.parentStyle()->opacity());
}

void StyleBuilderFunctions::applyValueCSSPropertyOpacity(StyleResolverState& state, CSSValue* value)
{
    state.style()->setOpacity(static_cast<float>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyDominantBaseline(StyleResolverState& state)
{
    state.style()->accessSVGStyle()->setDominantBaseline(SVGRenderStyle::initialDominantBaseline());
}

void StyleBuilderFunctions::applyInheritCSSPropertyDominantBaseline(StyleResolverState& state)
{
    state.style()->accessSVGStyle()->setDominantBaseline(state.parentStyle()->svgStyle()->dominantBaseline());
}

void StyleBuilderFunctions::applyValueCSSPropertyDominantBaseline(StyleResolverState& state, CSSValue* value)
{
    state.style()->accessSVGStyle()->setDominantBaseline(static_cast<EDominantBaseline>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitHyphenateCharacter(StyleResolverState& state)
{
    state.style()->setHyphenationString(RenderStyle::initialHyphenationString());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitHyphenateCharacter(StyleResolverState& state)
{
    state.style()->setHyphenationString(state.parentStyle()->hyphenationString());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitHyphenateCharacter(StyleResolverState& state, CSSValue* value)
{
    state.style()->setHyphenationString(StyleBuilderConverter::convertString<CSSValueAuto>(state, value));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitColumnBreakBefore(StyleResolverState& state)
{
    state.style()->setColumnBreakBefore(RenderStyle::initialPageBreak());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitColumnBreakBefore(StyleResolverState& state)
{
    state.style()->setColumnBreakBefore(state.parentStyle()->columnBreakBefore());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitColumnBreakBefore(StyleResolverState& state, CSSValue* value)
{
    state.style()->setColumnBreakBefore(static_cast<EPageBreak>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyTextTransform(StyleResolverState& state)
{
    state.style()->setTextTransform(RenderStyle::initialTextTransform());
}

void StyleBuilderFunctions::applyInheritCSSPropertyTextTransform(StyleResolverState& state)
{
    state.style()->setTextTransform(state.parentStyle()->textTransform());
}

void StyleBuilderFunctions::applyValueCSSPropertyTextTransform(StyleResolverState& state, CSSValue* value)
{
    state.style()->setTextTransform(static_cast<ETextTransform>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyAlignSelf(StyleResolverState& state)
{
    state.style()->setAlignSelf(RenderStyle::initialAlignSelf());
}

void StyleBuilderFunctions::applyInheritCSSPropertyAlignSelf(StyleResolverState& state)
{
    state.style()->setAlignSelf(state.parentStyle()->alignSelf());
}

void StyleBuilderFunctions::applyValueCSSPropertyAlignSelf(StyleResolverState& state, CSSValue* value)
{
    state.style()->setAlignSelf(static_cast<EAlignItems>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyOrder(StyleResolverState& state)
{
    state.style()->setOrder(RenderStyle::initialOrder());
}

void StyleBuilderFunctions::applyInheritCSSPropertyOrder(StyleResolverState& state)
{
    state.style()->setOrder(state.parentStyle()->order());
}

void StyleBuilderFunctions::applyValueCSSPropertyOrder(StyleResolverState& state, CSSValue* value)
{
    state.style()->setOrder(static_cast<int>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitBoxAlign(StyleResolverState& state)
{
    state.style()->setBoxAlign(RenderStyle::initialBoxAlign());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitBoxAlign(StyleResolverState& state)
{
    state.style()->setBoxAlign(state.parentStyle()->boxAlign());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitBoxAlign(StyleResolverState& state, CSSValue* value)
{
    state.style()->setBoxAlign(static_cast<EBoxAlignment>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyClear(StyleResolverState& state)
{
    state.style()->setClear(RenderStyle::initialClear());
}

void StyleBuilderFunctions::applyInheritCSSPropertyClear(StyleResolverState& state)
{
    state.style()->setClear(state.parentStyle()->clear());
}

void StyleBuilderFunctions::applyValueCSSPropertyClear(StyleResolverState& state, CSSValue* value)
{
    state.style()->setClear(static_cast<EClear>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitColumnBreakInside(StyleResolverState& state)
{
    state.style()->setColumnBreakInside(RenderStyle::initialPageBreak());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitColumnBreakInside(StyleResolverState& state)
{
    state.style()->setColumnBreakInside(state.parentStyle()->columnBreakInside());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitColumnBreakInside(StyleResolverState& state, CSSValue* value)
{
    state.style()->setColumnBreakInside(static_cast<EPageBreak>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyPaddingRight(StyleResolverState& state)
{
    state.style()->setPaddingRight(RenderStyle::initialPadding());
}

void StyleBuilderFunctions::applyInheritCSSPropertyPaddingRight(StyleResolverState& state)
{
    state.style()->setPaddingRight(state.parentStyle()->paddingRight());
}

void StyleBuilderFunctions::applyValueCSSPropertyPaddingRight(StyleResolverState& state, CSSValue* value)
{
    state.style()->setPaddingRight(StyleBuilderConverter::convertLength(state, value));
}

void StyleBuilderFunctions::applyInitialCSSPropertyAlignContent(StyleResolverState& state)
{
    state.style()->setAlignContent(RenderStyle::initialAlignContent());
}

void StyleBuilderFunctions::applyInheritCSSPropertyAlignContent(StyleResolverState& state)
{
    state.style()->setAlignContent(state.parentStyle()->alignContent());
}

void StyleBuilderFunctions::applyValueCSSPropertyAlignContent(StyleResolverState& state, CSSValue* value)
{
    state.style()->setAlignContent(static_cast<EAlignContent>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitShapePadding(StyleResolverState& state)
{
    state.style()->setShapePadding(RenderStyle::initialShapePadding());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitShapePadding(StyleResolverState& state)
{
    state.style()->setShapePadding(state.parentStyle()->shapePadding());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitShapePadding(StyleResolverState& state, CSSValue* value)
{
    state.style()->setShapePadding(StyleBuilderConverter::convertLength(state, value));
}

void StyleBuilderFunctions::applyInitialCSSPropertyColorInterpolation(StyleResolverState& state)
{
    state.style()->accessSVGStyle()->setColorInterpolation(SVGRenderStyle::initialColorInterpolation());
}

void StyleBuilderFunctions::applyInheritCSSPropertyColorInterpolation(StyleResolverState& state)
{
    state.style()->accessSVGStyle()->setColorInterpolation(state.parentStyle()->svgStyle()->colorInterpolation());
}

void StyleBuilderFunctions::applyValueCSSPropertyColorInterpolation(StyleResolverState& state, CSSValue* value)
{
    state.style()->accessSVGStyle()->setColorInterpolation(static_cast<EColorInterpolation>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyDirection(StyleResolverState& state)
{
    state.style()->setDirection(RenderStyle::initialDirection());
}

void StyleBuilderFunctions::applyInheritCSSPropertyDirection(StyleResolverState& state)
{
    state.style()->setDirection(state.parentStyle()->direction());
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitBackfaceVisibility(StyleResolverState& state)
{
    state.style()->setBackfaceVisibility(RenderStyle::initialBackfaceVisibility());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitBackfaceVisibility(StyleResolverState& state)
{
    state.style()->setBackfaceVisibility(state.parentStyle()->backfaceVisibility());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitBackfaceVisibility(StyleResolverState& state, CSSValue* value)
{
    state.style()->setBackfaceVisibility(static_cast<EBackfaceVisibility>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitRegionBreakAfter(StyleResolverState& state)
{
    state.style()->setRegionBreakAfter(RenderStyle::initialPageBreak());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitRegionBreakAfter(StyleResolverState& state)
{
    state.style()->setRegionBreakAfter(state.parentStyle()->regionBreakAfter());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitRegionBreakAfter(StyleResolverState& state, CSSValue* value)
{
    state.style()->setRegionBreakAfter(static_cast<EPageBreak>(*toCSSPrimitiveValue(value)));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitBorderImage(StyleResolverState& state)
{
    state.style()->setBorderImage(RenderStyle::initialNinePieceImage());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitBorderImage(StyleResolverState& state)
{
    state.style()->setBorderImage(state.parentStyle()->borderImage());
}

void StyleBuilderFunctions::applyInitialCSSPropertyPaddingBottom(StyleResolverState& state)
{
    state.style()->setPaddingBottom(RenderStyle::initialPadding());
}

void StyleBuilderFunctions::applyInheritCSSPropertyPaddingBottom(StyleResolverState& state)
{
    state.style()->setPaddingBottom(state.parentStyle()->paddingBottom());
}

void StyleBuilderFunctions::applyValueCSSPropertyPaddingBottom(StyleResolverState& state, CSSValue* value)
{
    state.style()->setPaddingBottom(StyleBuilderConverter::convertLength(state, value));
}

void StyleBuilderFunctions::applyInitialCSSPropertyMarginLeft(StyleResolverState& state)
{
    state.style()->setMarginLeft(RenderStyle::initialMargin());
}

void StyleBuilderFunctions::applyInheritCSSPropertyMarginLeft(StyleResolverState& state)
{
    state.style()->setMarginLeft(state.parentStyle()->marginLeft());
}

void StyleBuilderFunctions::applyValueCSSPropertyMarginLeft(StyleResolverState& state, CSSValue* value)
{
    state.style()->setMarginLeft(StyleBuilderConverter::convertLengthOrAuto(state, value));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitRegionBreakInside(StyleResolverState& state)
{
    state.style()->setRegionBreakInside(RenderStyle::initialPageBreak());
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitRegionBreakInside(StyleResolverState& state)
{
    state.style()->setRegionBreakInside(state.parentStyle()->regionBreakInside());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitRegionBreakInside(StyleResolverState& state, CSSValue* value)
{
    state.style()->setRegionBreakInside(static_cast<EPageBreak>(*toCSSPrimitiveValue(value)));
}


bool StyleBuilder::applyProperty(CSSPropertyID property, StyleResolverState& state, CSSValue* value, bool isInitial, bool isInherit) {
    switch(property) {
    case CSSPropertyWebkitShapeOutside:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitShapeOutside(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitShapeOutside(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitShapeOutside(state, value);
        return true;

    case CSSPropertyPosition:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyPosition(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyPosition(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyPosition(state, value);
        return true;

    case CSSPropertyWebkitMaskBoxImageRepeat:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitMaskBoxImageRepeat(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitMaskBoxImageRepeat(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitMaskBoxImageRepeat(state, value);
        return true;

    case CSSPropertyTextAnchor:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyTextAnchor(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyTextAnchor(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyTextAnchor(state, value);
        return true;

    case CSSPropertyFlexWrap:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyFlexWrap(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyFlexWrap(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyFlexWrap(state, value);
        return true;

    case CSSPropertyWebkitBorderHorizontalSpacing:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitBorderHorizontalSpacing(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitBorderHorizontalSpacing(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitBorderHorizontalSpacing(state, value);
        return true;

    case CSSPropertySize:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertySize(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertySize(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertySize(state, value);
        return true;

    case CSSPropertyWebkitAnimationPlayState:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitAnimationPlayState(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitAnimationPlayState(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitAnimationPlayState(state, value);
        return true;

    case CSSPropertyFillRule:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyFillRule(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyFillRule(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyFillRule(state, value);
        return true;

    case CSSPropertyWebkitAnimationFillMode:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitAnimationFillMode(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitAnimationFillMode(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitAnimationFillMode(state, value);
        return true;

    case CSSPropertyCaptionSide:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyCaptionSide(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyCaptionSide(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyCaptionSide(state, value);
        return true;

    case CSSPropertyWebkitMarqueeSpeed:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitMarqueeSpeed(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitMarqueeSpeed(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitMarqueeSpeed(state, value);
        return true;

    case CSSPropertyBorderLeftColor:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyBorderLeftColor(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyBorderLeftColor(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyBorderLeftColor(state, value);
        return true;

    case CSSPropertyTextDecoration:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyTextDecoration(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyTextDecoration(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyTextDecoration(state, value);
        return true;

    case CSSPropertyColorRendering:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyColorRendering(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyColorRendering(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyColorRendering(state, value);
        return true;

    case CSSPropertyWebkitPrintColorAdjust:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitPrintColorAdjust(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitPrintColorAdjust(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitPrintColorAdjust(state, value);
        return true;

    case CSSPropertyClipRule:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyClipRule(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyClipRule(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyClipRule(state, value);
        return true;

    case CSSPropertyWebkitMaskBoxImageWidth:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitMaskBoxImageWidth(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitMaskBoxImageWidth(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitMaskBoxImageWidth(state, value);
        return true;

    case CSSPropertyMaxHeight:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyMaxHeight(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyMaxHeight(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyMaxHeight(state, value);
        return true;

    case CSSPropertyFlexBasis:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyFlexBasis(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyFlexBasis(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyFlexBasis(state, value);
        return true;

    case CSSPropertyWebkitTextFillColor:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitTextFillColor(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitTextFillColor(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitTextFillColor(state, value);
        return true;

    case CSSPropertyMixBlendMode:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyMixBlendMode(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyMixBlendMode(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyMixBlendMode(state, value);
        return true;

    case CSSPropertyWidows:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWidows(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWidows(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWidows(state, value);
        return true;

    case CSSPropertyWebkitRubyPosition:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitRubyPosition(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitRubyPosition(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitRubyPosition(state, value);
        return true;

    case CSSPropertyBufferedRendering:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyBufferedRendering(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyBufferedRendering(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyBufferedRendering(state, value);
        return true;

    case CSSPropertyWebkitTransitionTimingFunction:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitTransitionTimingFunction(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitTransitionTimingFunction(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitTransitionTimingFunction(state, value);
        return true;

    case CSSPropertyZIndex:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyZIndex(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyZIndex(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyZIndex(state, value);
        return true;

    case CSSPropertyFlexShrink:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyFlexShrink(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyFlexShrink(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyFlexShrink(state, value);
        return true;

    case CSSPropertyWebkitMaskBoxImageSlice:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitMaskBoxImageSlice(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitMaskBoxImageSlice(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitMaskBoxImageSlice(state, value);
        return true;

    case CSSPropertyWebkitTransformOriginX:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitTransformOriginX(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitTransformOriginX(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitTransformOriginX(state, value);
        return true;

    case CSSPropertyPaddingLeft:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyPaddingLeft(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyPaddingLeft(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyPaddingLeft(state, value);
        return true;

    case CSSPropertyStrokeLinejoin:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyStrokeLinejoin(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyStrokeLinejoin(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyStrokeLinejoin(state, value);
        return true;

    case CSSPropertyWhiteSpace:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWhiteSpace(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWhiteSpace(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWhiteSpace(state, value);
        return true;

    case CSSPropertyBackgroundClip:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyBackgroundClip(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyBackgroundClip(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyBackgroundClip(state, value);
        return true;

    case CSSPropertyWritingMode:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWritingMode(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWritingMode(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWritingMode(state, value);
        return true;

    case CSSPropertyWebkitFlowInto:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitFlowInto(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitFlowInto(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitFlowInto(state, value);
        return true;

    case CSSPropertyOverflowWrap:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyOverflowWrap(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyOverflowWrap(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyOverflowWrap(state, value);
        return true;

    case CSSPropertyTextDecorationColor:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyTextDecorationColor(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyTextDecorationColor(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyTextDecorationColor(state, value);
        return true;

    case CSSPropertyWebkitTransitionDelay:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitTransitionDelay(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitTransitionDelay(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitTransitionDelay(state, value);
        return true;

    case CSSPropertyVerticalAlign:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyVerticalAlign(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyVerticalAlign(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyVerticalAlign(state, value);
        return true;

    case CSSPropertyWebkitColumnBreakAfter:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitColumnBreakAfter(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitColumnBreakAfter(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitColumnBreakAfter(state, value);
        return true;

    case CSSPropertyBackgroundPositionY:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyBackgroundPositionY(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyBackgroundPositionY(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyBackgroundPositionY(state, value);
        return true;

    case CSSPropertyBackgroundPositionX:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyBackgroundPositionX(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyBackgroundPositionX(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyBackgroundPositionX(state, value);
        return true;

    case CSSPropertyWebkitBoxPack:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitBoxPack(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitBoxPack(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitBoxPack(state, value);
        return true;

    case CSSPropertyWebkitColumnCount:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitColumnCount(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitColumnCount(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitColumnCount(state, value);
        return true;

    case CSSPropertyWebkitMaskRepeatY:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitMaskRepeatY(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitMaskRepeatY(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitMaskRepeatY(state, value);
        return true;

    case CSSPropertyWebkitColumnProgression:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitColumnProgression(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitColumnProgression(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitColumnProgression(state, value);
        return true;

    case CSSPropertyAlignmentBaseline:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyAlignmentBaseline(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyAlignmentBaseline(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyAlignmentBaseline(state, value);
        return true;

    case CSSPropertyWebkitMarginAfterCollapse:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitMarginAfterCollapse(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitMarginAfterCollapse(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitMarginAfterCollapse(state, value);
        return true;

    case CSSPropertyOutlineWidth:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyOutlineWidth(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyOutlineWidth(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyOutlineWidth(state, value);
        return true;

    case CSSPropertyWebkitClipPath:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitClipPath(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitClipPath(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitClipPath(state, value);
        return true;

    case CSSPropertyWebkitMaskOrigin:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitMaskOrigin(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitMaskOrigin(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitMaskOrigin(state, value);
        return true;

    case CSSPropertyWordSpacing:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWordSpacing(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWordSpacing(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWordSpacing(state, value);
        return true;

    case CSSPropertyPageBreakAfter:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyPageBreakAfter(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyPageBreakAfter(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyPageBreakAfter(state, value);
        return true;

    case CSSPropertyOutlineStyle:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyOutlineStyle(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyOutlineStyle(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyOutlineStyle(state, value);
        return true;

    case CSSPropertyMinWidth:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyMinWidth(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyMinWidth(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyMinWidth(state, value);
        return true;

    case CSSPropertyGridAutoFlow:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyGridAutoFlow(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyGridAutoFlow(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyGridAutoFlow(state, value);
        return true;

    case CSSPropertyWebkitAnimationName:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitAnimationName(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitAnimationName(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitAnimationName(state, value);
        return true;

    case CSSPropertyMaskType:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyMaskType(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyMaskType(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyMaskType(state, value);
        return true;

    case CSSPropertyBackgroundOrigin:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyBackgroundOrigin(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyBackgroundOrigin(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyBackgroundOrigin(state, value);
        return true;

    case CSSPropertyWebkitShapeMargin:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitShapeMargin(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitShapeMargin(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitShapeMargin(state, value);
        return true;

    case CSSPropertyBorderBottomRightRadius:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyBorderBottomRightRadius(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyBorderBottomRightRadius(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyBorderBottomRightRadius(state, value);
        return true;

    case CSSPropertyWebkitColumnWidth:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitColumnWidth(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitColumnWidth(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitColumnWidth(state, value);
        return true;

    case CSSPropertyWebkitMarqueeRepetition:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitMarqueeRepetition(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitMarqueeRepetition(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitMarqueeRepetition(state, value);
        return true;

    case CSSPropertyWebkitPerspectiveOriginY:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitPerspectiveOriginY(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitPerspectiveOriginY(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitPerspectiveOriginY(state, value);
        return true;

    case CSSPropertyTextAlignLast:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyTextAlignLast(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyTextAlignLast(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyTextAlignLast(state, value);
        return true;

    case CSSPropertyWebkitWrapThrough:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitWrapThrough(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitWrapThrough(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitWrapThrough(state, value);
        return true;

    case CSSPropertyBorderRightColor:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyBorderRightColor(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyBorderRightColor(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyBorderRightColor(state, value);
        return true;

    case CSSPropertyWebkitLineClamp:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitLineClamp(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitLineClamp(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitLineClamp(state, value);
        return true;

    case CSSPropertyPageBreakInside:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyPageBreakInside(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyPageBreakInside(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyPageBreakInside(state, value);
        return true;

    case CSSPropertyMinHeight:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyMinHeight(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyMinHeight(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyMinHeight(state, value);
        return true;

    case CSSPropertyCursor:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyCursor(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyCursor(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyCursor(state, value);
        return true;

    case CSSPropertyWebkitMaskComposite:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitMaskComposite(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitMaskComposite(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitMaskComposite(state, value);
        return true;

    case CSSPropertyWebkitBoxLines:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitBoxLines(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitBoxLines(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitBoxLines(state, value);
        return true;

    case CSSPropertyTabSize:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyTabSize(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyTabSize(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyTabSize(state, value);
        return true;

    case CSSPropertyWebkitMaskImage:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitMaskImage(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitMaskImage(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitMaskImage(state, value);
        return true;

    case CSSPropertyZoom:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyZoom(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyZoom(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyZoom(state, value);
        return true;

    case CSSPropertyBorderBottomStyle:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyBorderBottomStyle(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyBorderBottomStyle(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyBorderBottomStyle(state, value);
        return true;

    case CSSPropertyColorInterpolationFilters:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyColorInterpolationFilters(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyColorInterpolationFilters(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyColorInterpolationFilters(state, value);
        return true;

    case CSSPropertyHeight:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyHeight(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyHeight(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyHeight(state, value);
        return true;

    case CSSPropertyWebkitShapeInside:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitShapeInside(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitShapeInside(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitShapeInside(state, value);
        return true;

    case CSSPropertyWebkitLineGrid:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitLineGrid(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitLineGrid(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitLineGrid(state, value);
        return true;

    case CSSPropertyCounterIncrement:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyCounterIncrement(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyCounterIncrement(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyCounterIncrement(state, value);
        return true;

    case CSSPropertyBorderBottomWidth:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyBorderBottomWidth(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyBorderBottomWidth(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyBorderBottomWidth(state, value);
        return true;

    case CSSPropertyTextRendering:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyTextRendering(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyTextRendering(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyTextRendering(state, value);
        return true;

    case CSSPropertyTableLayout:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyTableLayout(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyTableLayout(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyTableLayout(state, value);
        return true;

    case CSSPropertyMaxWidth:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyMaxWidth(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyMaxWidth(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyMaxWidth(state, value);
        return true;

    case CSSPropertyFontStyle:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyFontStyle(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyFontStyle(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyFontStyle(state, value);
        return true;

    case CSSPropertyBorderRightStyle:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyBorderRightStyle(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyBorderRightStyle(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyBorderRightStyle(state, value);
        return true;

    case CSSPropertyWebkitHighlight:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitHighlight(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitHighlight(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitHighlight(state, value);
        return true;

    case CSSPropertyEmptyCells:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyEmptyCells(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyEmptyCells(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyEmptyCells(state, value);
        return true;

    case CSSPropertyWebkitRegionBreakBefore:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitRegionBreakBefore(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitRegionBreakBefore(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitRegionBreakBefore(state, value);
        return true;

    case CSSPropertyBorderRightWidth:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyBorderRightWidth(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyBorderRightWidth(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyBorderRightWidth(state, value);
        return true;

    case CSSPropertyBorderImageSource:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyBorderImageSource(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyBorderImageSource(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyBorderImageSource(state, value);
        return true;

    case CSSPropertyWebkitAnimationTimingFunction:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitAnimationTimingFunction(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitAnimationTimingFunction(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitAnimationTimingFunction(state, value);
        return true;

    case CSSPropertyBorderTopLeftRadius:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyBorderTopLeftRadius(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyBorderTopLeftRadius(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyBorderTopLeftRadius(state, value);
        return true;

    case CSSPropertyRight:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyRight(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyRight(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyRight(state, value);
        return true;

    case CSSPropertyBorderBottomLeftRadius:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyBorderBottomLeftRadius(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyBorderBottomLeftRadius(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyBorderBottomLeftRadius(state, value);
        return true;

    case CSSPropertyFontVariant:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyFontVariant(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyFontVariant(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyFontVariant(state, value);
        return true;

    case CSSPropertyBoxSizing:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyBoxSizing(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyBoxSizing(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyBoxSizing(state, value);
        return true;

    case CSSPropertyTextOverflow:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyTextOverflow(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyTextOverflow(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyTextOverflow(state, value);
        return true;

    case CSSPropertyBackgroundAttachment:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyBackgroundAttachment(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyBackgroundAttachment(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyBackgroundAttachment(state, value);
        return true;

    case CSSPropertyWebkitRegionFragment:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitRegionFragment(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitRegionFragment(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitRegionFragment(state, value);
        return true;

    case CSSPropertyWebkitTextSecurity:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitTextSecurity(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitTextSecurity(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitTextSecurity(state, value);
        return true;

    case CSSPropertyWebkitAnimationDirection:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitAnimationDirection(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitAnimationDirection(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitAnimationDirection(state, value);
        return true;

    case CSSPropertyBorderLeftWidth:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyBorderLeftWidth(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyBorderLeftWidth(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyBorderLeftWidth(state, value);
        return true;

    case CSSPropertyBackgroundBlendMode:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyBackgroundBlendMode(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyBackgroundBlendMode(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyBackgroundBlendMode(state, value);
        return true;

    case CSSPropertyWebkitMaskPositionX:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitMaskPositionX(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitMaskPositionX(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitMaskPositionX(state, value);
        return true;

    case CSSPropertyWebkitLineBreak:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitLineBreak(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitLineBreak(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitLineBreak(state, value);
        return true;

    case CSSPropertyWebkitMarqueeIncrement:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitMarqueeIncrement(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitMarqueeIncrement(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitMarqueeIncrement(state, value);
        return true;

    case CSSPropertyBackgroundImage:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyBackgroundImage(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyBackgroundImage(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyBackgroundImage(state, value);
        return true;

    case CSSPropertyLeft:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyLeft(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyLeft(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyLeft(state, value);
        return true;

    case CSSPropertyWebkitMaskClip:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitMaskClip(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitMaskClip(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitMaskClip(state, value);
        return true;

    case CSSPropertyWebkitAnimationDelay:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitAnimationDelay(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitAnimationDelay(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitAnimationDelay(state, value);
        return true;

    case CSSPropertyTextDecorationStyle:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyTextDecorationStyle(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyTextDecorationStyle(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyTextDecorationStyle(state, value);
        return true;

    case CSSPropertyWebkitTextEmphasisPosition:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitTextEmphasisPosition(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitTextEmphasisPosition(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitTextEmphasisPosition(state, value);
        return true;

    case CSSPropertyWebkitFontKerning:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitFontKerning(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitFontKerning(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitFontKerning(state, value);
        return true;

    case CSSPropertyWebkitFontVariantLigatures:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitFontVariantLigatures(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitFontVariantLigatures(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitFontVariantLigatures(state, value);
        return true;

    case CSSPropertyWidth:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWidth(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWidth(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWidth(state, value);
        return true;

    case CSSPropertyWebkitLineAlign:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitLineAlign(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitLineAlign(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitLineAlign(state, value);
        return true;

    case CSSPropertyCounterReset:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyCounterReset(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyCounterReset(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyCounterReset(state, value);
        return true;

    case CSSPropertyWebkitMaskRepeatX:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitMaskRepeatX(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitMaskRepeatX(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitMaskRepeatX(state, value);
        return true;

    case CSSPropertyBorderImageSlice:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyBorderImageSlice(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyBorderImageSlice(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyBorderImageSlice(state, value);
        return true;

    case CSSPropertyWebkitBackgroundClip:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyBackgroundClip(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyBackgroundClip(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyBackgroundClip(state, value);
        return true;

    case CSSPropertyTouchAction:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyTouchAction(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyTouchAction(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyTouchAction(state, value);
        return true;

    case CSSPropertyWebkitBackgroundComposite:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitBackgroundComposite(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitBackgroundComposite(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitBackgroundComposite(state, value);
        return true;

    case CSSPropertyWebkitTransitionProperty:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitTransitionProperty(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitTransitionProperty(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitTransitionProperty(state, value);
        return true;

    case CSSPropertyWebkitMaskBoxImageSource:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitMaskBoxImageSource(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitMaskBoxImageSource(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitMaskBoxImageSource(state, value);
        return true;

    case CSSPropertyBorderTopColor:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyBorderTopColor(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyBorderTopColor(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyBorderTopColor(state, value);
        return true;

    case CSSPropertyWebkitMaskPositionY:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitMaskPositionY(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitMaskPositionY(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitMaskPositionY(state, value);
        return true;

    case CSSPropertyWebkitAnimationIterationCount:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitAnimationIterationCount(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitAnimationIterationCount(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitAnimationIterationCount(state, value);
        return true;

    case CSSPropertyBackgroundColor:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyBackgroundColor(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyBackgroundColor(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyBackgroundColor(state, value);
        return true;

    case CSSPropertyOutlineColor:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyOutlineColor(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyOutlineColor(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyOutlineColor(state, value);
        return true;

    case CSSPropertyPaddingTop:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyPaddingTop(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyPaddingTop(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyPaddingTop(state, value);
        return true;

    case CSSPropertyBorderTopWidth:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyBorderTopWidth(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyBorderTopWidth(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyBorderTopWidth(state, value);
        return true;

    case CSSPropertyWebkitBorderVerticalSpacing:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitBorderVerticalSpacing(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitBorderVerticalSpacing(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitBorderVerticalSpacing(state, value);
        return true;

    case CSSPropertyBottom:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyBottom(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyBottom(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyBottom(state, value);
        return true;

    case CSSPropertyBorderCollapse:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyBorderCollapse(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyBorderCollapse(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyBorderCollapse(state, value);
        return true;

    case CSSPropertyWebkitMaskBoxImageOutset:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitMaskBoxImageOutset(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitMaskBoxImageOutset(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitMaskBoxImageOutset(state, value);
        return true;

    case CSSPropertyWebkitMarginTopCollapse:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitMarginTopCollapse(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitMarginTopCollapse(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitMarginTopCollapse(state, value);
        return true;

    case CSSPropertyTop:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyTop(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyTop(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyTop(state, value);
        return true;

    case CSSPropertyMarginBottom:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyMarginBottom(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyMarginBottom(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyMarginBottom(state, value);
        return true;

    case CSSPropertyImageRendering:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyImageRendering(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyImageRendering(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyImageRendering(state, value);
        return true;

    case CSSPropertyWebkitColumnRuleStyle:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitColumnRuleStyle(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitColumnRuleStyle(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitColumnRuleStyle(state, value);
        return true;

    case CSSPropertyWebkitColumnGap:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitColumnGap(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitColumnGap(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitColumnGap(state, value);
        return true;

    case CSSPropertyListStylePosition:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyListStylePosition(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyListStylePosition(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyListStylePosition(state, value);
        return true;

    case CSSPropertyUnicodeBidi:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyUnicodeBidi(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyUnicodeBidi(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyUnicodeBidi(state, value);
        return true;

    case CSSPropertyFloat:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyFloat(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyFloat(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyFloat(state, value);
        return true;

    case CSSPropertyWebkitRtlOrdering:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitRtlOrdering(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitRtlOrdering(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitRtlOrdering(state, value);
        return true;

    case CSSPropertyWebkitAnimationDuration:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitAnimationDuration(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitAnimationDuration(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitAnimationDuration(state, value);
        return true;

    case CSSPropertyWebkitTextEmphasisColor:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitTextEmphasisColor(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitTextEmphasisColor(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitTextEmphasisColor(state, value);
        return true;

    case CSSPropertyWebkitTransitionDuration:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitTransitionDuration(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitTransitionDuration(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitTransitionDuration(state, value);
        return true;

    case CSSPropertyDisplay:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyDisplay(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyDisplay(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyDisplay(state, value);
        return true;

    case CSSPropertyWebkitTextEmphasisStyle:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitTextEmphasisStyle(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitTextEmphasisStyle(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitTextEmphasisStyle(state, value);
        return true;

    case CSSPropertyOutlineOffset:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyOutlineOffset(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyOutlineOffset(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyOutlineOffset(state, value);
        return true;

    case CSSPropertyShapeRendering:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyShapeRendering(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyShapeRendering(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyShapeRendering(state, value);
        return true;

    case CSSPropertyWebkitUserSelect:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitUserSelect(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitUserSelect(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitUserSelect(state, value);
        return true;

    case CSSPropertyWebkitMaskSize:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitMaskSize(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitMaskSize(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitMaskSize(state, value);
        return true;

    case CSSPropertyWordBreak:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWordBreak(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWordBreak(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWordBreak(state, value);
        return true;

    case CSSPropertyWebkitBorderFit:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitBorderFit(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitBorderFit(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitBorderFit(state, value);
        return true;

    case CSSPropertyMarginTop:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyMarginTop(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyMarginTop(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyMarginTop(state, value);
        return true;

    case CSSPropertyBorderTopStyle:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyBorderTopStyle(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyBorderTopStyle(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyBorderTopStyle(state, value);
        return true;

    case CSSPropertyJustifyContent:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyJustifyContent(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyJustifyContent(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyJustifyContent(state, value);
        return true;

    case CSSPropertyWebkitMarqueeDirection:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitMarqueeDirection(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitMarqueeDirection(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitMarqueeDirection(state, value);
        return true;

    case CSSPropertyWebkitMarqueeStyle:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitMarqueeStyle(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitMarqueeStyle(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitMarqueeStyle(state, value);
        return true;

    case CSSPropertyTextIndent:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyTextIndent(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyTextIndent(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyTextIndent(state, value);
        return true;

    case CSSPropertyBorderImageOutset:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyBorderImageOutset(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyBorderImageOutset(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyBorderImageOutset(state, value);
        return true;

    case CSSPropertySpeak:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertySpeak(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertySpeak(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertySpeak(state, value);
        return true;

    case CSSPropertyFontFamily:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyFontFamily(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyFontFamily(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyFontFamily(state, value);
        return true;

    case CSSPropertyBorderImageWidth:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyBorderImageWidth(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyBorderImageWidth(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyBorderImageWidth(state, value);
        return true;

    case CSSPropertyWebkitBackgroundSize:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyBackgroundSize(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyBackgroundSize(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyBackgroundSize(state, value);
        return true;

    case CSSPropertyWebkitFlowFrom:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitFlowFrom(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitFlowFrom(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitFlowFrom(state, value);
        return true;

#if ENABLE(CSS3_TEXT)
    case CSSPropertyWebkitTextUnderlinePosition:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitTextUnderlinePosition(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitTextUnderlinePosition(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitTextUnderlinePosition(state, value);
        return true;
#endif

    case CSSPropertyFlexGrow:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyFlexGrow(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyFlexGrow(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyFlexGrow(state, value);
        return true;

    case CSSPropertyVisibility:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyVisibility(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyVisibility(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyVisibility(state, value);
        return true;

    case CSSPropertyListStyleImage:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyListStyleImage(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyListStyleImage(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyListStyleImage(state, value);
        return true;

    case CSSPropertyWebkitMarginBeforeCollapse:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitMarginBeforeCollapse(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitMarginBeforeCollapse(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitMarginBeforeCollapse(state, value);
        return true;

    case CSSPropertyWebkitAppearance:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitAppearance(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitAppearance(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitAppearance(state, value);
        return true;

    case CSSPropertyBorderTopRightRadius:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyBorderTopRightRadius(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyBorderTopRightRadius(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyBorderTopRightRadius(state, value);
        return true;

    case CSSPropertyPointerEvents:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyPointerEvents(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyPointerEvents(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyPointerEvents(state, value);
        return true;

    case CSSPropertyWebkitWrapFlow:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitWrapFlow(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitWrapFlow(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitWrapFlow(state, value);
        return true;

    case CSSPropertyWebkitColumnRuleWidth:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitColumnRuleWidth(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitColumnRuleWidth(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitColumnRuleWidth(state, value);
        return true;

    case CSSPropertyFlexDirection:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyFlexDirection(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyFlexDirection(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyFlexDirection(state, value);
        return true;

    case CSSPropertyWebkitMaskBoxImage:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitMaskBoxImage(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitMaskBoxImage(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitMaskBoxImage(state, value);
        return true;

    case CSSPropertyWebkitBoxOrient:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitBoxOrient(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitBoxOrient(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitBoxOrient(state, value);
        return true;

    case CSSPropertyWebkitBoxOrdinalGroup:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitBoxOrdinalGroup(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitBoxOrdinalGroup(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitBoxOrdinalGroup(state, value);
        return true;

    case CSSPropertyVectorEffect:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyVectorEffect(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyVectorEffect(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyVectorEffect(state, value);
        return true;

    case CSSPropertyWebkitColumnAxis:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitColumnAxis(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitColumnAxis(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitColumnAxis(state, value);
        return true;

    case CSSPropertyWebkitBoxDirection:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitBoxDirection(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitBoxDirection(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitBoxDirection(state, value);
        return true;

    case CSSPropertyWebkitUserModify:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitUserModify(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitUserModify(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitUserModify(state, value);
        return true;

    case CSSPropertyWebkitBoxFlex:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitBoxFlex(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitBoxFlex(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitBoxFlex(state, value);
        return true;

    case CSSPropertyBorderImageRepeat:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyBorderImageRepeat(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyBorderImageRepeat(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyBorderImageRepeat(state, value);
        return true;

    case CSSPropertyWordWrap:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWordWrap(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWordWrap(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWordWrap(state, value);
        return true;

    case CSSPropertyStrokeLinecap:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyStrokeLinecap(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyStrokeLinecap(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyStrokeLinecap(state, value);
        return true;

    case CSSPropertyWebkitBoxDecorationBreak:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitBoxDecorationBreak(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitBoxDecorationBreak(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitBoxDecorationBreak(state, value);
        return true;

    case CSSPropertyListStyleType:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyListStyleType(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyListStyleType(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyListStyleType(state, value);
        return true;

    case CSSPropertyWebkitMarginBottomCollapse:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitMarginBottomCollapse(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitMarginBottomCollapse(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitMarginBottomCollapse(state, value);
        return true;

    case CSSPropertyOverflowX:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyOverflowX(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyOverflowX(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyOverflowX(state, value);
        return true;

    case CSSPropertyFontWeight:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyFontWeight(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyFontWeight(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyFontWeight(state, value);
        return true;

    case CSSPropertyTextDecorationLine:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyTextDecoration(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyTextDecoration(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyTextDecoration(state, value);
        return true;

    case CSSPropertyBorderLeftStyle:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyBorderLeftStyle(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyBorderLeftStyle(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyBorderLeftStyle(state, value);
        return true;

    case CSSPropertyOverflowY:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyOverflowY(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyOverflowY(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyOverflowY(state, value);
        return true;

    case CSSPropertyTextAlign:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyTextAlign(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyTextAlign(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyTextAlign(state, value);
        return true;

    case CSSPropertyWebkitUserDrag:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitUserDrag(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitUserDrag(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitUserDrag(state, value);
        return true;

    case CSSPropertyMarginRight:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyMarginRight(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyMarginRight(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyMarginRight(state, value);
        return true;

    case CSSPropertyWebkitFontSmoothing:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitFontSmoothing(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitFontSmoothing(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitFontSmoothing(state, value);
        return true;

    case CSSPropertyPageBreakBefore:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyPageBreakBefore(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyPageBreakBefore(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyPageBreakBefore(state, value);
        return true;

    case CSSPropertyAlignItems:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyAlignItems(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyAlignItems(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyAlignItems(state, value);
        return true;

    case CSSPropertyWebkitColumnSpan:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitColumnSpan(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitColumnSpan(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitColumnSpan(state, value);
        return true;

    case CSSPropertyWebkitBackgroundOrigin:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyBackgroundOrigin(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyBackgroundOrigin(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyBackgroundOrigin(state, value);
        return true;

    case CSSPropertyWebkitColumnRuleColor:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitColumnRuleColor(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitColumnRuleColor(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitColumnRuleColor(state, value);
        return true;

    case CSSPropertyResize:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyResize(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyResize(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyResize(state, value);
        return true;

    case CSSPropertyLetterSpacing:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyLetterSpacing(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyLetterSpacing(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyLetterSpacing(state, value);
        return true;

    case CSSPropertyOrphans:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyOrphans(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyOrphans(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyOrphans(state, value);
        return true;

    case CSSPropertyWebkitTransformOriginZ:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitTransformOriginZ(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitTransformOriginZ(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitTransformOriginZ(state, value);
        return true;

    case CSSPropertyWebkitTransformStyle:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitTransformStyle(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitTransformStyle(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitTransformStyle(state, value);
        return true;

    case CSSPropertyWebkitTransformOriginY:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitTransformOriginY(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitTransformOriginY(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitTransformOriginY(state, value);
        return true;

    case CSSPropertyWebkitTextStrokeColor:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitTextStrokeColor(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitTextStrokeColor(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitTextStrokeColor(state, value);
        return true;

    case CSSPropertyWebkitLineSnap:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitLineSnap(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitLineSnap(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitLineSnap(state, value);
        return true;

    case CSSPropertyLineHeight:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyLineHeight(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyLineHeight(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyLineHeight(state, value);
        return true;

    case CSSPropertyWebkitTextCombine:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitTextCombine(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitTextCombine(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitTextCombine(state, value);
        return true;

    case CSSPropertyWebkitBoxFlexGroup:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitBoxFlexGroup(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitBoxFlexGroup(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitBoxFlexGroup(state, value);
        return true;

    case CSSPropertyWebkitPerspectiveOriginX:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitPerspectiveOriginX(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitPerspectiveOriginX(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitPerspectiveOriginX(state, value);
        return true;

    case CSSPropertyOpacity:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyOpacity(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyOpacity(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyOpacity(state, value);
        return true;

    case CSSPropertyDominantBaseline:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyDominantBaseline(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyDominantBaseline(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyDominantBaseline(state, value);
        return true;

    case CSSPropertyWebkitAspectRatio:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitAspectRatio(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitAspectRatio(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitAspectRatio(state, value);
        return true;

    case CSSPropertyWebkitPerspectiveOrigin:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitPerspectiveOrigin(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitPerspectiveOrigin(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitPerspectiveOrigin(state, value);
        return true;

    case CSSPropertyWebkitHyphenateCharacter:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitHyphenateCharacter(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitHyphenateCharacter(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitHyphenateCharacter(state, value);
        return true;

    case CSSPropertyWebkitColumnBreakBefore:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitColumnBreakBefore(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitColumnBreakBefore(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitColumnBreakBefore(state, value);
        return true;

    case CSSPropertyTextTransform:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyTextTransform(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyTextTransform(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyTextTransform(state, value);
        return true;

    case CSSPropertyBackgroundRepeatY:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyBackgroundRepeatY(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyBackgroundRepeatY(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyBackgroundRepeatY(state, value);
        return true;

    case CSSPropertyBackgroundRepeatX:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyBackgroundRepeatX(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyBackgroundRepeatX(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyBackgroundRepeatX(state, value);
        return true;

    case CSSPropertyBorderBottomColor:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyBorderBottomColor(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyBorderBottomColor(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyBorderBottomColor(state, value);
        return true;

    case CSSPropertyAlignSelf:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyAlignSelf(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyAlignSelf(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyAlignSelf(state, value);
        return true;

    case CSSPropertyFontSize:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyFontSize(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyFontSize(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyFontSize(state, value);
        return true;

    case CSSPropertyOrder:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyOrder(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyOrder(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyOrder(state, value);
        return true;

    case CSSPropertyWebkitBoxAlign:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitBoxAlign(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitBoxAlign(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitBoxAlign(state, value);
        return true;

    case CSSPropertyBackgroundSize:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyBackgroundSize(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyBackgroundSize(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyBackgroundSize(state, value);
        return true;

    case CSSPropertyClear:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyClear(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyClear(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyClear(state, value);
        return true;

    case CSSPropertyWebkitColumnBreakInside:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitColumnBreakInside(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitColumnBreakInside(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitColumnBreakInside(state, value);
        return true;

    case CSSPropertyPaddingRight:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyPaddingRight(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyPaddingRight(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyPaddingRight(state, value);
        return true;

    case CSSPropertyAlignContent:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyAlignContent(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyAlignContent(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyAlignContent(state, value);
        return true;

    case CSSPropertyWebkitShapePadding:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitShapePadding(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitShapePadding(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitShapePadding(state, value);
        return true;

    case CSSPropertyColorInterpolation:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyColorInterpolation(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyColorInterpolation(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyColorInterpolation(state, value);
        return true;

    case CSSPropertyDirection:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyDirection(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyDirection(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyDirection(state, value);
        return true;

    case CSSPropertyClip:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyClip(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyClip(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyClip(state, value);
        return true;

    case CSSPropertyWebkitBackfaceVisibility:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitBackfaceVisibility(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitBackfaceVisibility(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitBackfaceVisibility(state, value);
        return true;

    case CSSPropertyColor:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyColor(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyColor(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyColor(state, value);
        return true;

    case CSSPropertyWebkitRegionBreakAfter:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitRegionBreakAfter(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitRegionBreakAfter(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitRegionBreakAfter(state, value);
        return true;

    case CSSPropertyWebkitBorderImage:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitBorderImage(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitBorderImage(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitBorderImage(state, value);
        return true;

    case CSSPropertyPaddingBottom:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyPaddingBottom(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyPaddingBottom(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyPaddingBottom(state, value);
        return true;

    case CSSPropertyMarginLeft:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyMarginLeft(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyMarginLeft(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyMarginLeft(state, value);
        return true;

    case CSSPropertyWebkitRegionBreakInside:
        if (isInitial)
            StyleBuilderFunctions::applyInitialCSSPropertyWebkitRegionBreakInside(state);
        else if (isInherit)
            StyleBuilderFunctions::applyInheritCSSPropertyWebkitRegionBreakInside(state);
        else
            StyleBuilderFunctions::applyValueCSSPropertyWebkitRegionBreakInside(state, value);
        return true;

    default:
        return false;
    }
}

} // namespace WebCore

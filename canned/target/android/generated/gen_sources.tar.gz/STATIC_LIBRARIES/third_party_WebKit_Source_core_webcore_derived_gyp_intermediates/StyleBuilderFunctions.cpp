#include "config.h"
#include "StyleBuilderFunctions.h"

#include "CSSValueKeywords.h"
#include "core/css/BasicShapeFunctions.h"
#include "core/css/CSSPrimitiveValueMappings.h"
#include "core/css/Pair.h"
#include "core/css/resolver/StyleResolverState.h"
#include "core/platform/animation/CSSAnimationDataList.h"

// FIXME: This is duplicated in StyleBuilder.cpp.tmpl, but we'll move the
// function definitions there over to here later.

namespace WebCore {


void StyleBuilderFunctions::applyInitialCSSPropertyWebkitAnimationDelay(StyleResolverState& state)
{
    CSSAnimationDataList* list = state.style()->accessAnimations();
    if (list->isEmpty())
        list->append(CSSAnimationData::create());
    list->animation(0)->setDelay(CSSAnimationData::initialAnimationDelay());
    for (size_t i = 1; i < list->size(); ++i)
        list->animation(i)->clearDelay();
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitAnimationDelay(StyleResolverState& state)
{
    CSSAnimationDataList* list = state.style()->accessAnimations();
    const CSSAnimationDataList* parentList = state.parentStyle()->animations();
    size_t i = 0, parentSize = parentList ? parentList->size() : 0;
    for ( ; i < parentSize && parentList->animation(i)->isDelaySet(); ++i) {
        if (list->size() <= i)
            list->append(CSSAnimationData::create());
        list->animation(i)->setDelay(parentList->animation(i)->delay());
        list->animation(i)->setAnimationMode(parentList->animation(i)->animationMode());
    }

    // Reset any remaining animations to not have the property set.
    for ( ; i < list->size(); ++i)
        list->animation(i)->clearDelay();
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitAnimationDelay(StyleResolverState& state, CSSValue* value)
{
    CSSAnimationDataList* list = state.style()->accessAnimations();
    size_t childIndex = 0;
    if (value->isValueList()) {
        // Walk each value and put it into an animation, creating new animations as needed.
        for (CSSValueListIterator i = value; i.hasMore(); i.advance()) {
            if (childIndex <= list->size())
                list->append(CSSAnimationData::create());
            state.styleMap().mapAnimationDelay(list->animation(childIndex), i.value());
            ++childIndex;
        }
    } else {
        if (list->isEmpty())
            list->append(CSSAnimationData::create());
        state.styleMap().mapAnimationDelay(list->animation(childIndex), value);
        childIndex = 1;
    }
    for ( ; childIndex < list->size(); ++childIndex) {
        // Reset all remaining animations to not have the property set.
        list->animation(childIndex)->clearDelay();
    }
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitAnimationDirection(StyleResolverState& state)
{
    CSSAnimationDataList* list = state.style()->accessAnimations();
    if (list->isEmpty())
        list->append(CSSAnimationData::create());
    list->animation(0)->setDirection(CSSAnimationData::initialAnimationDirection());
    for (size_t i = 1; i < list->size(); ++i)
        list->animation(i)->clearDirection();
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitAnimationDirection(StyleResolverState& state)
{
    CSSAnimationDataList* list = state.style()->accessAnimations();
    const CSSAnimationDataList* parentList = state.parentStyle()->animations();
    size_t i = 0, parentSize = parentList ? parentList->size() : 0;
    for ( ; i < parentSize && parentList->animation(i)->isDirectionSet(); ++i) {
        if (list->size() <= i)
            list->append(CSSAnimationData::create());
        list->animation(i)->setDirection(parentList->animation(i)->direction());
        list->animation(i)->setAnimationMode(parentList->animation(i)->animationMode());
    }

    // Reset any remaining animations to not have the property set.
    for ( ; i < list->size(); ++i)
        list->animation(i)->clearDirection();
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitAnimationDirection(StyleResolverState& state, CSSValue* value)
{
    CSSAnimationDataList* list = state.style()->accessAnimations();
    size_t childIndex = 0;
    if (value->isValueList()) {
        // Walk each value and put it into an animation, creating new animations as needed.
        for (CSSValueListIterator i = value; i.hasMore(); i.advance()) {
            if (childIndex <= list->size())
                list->append(CSSAnimationData::create());
            state.styleMap().mapAnimationDirection(list->animation(childIndex), i.value());
            ++childIndex;
        }
    } else {
        if (list->isEmpty())
            list->append(CSSAnimationData::create());
        state.styleMap().mapAnimationDirection(list->animation(childIndex), value);
        childIndex = 1;
    }
    for ( ; childIndex < list->size(); ++childIndex) {
        // Reset all remaining animations to not have the property set.
        list->animation(childIndex)->clearDirection();
    }
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitAnimationDuration(StyleResolverState& state)
{
    CSSAnimationDataList* list = state.style()->accessAnimations();
    if (list->isEmpty())
        list->append(CSSAnimationData::create());
    list->animation(0)->setDuration(CSSAnimationData::initialAnimationDuration());
    for (size_t i = 1; i < list->size(); ++i)
        list->animation(i)->clearDuration();
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitAnimationDuration(StyleResolverState& state)
{
    CSSAnimationDataList* list = state.style()->accessAnimations();
    const CSSAnimationDataList* parentList = state.parentStyle()->animations();
    size_t i = 0, parentSize = parentList ? parentList->size() : 0;
    for ( ; i < parentSize && parentList->animation(i)->isDurationSet(); ++i) {
        if (list->size() <= i)
            list->append(CSSAnimationData::create());
        list->animation(i)->setDuration(parentList->animation(i)->duration());
        list->animation(i)->setAnimationMode(parentList->animation(i)->animationMode());
    }

    // Reset any remaining animations to not have the property set.
    for ( ; i < list->size(); ++i)
        list->animation(i)->clearDuration();
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitAnimationDuration(StyleResolverState& state, CSSValue* value)
{
    CSSAnimationDataList* list = state.style()->accessAnimations();
    size_t childIndex = 0;
    if (value->isValueList()) {
        // Walk each value and put it into an animation, creating new animations as needed.
        for (CSSValueListIterator i = value; i.hasMore(); i.advance()) {
            if (childIndex <= list->size())
                list->append(CSSAnimationData::create());
            state.styleMap().mapAnimationDuration(list->animation(childIndex), i.value());
            ++childIndex;
        }
    } else {
        if (list->isEmpty())
            list->append(CSSAnimationData::create());
        state.styleMap().mapAnimationDuration(list->animation(childIndex), value);
        childIndex = 1;
    }
    for ( ; childIndex < list->size(); ++childIndex) {
        // Reset all remaining animations to not have the property set.
        list->animation(childIndex)->clearDuration();
    }
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitAnimationFillMode(StyleResolverState& state)
{
    CSSAnimationDataList* list = state.style()->accessAnimations();
    if (list->isEmpty())
        list->append(CSSAnimationData::create());
    list->animation(0)->setFillMode(CSSAnimationData::initialAnimationFillMode());
    for (size_t i = 1; i < list->size(); ++i)
        list->animation(i)->clearFillMode();
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitAnimationFillMode(StyleResolverState& state)
{
    CSSAnimationDataList* list = state.style()->accessAnimations();
    const CSSAnimationDataList* parentList = state.parentStyle()->animations();
    size_t i = 0, parentSize = parentList ? parentList->size() : 0;
    for ( ; i < parentSize && parentList->animation(i)->isFillModeSet(); ++i) {
        if (list->size() <= i)
            list->append(CSSAnimationData::create());
        list->animation(i)->setFillMode(parentList->animation(i)->fillMode());
        list->animation(i)->setAnimationMode(parentList->animation(i)->animationMode());
    }

    // Reset any remaining animations to not have the property set.
    for ( ; i < list->size(); ++i)
        list->animation(i)->clearFillMode();
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitAnimationFillMode(StyleResolverState& state, CSSValue* value)
{
    CSSAnimationDataList* list = state.style()->accessAnimations();
    size_t childIndex = 0;
    if (value->isValueList()) {
        // Walk each value and put it into an animation, creating new animations as needed.
        for (CSSValueListIterator i = value; i.hasMore(); i.advance()) {
            if (childIndex <= list->size())
                list->append(CSSAnimationData::create());
            state.styleMap().mapAnimationFillMode(list->animation(childIndex), i.value());
            ++childIndex;
        }
    } else {
        if (list->isEmpty())
            list->append(CSSAnimationData::create());
        state.styleMap().mapAnimationFillMode(list->animation(childIndex), value);
        childIndex = 1;
    }
    for ( ; childIndex < list->size(); ++childIndex) {
        // Reset all remaining animations to not have the property set.
        list->animation(childIndex)->clearFillMode();
    }
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitAnimationIterationCount(StyleResolverState& state)
{
    CSSAnimationDataList* list = state.style()->accessAnimations();
    if (list->isEmpty())
        list->append(CSSAnimationData::create());
    list->animation(0)->setIterationCount(CSSAnimationData::initialAnimationIterationCount());
    for (size_t i = 1; i < list->size(); ++i)
        list->animation(i)->clearIterationCount();
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitAnimationIterationCount(StyleResolverState& state)
{
    CSSAnimationDataList* list = state.style()->accessAnimations();
    const CSSAnimationDataList* parentList = state.parentStyle()->animations();
    size_t i = 0, parentSize = parentList ? parentList->size() : 0;
    for ( ; i < parentSize && parentList->animation(i)->isIterationCountSet(); ++i) {
        if (list->size() <= i)
            list->append(CSSAnimationData::create());
        list->animation(i)->setIterationCount(parentList->animation(i)->iterationCount());
        list->animation(i)->setAnimationMode(parentList->animation(i)->animationMode());
    }

    // Reset any remaining animations to not have the property set.
    for ( ; i < list->size(); ++i)
        list->animation(i)->clearIterationCount();
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitAnimationIterationCount(StyleResolverState& state, CSSValue* value)
{
    CSSAnimationDataList* list = state.style()->accessAnimations();
    size_t childIndex = 0;
    if (value->isValueList()) {
        // Walk each value and put it into an animation, creating new animations as needed.
        for (CSSValueListIterator i = value; i.hasMore(); i.advance()) {
            if (childIndex <= list->size())
                list->append(CSSAnimationData::create());
            state.styleMap().mapAnimationIterationCount(list->animation(childIndex), i.value());
            ++childIndex;
        }
    } else {
        if (list->isEmpty())
            list->append(CSSAnimationData::create());
        state.styleMap().mapAnimationIterationCount(list->animation(childIndex), value);
        childIndex = 1;
    }
    for ( ; childIndex < list->size(); ++childIndex) {
        // Reset all remaining animations to not have the property set.
        list->animation(childIndex)->clearIterationCount();
    }
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitAnimationName(StyleResolverState& state)
{
    CSSAnimationDataList* list = state.style()->accessAnimations();
    if (list->isEmpty())
        list->append(CSSAnimationData::create());
    list->animation(0)->setName(CSSAnimationData::initialAnimationName());
    for (size_t i = 1; i < list->size(); ++i)
        list->animation(i)->clearName();
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitAnimationName(StyleResolverState& state)
{
    CSSAnimationDataList* list = state.style()->accessAnimations();
    const CSSAnimationDataList* parentList = state.parentStyle()->animations();
    size_t i = 0, parentSize = parentList ? parentList->size() : 0;
    for ( ; i < parentSize && parentList->animation(i)->isNameSet(); ++i) {
        if (list->size() <= i)
            list->append(CSSAnimationData::create());
        list->animation(i)->setName(parentList->animation(i)->name());
        list->animation(i)->setAnimationMode(parentList->animation(i)->animationMode());
    }

    // Reset any remaining animations to not have the property set.
    for ( ; i < list->size(); ++i)
        list->animation(i)->clearName();
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitAnimationName(StyleResolverState& state, CSSValue* value)
{
    CSSAnimationDataList* list = state.style()->accessAnimations();
    size_t childIndex = 0;
    if (value->isValueList()) {
        // Walk each value and put it into an animation, creating new animations as needed.
        for (CSSValueListIterator i = value; i.hasMore(); i.advance()) {
            if (childIndex <= list->size())
                list->append(CSSAnimationData::create());
            state.styleMap().mapAnimationName(list->animation(childIndex), i.value());
            ++childIndex;
        }
    } else {
        if (list->isEmpty())
            list->append(CSSAnimationData::create());
        state.styleMap().mapAnimationName(list->animation(childIndex), value);
        childIndex = 1;
    }
    for ( ; childIndex < list->size(); ++childIndex) {
        // Reset all remaining animations to not have the property set.
        list->animation(childIndex)->clearName();
    }
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitAnimationPlayState(StyleResolverState& state)
{
    CSSAnimationDataList* list = state.style()->accessAnimations();
    if (list->isEmpty())
        list->append(CSSAnimationData::create());
    list->animation(0)->setPlayState(CSSAnimationData::initialAnimationPlayState());
    for (size_t i = 1; i < list->size(); ++i)
        list->animation(i)->clearPlayState();
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitAnimationPlayState(StyleResolverState& state)
{
    CSSAnimationDataList* list = state.style()->accessAnimations();
    const CSSAnimationDataList* parentList = state.parentStyle()->animations();
    size_t i = 0, parentSize = parentList ? parentList->size() : 0;
    for ( ; i < parentSize && parentList->animation(i)->isPlayStateSet(); ++i) {
        if (list->size() <= i)
            list->append(CSSAnimationData::create());
        list->animation(i)->setPlayState(parentList->animation(i)->playState());
        list->animation(i)->setAnimationMode(parentList->animation(i)->animationMode());
    }

    // Reset any remaining animations to not have the property set.
    for ( ; i < list->size(); ++i)
        list->animation(i)->clearPlayState();
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitAnimationPlayState(StyleResolverState& state, CSSValue* value)
{
    CSSAnimationDataList* list = state.style()->accessAnimations();
    size_t childIndex = 0;
    if (value->isValueList()) {
        // Walk each value and put it into an animation, creating new animations as needed.
        for (CSSValueListIterator i = value; i.hasMore(); i.advance()) {
            if (childIndex <= list->size())
                list->append(CSSAnimationData::create());
            state.styleMap().mapAnimationPlayState(list->animation(childIndex), i.value());
            ++childIndex;
        }
    } else {
        if (list->isEmpty())
            list->append(CSSAnimationData::create());
        state.styleMap().mapAnimationPlayState(list->animation(childIndex), value);
        childIndex = 1;
    }
    for ( ; childIndex < list->size(); ++childIndex) {
        // Reset all remaining animations to not have the property set.
        list->animation(childIndex)->clearPlayState();
    }
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitAnimationTimingFunction(StyleResolverState& state)
{
    CSSAnimationDataList* list = state.style()->accessAnimations();
    if (list->isEmpty())
        list->append(CSSAnimationData::create());
    list->animation(0)->setTimingFunction(CSSAnimationData::initialAnimationTimingFunction());
    for (size_t i = 1; i < list->size(); ++i)
        list->animation(i)->clearTimingFunction();
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitAnimationTimingFunction(StyleResolverState& state)
{
    CSSAnimationDataList* list = state.style()->accessAnimations();
    const CSSAnimationDataList* parentList = state.parentStyle()->animations();
    size_t i = 0, parentSize = parentList ? parentList->size() : 0;
    for ( ; i < parentSize && parentList->animation(i)->isTimingFunctionSet(); ++i) {
        if (list->size() <= i)
            list->append(CSSAnimationData::create());
        list->animation(i)->setTimingFunction(parentList->animation(i)->timingFunction());
        list->animation(i)->setAnimationMode(parentList->animation(i)->animationMode());
    }

    // Reset any remaining animations to not have the property set.
    for ( ; i < list->size(); ++i)
        list->animation(i)->clearTimingFunction();
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitAnimationTimingFunction(StyleResolverState& state, CSSValue* value)
{
    CSSAnimationDataList* list = state.style()->accessAnimations();
    size_t childIndex = 0;
    if (value->isValueList()) {
        // Walk each value and put it into an animation, creating new animations as needed.
        for (CSSValueListIterator i = value; i.hasMore(); i.advance()) {
            if (childIndex <= list->size())
                list->append(CSSAnimationData::create());
            state.styleMap().mapAnimationTimingFunction(list->animation(childIndex), i.value());
            ++childIndex;
        }
    } else {
        if (list->isEmpty())
            list->append(CSSAnimationData::create());
        state.styleMap().mapAnimationTimingFunction(list->animation(childIndex), value);
        childIndex = 1;
    }
    for ( ; childIndex < list->size(); ++childIndex) {
        // Reset all remaining animations to not have the property set.
        list->animation(childIndex)->clearTimingFunction();
    }
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitTransitionDelay(StyleResolverState& state)
{
    CSSAnimationDataList* list = state.style()->accessTransitions();
    if (list->isEmpty())
        list->append(CSSAnimationData::create());
    list->animation(0)->setDelay(CSSAnimationData::initialAnimationDelay());
    for (size_t i = 1; i < list->size(); ++i)
        list->animation(i)->clearDelay();
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitTransitionDelay(StyleResolverState& state)
{
    CSSAnimationDataList* list = state.style()->accessTransitions();
    const CSSAnimationDataList* parentList = state.parentStyle()->transitions();
    size_t i = 0, parentSize = parentList ? parentList->size() : 0;
    for ( ; i < parentSize && parentList->animation(i)->isDelaySet(); ++i) {
        if (list->size() <= i)
            list->append(CSSAnimationData::create());
        list->animation(i)->setDelay(parentList->animation(i)->delay());
        list->animation(i)->setAnimationMode(parentList->animation(i)->animationMode());
    }

    // Reset any remaining animations to not have the property set.
    for ( ; i < list->size(); ++i)
        list->animation(i)->clearDelay();
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitTransitionDelay(StyleResolverState& state, CSSValue* value)
{
    CSSAnimationDataList* list = state.style()->accessTransitions();
    size_t childIndex = 0;
    if (value->isValueList()) {
        // Walk each value and put it into an animation, creating new animations as needed.
        for (CSSValueListIterator i = value; i.hasMore(); i.advance()) {
            if (childIndex <= list->size())
                list->append(CSSAnimationData::create());
            state.styleMap().mapAnimationDelay(list->animation(childIndex), i.value());
            ++childIndex;
        }
    } else {
        if (list->isEmpty())
            list->append(CSSAnimationData::create());
        state.styleMap().mapAnimationDelay(list->animation(childIndex), value);
        childIndex = 1;
    }
    for ( ; childIndex < list->size(); ++childIndex) {
        // Reset all remaining animations to not have the property set.
        list->animation(childIndex)->clearDelay();
    }
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitTransitionDuration(StyleResolverState& state)
{
    CSSAnimationDataList* list = state.style()->accessTransitions();
    if (list->isEmpty())
        list->append(CSSAnimationData::create());
    list->animation(0)->setDuration(CSSAnimationData::initialAnimationDuration());
    for (size_t i = 1; i < list->size(); ++i)
        list->animation(i)->clearDuration();
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitTransitionDuration(StyleResolverState& state)
{
    CSSAnimationDataList* list = state.style()->accessTransitions();
    const CSSAnimationDataList* parentList = state.parentStyle()->transitions();
    size_t i = 0, parentSize = parentList ? parentList->size() : 0;
    for ( ; i < parentSize && parentList->animation(i)->isDurationSet(); ++i) {
        if (list->size() <= i)
            list->append(CSSAnimationData::create());
        list->animation(i)->setDuration(parentList->animation(i)->duration());
        list->animation(i)->setAnimationMode(parentList->animation(i)->animationMode());
    }

    // Reset any remaining animations to not have the property set.
    for ( ; i < list->size(); ++i)
        list->animation(i)->clearDuration();
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitTransitionDuration(StyleResolverState& state, CSSValue* value)
{
    CSSAnimationDataList* list = state.style()->accessTransitions();
    size_t childIndex = 0;
    if (value->isValueList()) {
        // Walk each value and put it into an animation, creating new animations as needed.
        for (CSSValueListIterator i = value; i.hasMore(); i.advance()) {
            if (childIndex <= list->size())
                list->append(CSSAnimationData::create());
            state.styleMap().mapAnimationDuration(list->animation(childIndex), i.value());
            ++childIndex;
        }
    } else {
        if (list->isEmpty())
            list->append(CSSAnimationData::create());
        state.styleMap().mapAnimationDuration(list->animation(childIndex), value);
        childIndex = 1;
    }
    for ( ; childIndex < list->size(); ++childIndex) {
        // Reset all remaining animations to not have the property set.
        list->animation(childIndex)->clearDuration();
    }
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitTransitionProperty(StyleResolverState& state)
{
    CSSAnimationDataList* list = state.style()->accessTransitions();
    if (list->isEmpty())
        list->append(CSSAnimationData::create());
    list->animation(0)->setProperty(CSSAnimationData::initialAnimationProperty());
        list->animation(0)->setAnimationMode(CSSAnimationData::AnimateAll);
    for (size_t i = 1; i < list->size(); ++i)
        list->animation(i)->clearProperty();
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitTransitionProperty(StyleResolverState& state)
{
    CSSAnimationDataList* list = state.style()->accessTransitions();
    const CSSAnimationDataList* parentList = state.parentStyle()->transitions();
    size_t i = 0, parentSize = parentList ? parentList->size() : 0;
    for ( ; i < parentSize && parentList->animation(i)->isPropertySet(); ++i) {
        if (list->size() <= i)
            list->append(CSSAnimationData::create());
        list->animation(i)->setProperty(parentList->animation(i)->property());
        list->animation(i)->setAnimationMode(parentList->animation(i)->animationMode());
    }

    // Reset any remaining animations to not have the property set.
    for ( ; i < list->size(); ++i)
        list->animation(i)->clearProperty();
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitTransitionProperty(StyleResolverState& state, CSSValue* value)
{
    CSSAnimationDataList* list = state.style()->accessTransitions();
    size_t childIndex = 0;
    if (value->isValueList()) {
        // Walk each value and put it into an animation, creating new animations as needed.
        for (CSSValueListIterator i = value; i.hasMore(); i.advance()) {
            if (childIndex <= list->size())
                list->append(CSSAnimationData::create());
            state.styleMap().mapAnimationProperty(list->animation(childIndex), i.value());
            ++childIndex;
        }
    } else {
        if (list->isEmpty())
            list->append(CSSAnimationData::create());
        state.styleMap().mapAnimationProperty(list->animation(childIndex), value);
        childIndex = 1;
    }
    for ( ; childIndex < list->size(); ++childIndex) {
        // Reset all remaining animations to not have the property set.
        list->animation(childIndex)->clearProperty();
    }
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitTransitionTimingFunction(StyleResolverState& state)
{
    CSSAnimationDataList* list = state.style()->accessTransitions();
    if (list->isEmpty())
        list->append(CSSAnimationData::create());
    list->animation(0)->setTimingFunction(CSSAnimationData::initialAnimationTimingFunction());
    for (size_t i = 1; i < list->size(); ++i)
        list->animation(i)->clearTimingFunction();
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitTransitionTimingFunction(StyleResolverState& state)
{
    CSSAnimationDataList* list = state.style()->accessTransitions();
    const CSSAnimationDataList* parentList = state.parentStyle()->transitions();
    size_t i = 0, parentSize = parentList ? parentList->size() : 0;
    for ( ; i < parentSize && parentList->animation(i)->isTimingFunctionSet(); ++i) {
        if (list->size() <= i)
            list->append(CSSAnimationData::create());
        list->animation(i)->setTimingFunction(parentList->animation(i)->timingFunction());
        list->animation(i)->setAnimationMode(parentList->animation(i)->animationMode());
    }

    // Reset any remaining animations to not have the property set.
    for ( ; i < list->size(); ++i)
        list->animation(i)->clearTimingFunction();
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitTransitionTimingFunction(StyleResolverState& state, CSSValue* value)
{
    CSSAnimationDataList* list = state.style()->accessTransitions();
    size_t childIndex = 0;
    if (value->isValueList()) {
        // Walk each value and put it into an animation, creating new animations as needed.
        for (CSSValueListIterator i = value; i.hasMore(); i.advance()) {
            if (childIndex <= list->size())
                list->append(CSSAnimationData::create());
            state.styleMap().mapAnimationTimingFunction(list->animation(childIndex), i.value());
            ++childIndex;
        }
    } else {
        if (list->isEmpty())
            list->append(CSSAnimationData::create());
        state.styleMap().mapAnimationTimingFunction(list->animation(childIndex), value);
        childIndex = 1;
    }
    for ( ; childIndex < list->size(); ++childIndex) {
        // Reset all remaining animations to not have the property set.
        list->animation(childIndex)->clearTimingFunction();
    }
}


void StyleBuilderFunctions::applyInitialCSSPropertyOrphans(StyleResolverState& state)
{
    state.style()->setHasAutoOrphans();
}

void StyleBuilderFunctions::applyInheritCSSPropertyOrphans(StyleResolverState& state)
{
    if (state.parentStyle()->hasAutoOrphans())
        state.style()->setHasAutoOrphans();
    else
        state.style()->setOrphans(state.parentStyle()->orphans());
}

void StyleBuilderFunctions::applyValueCSSPropertyOrphans(StyleResolverState& state, CSSValue* value)
{
    if (!value->isPrimitiveValue())
        return;

    CSSPrimitiveValue* primitiveValue = toCSSPrimitiveValue(value);
    if (primitiveValue->getValueID() == CSSValueAuto)
        state.style()->setHasAutoOrphans();
    else
        state.style()->setOrphans(*primitiveValue);
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitColumnCount(StyleResolverState& state)
{
    state.style()->setHasAutoColumnCount();
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitColumnCount(StyleResolverState& state)
{
    if (state.parentStyle()->hasAutoColumnCount())
        state.style()->setHasAutoColumnCount();
    else
        state.style()->setColumnCount(state.parentStyle()->columnCount());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitColumnCount(StyleResolverState& state, CSSValue* value)
{
    if (!value->isPrimitiveValue())
        return;

    CSSPrimitiveValue* primitiveValue = toCSSPrimitiveValue(value);
    if (primitiveValue->getValueID() == CSSValueAuto)
        state.style()->setHasAutoColumnCount();
    else
        state.style()->setColumnCount(*primitiveValue);
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitColumnGap(StyleResolverState& state)
{
    state.style()->setHasNormalColumnGap();
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitColumnGap(StyleResolverState& state)
{
    if (state.parentStyle()->hasNormalColumnGap())
        state.style()->setHasNormalColumnGap();
    else
        state.style()->setColumnGap(state.parentStyle()->columnGap());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitColumnGap(StyleResolverState& state, CSSValue* value)
{
    if (!value->isPrimitiveValue())
        return;

    CSSPrimitiveValue* primitiveValue = toCSSPrimitiveValue(value);
    if (primitiveValue->getValueID() == CSSValueNormal)
        state.style()->setHasNormalColumnGap();
    else
        state.style()->setColumnGap(primitiveValue->computeLength<float>(state.style(), state.rootElementStyle(), state.style()->effectiveZoom()));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitColumnWidth(StyleResolverState& state)
{
    state.style()->setHasAutoColumnWidth();
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitColumnWidth(StyleResolverState& state)
{
    if (state.parentStyle()->hasAutoColumnWidth())
        state.style()->setHasAutoColumnWidth();
    else
        state.style()->setColumnWidth(state.parentStyle()->columnWidth());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitColumnWidth(StyleResolverState& state, CSSValue* value)
{
    if (!value->isPrimitiveValue())
        return;

    CSSPrimitiveValue* primitiveValue = toCSSPrimitiveValue(value);
    if (primitiveValue->getValueID() == CSSValueAuto)
        state.style()->setHasAutoColumnWidth();
    else
        state.style()->setColumnWidth(primitiveValue->computeLength<float>(state.style(), state.rootElementStyle(), state.style()->effectiveZoom()));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWidows(StyleResolverState& state)
{
    state.style()->setHasAutoWidows();
}

void StyleBuilderFunctions::applyInheritCSSPropertyWidows(StyleResolverState& state)
{
    if (state.parentStyle()->hasAutoWidows())
        state.style()->setHasAutoWidows();
    else
        state.style()->setWidows(state.parentStyle()->widows());
}

void StyleBuilderFunctions::applyValueCSSPropertyWidows(StyleResolverState& state, CSSValue* value)
{
    if (!value->isPrimitiveValue())
        return;

    CSSPrimitiveValue* primitiveValue = toCSSPrimitiveValue(value);
    if (primitiveValue->getValueID() == CSSValueAuto)
        state.style()->setHasAutoWidows();
    else
        state.style()->setWidows(*primitiveValue);
}

void StyleBuilderFunctions::applyInitialCSSPropertyZIndex(StyleResolverState& state)
{
    state.style()->setHasAutoZIndex();
}

void StyleBuilderFunctions::applyInheritCSSPropertyZIndex(StyleResolverState& state)
{
    if (state.parentStyle()->hasAutoZIndex())
        state.style()->setHasAutoZIndex();
    else
        state.style()->setZIndex(state.parentStyle()->zIndex());
}

void StyleBuilderFunctions::applyValueCSSPropertyZIndex(StyleResolverState& state, CSSValue* value)
{
    if (!value->isPrimitiveValue())
        return;

    CSSPrimitiveValue* primitiveValue = toCSSPrimitiveValue(value);
    if (primitiveValue->getValueID() == CSSValueAuto)
        state.style()->setHasAutoZIndex();
    else
        state.style()->setZIndex(*primitiveValue);
}


void StyleBuilderFunctions::applyValueCSSPropertyWebkitBorderImage(StyleResolverState& state, CSSValue* value)
{
    NinePieceImage image;
    state.styleMap().mapNinePieceImage(state.style(), CSSPropertyWebkitBorderImage, value, image);
    state.style()->setBorderImage(image);
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitMaskBoxImage(StyleResolverState& state, CSSValue* value)
{
    NinePieceImage image;
    image.setMaskDefaults();
    state.styleMap().mapNinePieceImage(state.style(), CSSPropertyWebkitMaskBoxImage, value, image);
    state.style()->setMaskBoxImage(image);
}


void StyleBuilderFunctions::applyInitialCSSPropertyBorderImageOutset(StyleResolverState& state)
{
    NinePieceImage image(state.style()->borderImage());
    image.setOutset(LengthBox(0));
    state.style()->setBorderImage(image);
}

void StyleBuilderFunctions::applyInheritCSSPropertyBorderImageOutset(StyleResolverState& state)
{
    NinePieceImage image(state.style()->borderImage());
    image.copyOutsetFrom(state.parentStyle()->borderImage());
    state.style()->setBorderImage(image);
}

void StyleBuilderFunctions::applyValueCSSPropertyBorderImageOutset(StyleResolverState& state, CSSValue* value)
{
    NinePieceImage image(state.style()->borderImage());
    image.setOutset(state.styleMap().mapNinePieceImageQuad(value));
    state.style()->setBorderImage(image);
}

void StyleBuilderFunctions::applyInitialCSSPropertyBorderImageRepeat(StyleResolverState& state)
{
    NinePieceImage image(state.style()->borderImage());
    image.setHorizontalRule(StretchImageRule);
    image.setVerticalRule(StretchImageRule);
    state.style()->setBorderImage(image);
}

void StyleBuilderFunctions::applyInheritCSSPropertyBorderImageRepeat(StyleResolverState& state)
{
    NinePieceImage image(state.style()->borderImage());
    image.copyRepeatFrom(state.parentStyle()->borderImage());
    state.style()->setBorderImage(image);
}

void StyleBuilderFunctions::applyValueCSSPropertyBorderImageRepeat(StyleResolverState& state, CSSValue* value)
{
    NinePieceImage image(state.style()->borderImage());
    state.styleMap().mapNinePieceImageRepeat(value, image);
    state.style()->setBorderImage(image);
}

void StyleBuilderFunctions::applyInitialCSSPropertyBorderImageSlice(StyleResolverState& state)
{
    NinePieceImage image(state.style()->borderImage());
    // Masks have a different initial value for slices. Preserve the value of 0 for backwards compatibility.
    image.setImageSlices(LengthBox(Length(100, Percent), Length(100, Percent), Length(100, Percent), Length(100, Percent)));
    image.setFill(false);
    state.style()->setBorderImage(image);
}

void StyleBuilderFunctions::applyInheritCSSPropertyBorderImageSlice(StyleResolverState& state)
{
    NinePieceImage image(state.style()->borderImage());
    image.copyImageSlicesFrom(state.parentStyle()->borderImage());
    state.style()->setBorderImage(image);
}

void StyleBuilderFunctions::applyValueCSSPropertyBorderImageSlice(StyleResolverState& state, CSSValue* value)
{
    NinePieceImage image(state.style()->borderImage());
    state.styleMap().mapNinePieceImageSlice(value, image);
    state.style()->setBorderImage(image);
}

void StyleBuilderFunctions::applyInitialCSSPropertyBorderImageWidth(StyleResolverState& state)
{
    NinePieceImage image(state.style()->borderImage());
    // Masks have a different initial value for widths. Preserve the value of 0 for backwards compatibility.
    image.setBorderSlices(LengthBox(Length(1, Relative), Length(1, Relative), Length(1, Relative), Length(1, Relative)));
    state.style()->setBorderImage(image);
}

void StyleBuilderFunctions::applyInheritCSSPropertyBorderImageWidth(StyleResolverState& state)
{
    NinePieceImage image(state.style()->borderImage());
    image.copyBorderSlicesFrom(state.parentStyle()->borderImage());
    state.style()->setBorderImage(image);
}

void StyleBuilderFunctions::applyValueCSSPropertyBorderImageWidth(StyleResolverState& state, CSSValue* value)
{
    NinePieceImage image(state.style()->borderImage());
    image.setBorderSlices(state.styleMap().mapNinePieceImageQuad(value));
    state.style()->setBorderImage(image);
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitMaskBoxImageOutset(StyleResolverState& state)
{
    NinePieceImage image(state.style()->maskBoxImage());
    image.setOutset(LengthBox(0));
    state.style()->setMaskBoxImage(image);
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitMaskBoxImageOutset(StyleResolverState& state)
{
    NinePieceImage image(state.style()->maskBoxImage());
    image.copyOutsetFrom(state.parentStyle()->maskBoxImage());
    state.style()->setMaskBoxImage(image);
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitMaskBoxImageOutset(StyleResolverState& state, CSSValue* value)
{
    NinePieceImage image(state.style()->maskBoxImage());
    image.setOutset(state.styleMap().mapNinePieceImageQuad(value));
    state.style()->setMaskBoxImage(image);
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitMaskBoxImageRepeat(StyleResolverState& state)
{
    NinePieceImage image(state.style()->maskBoxImage());
    image.setHorizontalRule(StretchImageRule);
    image.setVerticalRule(StretchImageRule);
    state.style()->setMaskBoxImage(image);
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitMaskBoxImageRepeat(StyleResolverState& state)
{
    NinePieceImage image(state.style()->maskBoxImage());
    image.copyRepeatFrom(state.parentStyle()->maskBoxImage());
    state.style()->setMaskBoxImage(image);
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitMaskBoxImageRepeat(StyleResolverState& state, CSSValue* value)
{
    NinePieceImage image(state.style()->maskBoxImage());
    state.styleMap().mapNinePieceImageRepeat(value, image);
    state.style()->setMaskBoxImage(image);
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitMaskBoxImageSlice(StyleResolverState& state)
{
    NinePieceImage image(state.style()->maskBoxImage());
    // Masks have a different initial value for slices. Preserve the value of 0 for backwards compatibility.
    image.setImageSlices(LengthBox());
    image.setFill(false);
    state.style()->setMaskBoxImage(image);
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitMaskBoxImageSlice(StyleResolverState& state)
{
    NinePieceImage image(state.style()->maskBoxImage());
    image.copyImageSlicesFrom(state.parentStyle()->maskBoxImage());
    state.style()->setMaskBoxImage(image);
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitMaskBoxImageSlice(StyleResolverState& state, CSSValue* value)
{
    NinePieceImage image(state.style()->maskBoxImage());
    state.styleMap().mapNinePieceImageSlice(value, image);
    state.style()->setMaskBoxImage(image);
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitMaskBoxImageWidth(StyleResolverState& state)
{
    NinePieceImage image(state.style()->maskBoxImage());
    // Masks have a different initial value for widths. Preserve the value of 0 for backwards compatibility.
    image.setBorderSlices(LengthBox());
    state.style()->setMaskBoxImage(image);
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitMaskBoxImageWidth(StyleResolverState& state)
{
    NinePieceImage image(state.style()->maskBoxImage());
    image.copyBorderSlicesFrom(state.parentStyle()->maskBoxImage());
    state.style()->setMaskBoxImage(image);
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitMaskBoxImageWidth(StyleResolverState& state, CSSValue* value)
{
    NinePieceImage image(state.style()->maskBoxImage());
    image.setBorderSlices(state.styleMap().mapNinePieceImageQuad(value));
    state.style()->setMaskBoxImage(image);
}


void StyleBuilderFunctions::applyValueCSSPropertyBorderImageSource(StyleResolverState& state, CSSValue* value)
{
    state.style()->setBorderImageSource(state.styleImage(CSSPropertyBorderImageSource, value));
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitMaskBoxImageSource(StyleResolverState& state, CSSValue* value)
{
    state.style()->setMaskBoxImageSource(state.styleImage(CSSPropertyWebkitMaskBoxImageSource, value));
}


void StyleBuilderFunctions::applyInitialCSSPropertyBackgroundColor(StyleResolverState& state)
{
    StyleColor color = StyleColor();
    if (state.applyPropertyToRegularStyle())
        state.style()->setBackgroundColor(color);
    if (state.applyPropertyToVisitedLinkStyle())
        state.style()->setVisitedLinkBackgroundColor(color);
}

void StyleBuilderFunctions::applyInheritCSSPropertyBackgroundColor(StyleResolverState& state)
{
    // Visited link style can never explicitly inherit from parent visited link style so no separate getters are needed.
    StyleColor color = state.parentStyle()->backgroundColor();
    if (!color.isValid())
        color = state.parentStyle()->invalidColor();
    if (state.applyPropertyToRegularStyle())
        state.style()->setBackgroundColor(color);
    if (state.applyPropertyToVisitedLinkStyle())
        state.style()->setVisitedLinkBackgroundColor(color);
}

void StyleBuilderFunctions::applyValueCSSPropertyBackgroundColor(StyleResolverState& state, CSSValue* value)
{
    if (!value->isPrimitiveValue())
        return;

    CSSPrimitiveValue* primitiveValue = toCSSPrimitiveValue(value);

    if (state.applyPropertyToRegularStyle())
        state.style()->setBackgroundColor(state.document()->textLinkColors().colorFromPrimitiveValue(primitiveValue));
    if (state.applyPropertyToVisitedLinkStyle())
        state.style()->setVisitedLinkBackgroundColor(state.document()->textLinkColors().colorFromPrimitiveValue(primitiveValue, state.element()->isLink() /* forVisitedLink */));
}

void StyleBuilderFunctions::applyInitialCSSPropertyBorderBottomColor(StyleResolverState& state)
{
    StyleColor color = StyleColor();
    if (state.applyPropertyToRegularStyle())
        state.style()->setBorderBottomColor(color);
    if (state.applyPropertyToVisitedLinkStyle())
        state.style()->setVisitedLinkBorderBottomColor(color);
}

void StyleBuilderFunctions::applyInheritCSSPropertyBorderBottomColor(StyleResolverState& state)
{
    // Visited link style can never explicitly inherit from parent visited link style so no separate getters are needed.
    StyleColor color = state.parentStyle()->borderBottomColor();
    if (!color.isValid())
        color = state.parentStyle()->color();
    if (state.applyPropertyToRegularStyle())
        state.style()->setBorderBottomColor(color);
    if (state.applyPropertyToVisitedLinkStyle())
        state.style()->setVisitedLinkBorderBottomColor(color);
}

void StyleBuilderFunctions::applyValueCSSPropertyBorderBottomColor(StyleResolverState& state, CSSValue* value)
{
    if (!value->isPrimitiveValue())
        return;

    CSSPrimitiveValue* primitiveValue = toCSSPrimitiveValue(value);

    if (state.applyPropertyToRegularStyle())
        state.style()->setBorderBottomColor(state.document()->textLinkColors().colorFromPrimitiveValue(primitiveValue));
    if (state.applyPropertyToVisitedLinkStyle())
        state.style()->setVisitedLinkBorderBottomColor(state.document()->textLinkColors().colorFromPrimitiveValue(primitiveValue, state.element()->isLink() /* forVisitedLink */));
}

void StyleBuilderFunctions::applyInitialCSSPropertyBorderLeftColor(StyleResolverState& state)
{
    StyleColor color = StyleColor();
    if (state.applyPropertyToRegularStyle())
        state.style()->setBorderLeftColor(color);
    if (state.applyPropertyToVisitedLinkStyle())
        state.style()->setVisitedLinkBorderLeftColor(color);
}

void StyleBuilderFunctions::applyInheritCSSPropertyBorderLeftColor(StyleResolverState& state)
{
    // Visited link style can never explicitly inherit from parent visited link style so no separate getters are needed.
    StyleColor color = state.parentStyle()->borderLeftColor();
    if (!color.isValid())
        color = state.parentStyle()->color();
    if (state.applyPropertyToRegularStyle())
        state.style()->setBorderLeftColor(color);
    if (state.applyPropertyToVisitedLinkStyle())
        state.style()->setVisitedLinkBorderLeftColor(color);
}

void StyleBuilderFunctions::applyValueCSSPropertyBorderLeftColor(StyleResolverState& state, CSSValue* value)
{
    if (!value->isPrimitiveValue())
        return;

    CSSPrimitiveValue* primitiveValue = toCSSPrimitiveValue(value);

    if (state.applyPropertyToRegularStyle())
        state.style()->setBorderLeftColor(state.document()->textLinkColors().colorFromPrimitiveValue(primitiveValue));
    if (state.applyPropertyToVisitedLinkStyle())
        state.style()->setVisitedLinkBorderLeftColor(state.document()->textLinkColors().colorFromPrimitiveValue(primitiveValue, state.element()->isLink() /* forVisitedLink */));
}

void StyleBuilderFunctions::applyInitialCSSPropertyBorderRightColor(StyleResolverState& state)
{
    StyleColor color = StyleColor();
    if (state.applyPropertyToRegularStyle())
        state.style()->setBorderRightColor(color);
    if (state.applyPropertyToVisitedLinkStyle())
        state.style()->setVisitedLinkBorderRightColor(color);
}

void StyleBuilderFunctions::applyInheritCSSPropertyBorderRightColor(StyleResolverState& state)
{
    // Visited link style can never explicitly inherit from parent visited link style so no separate getters are needed.
    StyleColor color = state.parentStyle()->borderRightColor();
    if (!color.isValid())
        color = state.parentStyle()->color();
    if (state.applyPropertyToRegularStyle())
        state.style()->setBorderRightColor(color);
    if (state.applyPropertyToVisitedLinkStyle())
        state.style()->setVisitedLinkBorderRightColor(color);
}

void StyleBuilderFunctions::applyValueCSSPropertyBorderRightColor(StyleResolverState& state, CSSValue* value)
{
    if (!value->isPrimitiveValue())
        return;

    CSSPrimitiveValue* primitiveValue = toCSSPrimitiveValue(value);

    if (state.applyPropertyToRegularStyle())
        state.style()->setBorderRightColor(state.document()->textLinkColors().colorFromPrimitiveValue(primitiveValue));
    if (state.applyPropertyToVisitedLinkStyle())
        state.style()->setVisitedLinkBorderRightColor(state.document()->textLinkColors().colorFromPrimitiveValue(primitiveValue, state.element()->isLink() /* forVisitedLink */));
}

void StyleBuilderFunctions::applyInitialCSSPropertyBorderTopColor(StyleResolverState& state)
{
    StyleColor color = StyleColor();
    if (state.applyPropertyToRegularStyle())
        state.style()->setBorderTopColor(color);
    if (state.applyPropertyToVisitedLinkStyle())
        state.style()->setVisitedLinkBorderTopColor(color);
}

void StyleBuilderFunctions::applyInheritCSSPropertyBorderTopColor(StyleResolverState& state)
{
    // Visited link style can never explicitly inherit from parent visited link style so no separate getters are needed.
    StyleColor color = state.parentStyle()->borderTopColor();
    if (!color.isValid())
        color = state.parentStyle()->color();
    if (state.applyPropertyToRegularStyle())
        state.style()->setBorderTopColor(color);
    if (state.applyPropertyToVisitedLinkStyle())
        state.style()->setVisitedLinkBorderTopColor(color);
}

void StyleBuilderFunctions::applyValueCSSPropertyBorderTopColor(StyleResolverState& state, CSSValue* value)
{
    if (!value->isPrimitiveValue())
        return;

    CSSPrimitiveValue* primitiveValue = toCSSPrimitiveValue(value);

    if (state.applyPropertyToRegularStyle())
        state.style()->setBorderTopColor(state.document()->textLinkColors().colorFromPrimitiveValue(primitiveValue));
    if (state.applyPropertyToVisitedLinkStyle())
        state.style()->setVisitedLinkBorderTopColor(state.document()->textLinkColors().colorFromPrimitiveValue(primitiveValue, state.element()->isLink() /* forVisitedLink */));
}

void StyleBuilderFunctions::applyInitialCSSPropertyColor(StyleResolverState& state)
{
    StyleColor color = RenderStyle::initialColor();
    if (state.applyPropertyToRegularStyle())
        state.style()->setColor(color);
    if (state.applyPropertyToVisitedLinkStyle())
        state.style()->setVisitedLinkColor(color);
}

void StyleBuilderFunctions::applyInheritCSSPropertyColor(StyleResolverState& state)
{
    // Visited link style can never explicitly inherit from parent visited link style so no separate getters are needed.
    StyleColor color = state.parentStyle()->color();
    if (!color.isValid())
        color = state.parentStyle()->invalidColor();
    if (state.applyPropertyToRegularStyle())
        state.style()->setColor(color);
    if (state.applyPropertyToVisitedLinkStyle())
        state.style()->setVisitedLinkColor(color);
}

void StyleBuilderFunctions::applyValueCSSPropertyColor(StyleResolverState& state, CSSValue* value)
{
    if (!value->isPrimitiveValue())
        return;

    CSSPrimitiveValue* primitiveValue = toCSSPrimitiveValue(value);
    if (primitiveValue->getValueID() == CSSValueCurrentcolor) {
        applyInheritCSSPropertyColor(state);
        return;
    }

    if (state.applyPropertyToRegularStyle())
        state.style()->setColor(state.document()->textLinkColors().colorFromPrimitiveValue(primitiveValue));
    if (state.applyPropertyToVisitedLinkStyle())
        state.style()->setVisitedLinkColor(state.document()->textLinkColors().colorFromPrimitiveValue(primitiveValue, state.element()->isLink() /* forVisitedLink */));
}

void StyleBuilderFunctions::applyInitialCSSPropertyOutlineColor(StyleResolverState& state)
{
    StyleColor color = StyleColor();
    if (state.applyPropertyToRegularStyle())
        state.style()->setOutlineColor(color);
    if (state.applyPropertyToVisitedLinkStyle())
        state.style()->setVisitedLinkOutlineColor(color);
}

void StyleBuilderFunctions::applyInheritCSSPropertyOutlineColor(StyleResolverState& state)
{
    // Visited link style can never explicitly inherit from parent visited link style so no separate getters are needed.
    StyleColor color = state.parentStyle()->outlineColor();
    if (!color.isValid())
        color = state.parentStyle()->color();
    if (state.applyPropertyToRegularStyle())
        state.style()->setOutlineColor(color);
    if (state.applyPropertyToVisitedLinkStyle())
        state.style()->setVisitedLinkOutlineColor(color);
}

void StyleBuilderFunctions::applyValueCSSPropertyOutlineColor(StyleResolverState& state, CSSValue* value)
{
    if (!value->isPrimitiveValue())
        return;

    CSSPrimitiveValue* primitiveValue = toCSSPrimitiveValue(value);

    if (state.applyPropertyToRegularStyle())
        state.style()->setOutlineColor(state.document()->textLinkColors().colorFromPrimitiveValue(primitiveValue));
    if (state.applyPropertyToVisitedLinkStyle())
        state.style()->setVisitedLinkOutlineColor(state.document()->textLinkColors().colorFromPrimitiveValue(primitiveValue, state.element()->isLink() /* forVisitedLink */));
}

void StyleBuilderFunctions::applyInitialCSSPropertyTextDecorationColor(StyleResolverState& state)
{
    StyleColor color = StyleColor();
    if (state.applyPropertyToRegularStyle())
        state.style()->setTextDecorationColor(color);
    if (state.applyPropertyToVisitedLinkStyle())
        state.style()->setVisitedLinkTextDecorationColor(color);
}

void StyleBuilderFunctions::applyInheritCSSPropertyTextDecorationColor(StyleResolverState& state)
{
    // Visited link style can never explicitly inherit from parent visited link style so no separate getters are needed.
    StyleColor color = state.parentStyle()->textDecorationColor();
    if (!color.isValid())
        color = state.parentStyle()->color();
    if (state.applyPropertyToRegularStyle())
        state.style()->setTextDecorationColor(color);
    if (state.applyPropertyToVisitedLinkStyle())
        state.style()->setVisitedLinkTextDecorationColor(color);
}

void StyleBuilderFunctions::applyValueCSSPropertyTextDecorationColor(StyleResolverState& state, CSSValue* value)
{
    if (!value->isPrimitiveValue())
        return;

    CSSPrimitiveValue* primitiveValue = toCSSPrimitiveValue(value);

    if (state.applyPropertyToRegularStyle())
        state.style()->setTextDecorationColor(state.document()->textLinkColors().colorFromPrimitiveValue(primitiveValue));
    if (state.applyPropertyToVisitedLinkStyle())
        state.style()->setVisitedLinkTextDecorationColor(state.document()->textLinkColors().colorFromPrimitiveValue(primitiveValue, state.element()->isLink() /* forVisitedLink */));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitColumnRuleColor(StyleResolverState& state)
{
    StyleColor color = StyleColor();
    if (state.applyPropertyToRegularStyle())
        state.style()->setColumnRuleColor(color);
    if (state.applyPropertyToVisitedLinkStyle())
        state.style()->setVisitedLinkColumnRuleColor(color);
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitColumnRuleColor(StyleResolverState& state)
{
    // Visited link style can never explicitly inherit from parent visited link style so no separate getters are needed.
    StyleColor color = state.parentStyle()->columnRuleColor();
    if (!color.isValid())
        color = state.parentStyle()->color();
    if (state.applyPropertyToRegularStyle())
        state.style()->setColumnRuleColor(color);
    if (state.applyPropertyToVisitedLinkStyle())
        state.style()->setVisitedLinkColumnRuleColor(color);
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitColumnRuleColor(StyleResolverState& state, CSSValue* value)
{
    if (!value->isPrimitiveValue())
        return;

    CSSPrimitiveValue* primitiveValue = toCSSPrimitiveValue(value);

    if (state.applyPropertyToRegularStyle())
        state.style()->setColumnRuleColor(state.document()->textLinkColors().colorFromPrimitiveValue(primitiveValue));
    if (state.applyPropertyToVisitedLinkStyle())
        state.style()->setVisitedLinkColumnRuleColor(state.document()->textLinkColors().colorFromPrimitiveValue(primitiveValue, state.element()->isLink() /* forVisitedLink */));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitTextEmphasisColor(StyleResolverState& state)
{
    StyleColor color = StyleColor();
    if (state.applyPropertyToRegularStyle())
        state.style()->setTextEmphasisColor(color);
    if (state.applyPropertyToVisitedLinkStyle())
        state.style()->setVisitedLinkTextEmphasisColor(color);
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitTextEmphasisColor(StyleResolverState& state)
{
    // Visited link style can never explicitly inherit from parent visited link style so no separate getters are needed.
    StyleColor color = state.parentStyle()->textEmphasisColor();
    if (!color.isValid())
        color = state.parentStyle()->color();
    if (state.applyPropertyToRegularStyle())
        state.style()->setTextEmphasisColor(color);
    if (state.applyPropertyToVisitedLinkStyle())
        state.style()->setVisitedLinkTextEmphasisColor(color);
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitTextEmphasisColor(StyleResolverState& state, CSSValue* value)
{
    if (!value->isPrimitiveValue())
        return;

    CSSPrimitiveValue* primitiveValue = toCSSPrimitiveValue(value);

    if (state.applyPropertyToRegularStyle())
        state.style()->setTextEmphasisColor(state.document()->textLinkColors().colorFromPrimitiveValue(primitiveValue));
    if (state.applyPropertyToVisitedLinkStyle())
        state.style()->setVisitedLinkTextEmphasisColor(state.document()->textLinkColors().colorFromPrimitiveValue(primitiveValue, state.element()->isLink() /* forVisitedLink */));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitTextFillColor(StyleResolverState& state)
{
    StyleColor color = StyleColor();
    if (state.applyPropertyToRegularStyle())
        state.style()->setTextFillColor(color);
    if (state.applyPropertyToVisitedLinkStyle())
        state.style()->setVisitedLinkTextFillColor(color);
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitTextFillColor(StyleResolverState& state)
{
    // Visited link style can never explicitly inherit from parent visited link style so no separate getters are needed.
    StyleColor color = state.parentStyle()->textFillColor();
    if (!color.isValid())
        color = state.parentStyle()->color();
    if (state.applyPropertyToRegularStyle())
        state.style()->setTextFillColor(color);
    if (state.applyPropertyToVisitedLinkStyle())
        state.style()->setVisitedLinkTextFillColor(color);
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitTextFillColor(StyleResolverState& state, CSSValue* value)
{
    if (!value->isPrimitiveValue())
        return;

    CSSPrimitiveValue* primitiveValue = toCSSPrimitiveValue(value);

    if (state.applyPropertyToRegularStyle())
        state.style()->setTextFillColor(state.document()->textLinkColors().colorFromPrimitiveValue(primitiveValue));
    if (state.applyPropertyToVisitedLinkStyle())
        state.style()->setVisitedLinkTextFillColor(state.document()->textLinkColors().colorFromPrimitiveValue(primitiveValue, state.element()->isLink() /* forVisitedLink */));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitTextStrokeColor(StyleResolverState& state)
{
    StyleColor color = StyleColor();
    if (state.applyPropertyToRegularStyle())
        state.style()->setTextStrokeColor(color);
    if (state.applyPropertyToVisitedLinkStyle())
        state.style()->setVisitedLinkTextStrokeColor(color);
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitTextStrokeColor(StyleResolverState& state)
{
    // Visited link style can never explicitly inherit from parent visited link style so no separate getters are needed.
    StyleColor color = state.parentStyle()->textStrokeColor();
    if (!color.isValid())
        color = state.parentStyle()->color();
    if (state.applyPropertyToRegularStyle())
        state.style()->setTextStrokeColor(color);
    if (state.applyPropertyToVisitedLinkStyle())
        state.style()->setVisitedLinkTextStrokeColor(color);
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitTextStrokeColor(StyleResolverState& state, CSSValue* value)
{
    if (!value->isPrimitiveValue())
        return;

    CSSPrimitiveValue* primitiveValue = toCSSPrimitiveValue(value);

    if (state.applyPropertyToRegularStyle())
        state.style()->setTextStrokeColor(state.document()->textLinkColors().colorFromPrimitiveValue(primitiveValue));
    if (state.applyPropertyToVisitedLinkStyle())
        state.style()->setVisitedLinkTextStrokeColor(state.document()->textLinkColors().colorFromPrimitiveValue(primitiveValue, state.element()->isLink() /* forVisitedLink */));
}


void StyleBuilderFunctions::applyInitialCSSPropertyCounterIncrement(StyleResolverState& state) { }

void StyleBuilderFunctions::applyInheritCSSPropertyCounterIncrement(StyleResolverState& state)
{
    CounterDirectiveMap& map = state.style()->accessCounterDirectives();
    CounterDirectiveMap& parentMap = state.parentStyle()->accessCounterDirectives();

    typedef CounterDirectiveMap::iterator Iterator;
    Iterator end = parentMap.end();
    for (Iterator it = parentMap.begin(); it != end; ++it) {
        CounterDirectives& directives = map.add(it->key, CounterDirectives()).iterator->value;
        directives.inheritIncrement(it->value);
    }
}

void StyleBuilderFunctions::applyValueCSSPropertyCounterIncrement(StyleResolverState& state, CSSValue* value)
{
    if (!value->isValueList())
        return;

    CSSValueList* list = toCSSValueList(value);

    CounterDirectiveMap& map = state.style()->accessCounterDirectives();
    typedef CounterDirectiveMap::iterator Iterator;

    Iterator end = map.end();
    for (Iterator it = map.begin(); it != end; ++it)
        it->value.clearIncrement();

    int length = list ? list->length() : 0;
    for (int i = 0; i < length; ++i) {
        CSSValue* currValue = list->itemWithoutBoundsCheck(i);
        if (!currValue->isPrimitiveValue())
            continue;

        Pair* pair = toCSSPrimitiveValue(currValue)->getPairValue();
        if (!pair || !pair->first() || !pair->second())
            continue;

        AtomicString identifier = pair->first()->getStringValue();
        int value = pair->second()->getIntValue();
        CounterDirectives& directives = map.add(identifier, CounterDirectives()).iterator->value;
        directives.addIncrementValue(value);
    }
}

void StyleBuilderFunctions::applyInitialCSSPropertyCounterReset(StyleResolverState& state) { }

void StyleBuilderFunctions::applyInheritCSSPropertyCounterReset(StyleResolverState& state)
{
    CounterDirectiveMap& map = state.style()->accessCounterDirectives();
    CounterDirectiveMap& parentMap = state.parentStyle()->accessCounterDirectives();

    typedef CounterDirectiveMap::iterator Iterator;
    Iterator end = parentMap.end();
    for (Iterator it = parentMap.begin(); it != end; ++it) {
        CounterDirectives& directives = map.add(it->key, CounterDirectives()).iterator->value;
        directives.inheritReset(it->value);
    }
}

void StyleBuilderFunctions::applyValueCSSPropertyCounterReset(StyleResolverState& state, CSSValue* value)
{
    if (!value->isValueList())
        return;

    CSSValueList* list = toCSSValueList(value);

    CounterDirectiveMap& map = state.style()->accessCounterDirectives();
    typedef CounterDirectiveMap::iterator Iterator;

    Iterator end = map.end();
    for (Iterator it = map.begin(); it != end; ++it)
        it->value.clearReset();

    int length = list ? list->length() : 0;
    for (int i = 0; i < length; ++i) {
        CSSValue* currValue = list->itemWithoutBoundsCheck(i);
        if (!currValue->isPrimitiveValue())
            continue;

        Pair* pair = toCSSPrimitiveValue(currValue)->getPairValue();
        if (!pair || !pair->first() || !pair->second())
            continue;

        AtomicString identifier = pair->first()->getStringValue();
        int value = pair->second()->getIntValue();
        CounterDirectives& directives = map.add(identifier, CounterDirectives()).iterator->value;
        directives.setResetValue(value);
    }
}


void StyleBuilderFunctions::applyInitialCSSPropertyBackgroundAttachment(StyleResolverState& state)
{
    FillLayer* currChild = state.style()->accessBackgroundLayers();
    currChild->setAttachment(FillLayer::initialFillAttachment(BackgroundFillLayer));
    for (currChild = currChild->next(); currChild; currChild = currChild->next())
        currChild->clearAttachment();
}

void StyleBuilderFunctions::applyInheritCSSPropertyBackgroundAttachment(StyleResolverState& state)
{
    FillLayer* currChild = state.style()->accessBackgroundLayers();
    FillLayer* prevChild = 0;
    const FillLayer* currParent = state.parentStyle()->backgroundLayers();
    while (currParent && currParent->isAttachmentSet()) {
        if (!currChild) {
            /* Need to make a new layer.*/
            currChild = new FillLayer(BackgroundFillLayer);
            prevChild->setNext(currChild);
        }
        currChild->setAttachment(currParent->attachment());
        prevChild = currChild;
        currChild = prevChild->next();
        currParent = currParent->next();
    }

    while (currChild) {
        /* Reset any remaining layers to not have the property set. */
        currChild->clearAttachment();
        currChild = currChild->next();
    }
}

void StyleBuilderFunctions::applyValueCSSPropertyBackgroundAttachment(StyleResolverState& state, CSSValue* value)
{
    FillLayer* currChild = state.style()->accessBackgroundLayers();
    FillLayer* prevChild = 0;
    if (value->isValueList() && !value->isImageSetValue()) {
        /* Walk each value and put it into a layer, creating new layers as needed. */
        CSSValueList* valueList = toCSSValueList(value);
        for (unsigned int i = 0; i < valueList->length(); i++) {
            if (!currChild) {
                /* Need to make a new layer to hold this value */
                currChild = new FillLayer(BackgroundFillLayer);
                prevChild->setNext(currChild);
            }
            state.styleMap().mapFillAttachment(CSSPropertyBackgroundAttachment, currChild, valueList->itemWithoutBoundsCheck(i));
            prevChild = currChild;
            currChild = currChild->next();
        }
    } else {
        state.styleMap().mapFillAttachment(CSSPropertyBackgroundAttachment, currChild, value);
        currChild = currChild->next();
    }
    while (currChild) {
        /* Reset all remaining layers to not have the property set. */
        currChild->clearAttachment();
        currChild = currChild->next();
    }
}

void StyleBuilderFunctions::applyInitialCSSPropertyBackgroundBlendMode(StyleResolverState& state)
{
    FillLayer* currChild = state.style()->accessBackgroundLayers();
    currChild->setBlendMode(FillLayer::initialFillBlendMode(BackgroundFillLayer));
    for (currChild = currChild->next(); currChild; currChild = currChild->next())
        currChild->clearBlendMode();
}

void StyleBuilderFunctions::applyInheritCSSPropertyBackgroundBlendMode(StyleResolverState& state)
{
    FillLayer* currChild = state.style()->accessBackgroundLayers();
    FillLayer* prevChild = 0;
    const FillLayer* currParent = state.parentStyle()->backgroundLayers();
    while (currParent && currParent->isBlendModeSet()) {
        if (!currChild) {
            /* Need to make a new layer.*/
            currChild = new FillLayer(BackgroundFillLayer);
            prevChild->setNext(currChild);
        }
        currChild->setBlendMode(currParent->blendMode());
        prevChild = currChild;
        currChild = prevChild->next();
        currParent = currParent->next();
    }

    while (currChild) {
        /* Reset any remaining layers to not have the property set. */
        currChild->clearBlendMode();
        currChild = currChild->next();
    }
}

void StyleBuilderFunctions::applyValueCSSPropertyBackgroundBlendMode(StyleResolverState& state, CSSValue* value)
{
    FillLayer* currChild = state.style()->accessBackgroundLayers();
    FillLayer* prevChild = 0;
    if (value->isValueList() && !value->isImageSetValue()) {
        /* Walk each value and put it into a layer, creating new layers as needed. */
        CSSValueList* valueList = toCSSValueList(value);
        for (unsigned int i = 0; i < valueList->length(); i++) {
            if (!currChild) {
                /* Need to make a new layer to hold this value */
                currChild = new FillLayer(BackgroundFillLayer);
                prevChild->setNext(currChild);
            }
            state.styleMap().mapFillBlendMode(CSSPropertyBackgroundBlendMode, currChild, valueList->itemWithoutBoundsCheck(i));
            prevChild = currChild;
            currChild = currChild->next();
        }
    } else {
        state.styleMap().mapFillBlendMode(CSSPropertyBackgroundBlendMode, currChild, value);
        currChild = currChild->next();
    }
    while (currChild) {
        /* Reset all remaining layers to not have the property set. */
        currChild->clearBlendMode();
        currChild = currChild->next();
    }
}

void StyleBuilderFunctions::applyInitialCSSPropertyBackgroundClip(StyleResolverState& state)
{
    FillLayer* currChild = state.style()->accessBackgroundLayers();
    currChild->setClip(FillLayer::initialFillClip(BackgroundFillLayer));
    for (currChild = currChild->next(); currChild; currChild = currChild->next())
        currChild->clearClip();
}

void StyleBuilderFunctions::applyInheritCSSPropertyBackgroundClip(StyleResolverState& state)
{
    FillLayer* currChild = state.style()->accessBackgroundLayers();
    FillLayer* prevChild = 0;
    const FillLayer* currParent = state.parentStyle()->backgroundLayers();
    while (currParent && currParent->isClipSet()) {
        if (!currChild) {
            /* Need to make a new layer.*/
            currChild = new FillLayer(BackgroundFillLayer);
            prevChild->setNext(currChild);
        }
        currChild->setClip(currParent->clip());
        prevChild = currChild;
        currChild = prevChild->next();
        currParent = currParent->next();
    }

    while (currChild) {
        /* Reset any remaining layers to not have the property set. */
        currChild->clearClip();
        currChild = currChild->next();
    }
}

void StyleBuilderFunctions::applyValueCSSPropertyBackgroundClip(StyleResolverState& state, CSSValue* value)
{
    FillLayer* currChild = state.style()->accessBackgroundLayers();
    FillLayer* prevChild = 0;
    if (value->isValueList() && !value->isImageSetValue()) {
        /* Walk each value and put it into a layer, creating new layers as needed. */
        CSSValueList* valueList = toCSSValueList(value);
        for (unsigned int i = 0; i < valueList->length(); i++) {
            if (!currChild) {
                /* Need to make a new layer to hold this value */
                currChild = new FillLayer(BackgroundFillLayer);
                prevChild->setNext(currChild);
            }
            state.styleMap().mapFillClip(CSSPropertyBackgroundClip, currChild, valueList->itemWithoutBoundsCheck(i));
            prevChild = currChild;
            currChild = currChild->next();
        }
    } else {
        state.styleMap().mapFillClip(CSSPropertyBackgroundClip, currChild, value);
        currChild = currChild->next();
    }
    while (currChild) {
        /* Reset all remaining layers to not have the property set. */
        currChild->clearClip();
        currChild = currChild->next();
    }
}

void StyleBuilderFunctions::applyInitialCSSPropertyBackgroundImage(StyleResolverState& state)
{
    FillLayer* currChild = state.style()->accessBackgroundLayers();
    currChild->setImage(FillLayer::initialFillImage(BackgroundFillLayer));
    for (currChild = currChild->next(); currChild; currChild = currChild->next())
        currChild->clearImage();
}

void StyleBuilderFunctions::applyInheritCSSPropertyBackgroundImage(StyleResolverState& state)
{
    FillLayer* currChild = state.style()->accessBackgroundLayers();
    FillLayer* prevChild = 0;
    const FillLayer* currParent = state.parentStyle()->backgroundLayers();
    while (currParent && currParent->isImageSet()) {
        if (!currChild) {
            /* Need to make a new layer.*/
            currChild = new FillLayer(BackgroundFillLayer);
            prevChild->setNext(currChild);
        }
        currChild->setImage(currParent->image());
        prevChild = currChild;
        currChild = prevChild->next();
        currParent = currParent->next();
    }

    while (currChild) {
        /* Reset any remaining layers to not have the property set. */
        currChild->clearImage();
        currChild = currChild->next();
    }
}

void StyleBuilderFunctions::applyValueCSSPropertyBackgroundImage(StyleResolverState& state, CSSValue* value)
{
    FillLayer* currChild = state.style()->accessBackgroundLayers();
    FillLayer* prevChild = 0;
    if (value->isValueList() && !value->isImageSetValue()) {
        /* Walk each value and put it into a layer, creating new layers as needed. */
        CSSValueList* valueList = toCSSValueList(value);
        for (unsigned int i = 0; i < valueList->length(); i++) {
            if (!currChild) {
                /* Need to make a new layer to hold this value */
                currChild = new FillLayer(BackgroundFillLayer);
                prevChild->setNext(currChild);
            }
            state.styleMap().mapFillImage(CSSPropertyBackgroundImage, currChild, valueList->itemWithoutBoundsCheck(i));
            prevChild = currChild;
            currChild = currChild->next();
        }
    } else {
        state.styleMap().mapFillImage(CSSPropertyBackgroundImage, currChild, value);
        currChild = currChild->next();
    }
    while (currChild) {
        /* Reset all remaining layers to not have the property set. */
        currChild->clearImage();
        currChild = currChild->next();
    }
}

void StyleBuilderFunctions::applyInitialCSSPropertyBackgroundOrigin(StyleResolverState& state)
{
    FillLayer* currChild = state.style()->accessBackgroundLayers();
    currChild->setOrigin(FillLayer::initialFillOrigin(BackgroundFillLayer));
    for (currChild = currChild->next(); currChild; currChild = currChild->next())
        currChild->clearOrigin();
}

void StyleBuilderFunctions::applyInheritCSSPropertyBackgroundOrigin(StyleResolverState& state)
{
    FillLayer* currChild = state.style()->accessBackgroundLayers();
    FillLayer* prevChild = 0;
    const FillLayer* currParent = state.parentStyle()->backgroundLayers();
    while (currParent && currParent->isOriginSet()) {
        if (!currChild) {
            /* Need to make a new layer.*/
            currChild = new FillLayer(BackgroundFillLayer);
            prevChild->setNext(currChild);
        }
        currChild->setOrigin(currParent->origin());
        prevChild = currChild;
        currChild = prevChild->next();
        currParent = currParent->next();
    }

    while (currChild) {
        /* Reset any remaining layers to not have the property set. */
        currChild->clearOrigin();
        currChild = currChild->next();
    }
}

void StyleBuilderFunctions::applyValueCSSPropertyBackgroundOrigin(StyleResolverState& state, CSSValue* value)
{
    FillLayer* currChild = state.style()->accessBackgroundLayers();
    FillLayer* prevChild = 0;
    if (value->isValueList() && !value->isImageSetValue()) {
        /* Walk each value and put it into a layer, creating new layers as needed. */
        CSSValueList* valueList = toCSSValueList(value);
        for (unsigned int i = 0; i < valueList->length(); i++) {
            if (!currChild) {
                /* Need to make a new layer to hold this value */
                currChild = new FillLayer(BackgroundFillLayer);
                prevChild->setNext(currChild);
            }
            state.styleMap().mapFillOrigin(CSSPropertyBackgroundOrigin, currChild, valueList->itemWithoutBoundsCheck(i));
            prevChild = currChild;
            currChild = currChild->next();
        }
    } else {
        state.styleMap().mapFillOrigin(CSSPropertyBackgroundOrigin, currChild, value);
        currChild = currChild->next();
    }
    while (currChild) {
        /* Reset all remaining layers to not have the property set. */
        currChild->clearOrigin();
        currChild = currChild->next();
    }
}

void StyleBuilderFunctions::applyInitialCSSPropertyBackgroundPositionX(StyleResolverState& state)
{
    FillLayer* currChild = state.style()->accessBackgroundLayers();
    currChild->setXPosition(FillLayer::initialFillXPosition(BackgroundFillLayer));
    for (currChild = currChild->next(); currChild; currChild = currChild->next())
        currChild->clearXPosition();
}

void StyleBuilderFunctions::applyInheritCSSPropertyBackgroundPositionX(StyleResolverState& state)
{
    FillLayer* currChild = state.style()->accessBackgroundLayers();
    FillLayer* prevChild = 0;
    const FillLayer* currParent = state.parentStyle()->backgroundLayers();
    while (currParent && currParent->isXPositionSet()) {
        if (!currChild) {
            /* Need to make a new layer.*/
            currChild = new FillLayer(BackgroundFillLayer);
            prevChild->setNext(currChild);
        }
        currChild->setXPosition(currParent->xPosition());
        prevChild = currChild;
        currChild = prevChild->next();
        currParent = currParent->next();
    }

    while (currChild) {
        /* Reset any remaining layers to not have the property set. */
        currChild->clearXPosition();
        currChild = currChild->next();
    }
}

void StyleBuilderFunctions::applyValueCSSPropertyBackgroundPositionX(StyleResolverState& state, CSSValue* value)
{
    FillLayer* currChild = state.style()->accessBackgroundLayers();
    FillLayer* prevChild = 0;
    if (value->isValueList() && !value->isImageSetValue()) {
        /* Walk each value and put it into a layer, creating new layers as needed. */
        CSSValueList* valueList = toCSSValueList(value);
        for (unsigned int i = 0; i < valueList->length(); i++) {
            if (!currChild) {
                /* Need to make a new layer to hold this value */
                currChild = new FillLayer(BackgroundFillLayer);
                prevChild->setNext(currChild);
            }
            state.styleMap().mapFillXPosition(CSSPropertyBackgroundPositionX, currChild, valueList->itemWithoutBoundsCheck(i));
            prevChild = currChild;
            currChild = currChild->next();
        }
    } else {
        state.styleMap().mapFillXPosition(CSSPropertyBackgroundPositionX, currChild, value);
        currChild = currChild->next();
    }
    while (currChild) {
        /* Reset all remaining layers to not have the property set. */
        currChild->clearXPosition();
        currChild = currChild->next();
    }
}

void StyleBuilderFunctions::applyInitialCSSPropertyBackgroundPositionY(StyleResolverState& state)
{
    FillLayer* currChild = state.style()->accessBackgroundLayers();
    currChild->setYPosition(FillLayer::initialFillYPosition(BackgroundFillLayer));
    for (currChild = currChild->next(); currChild; currChild = currChild->next())
        currChild->clearYPosition();
}

void StyleBuilderFunctions::applyInheritCSSPropertyBackgroundPositionY(StyleResolverState& state)
{
    FillLayer* currChild = state.style()->accessBackgroundLayers();
    FillLayer* prevChild = 0;
    const FillLayer* currParent = state.parentStyle()->backgroundLayers();
    while (currParent && currParent->isYPositionSet()) {
        if (!currChild) {
            /* Need to make a new layer.*/
            currChild = new FillLayer(BackgroundFillLayer);
            prevChild->setNext(currChild);
        }
        currChild->setYPosition(currParent->yPosition());
        prevChild = currChild;
        currChild = prevChild->next();
        currParent = currParent->next();
    }

    while (currChild) {
        /* Reset any remaining layers to not have the property set. */
        currChild->clearYPosition();
        currChild = currChild->next();
    }
}

void StyleBuilderFunctions::applyValueCSSPropertyBackgroundPositionY(StyleResolverState& state, CSSValue* value)
{
    FillLayer* currChild = state.style()->accessBackgroundLayers();
    FillLayer* prevChild = 0;
    if (value->isValueList() && !value->isImageSetValue()) {
        /* Walk each value and put it into a layer, creating new layers as needed. */
        CSSValueList* valueList = toCSSValueList(value);
        for (unsigned int i = 0; i < valueList->length(); i++) {
            if (!currChild) {
                /* Need to make a new layer to hold this value */
                currChild = new FillLayer(BackgroundFillLayer);
                prevChild->setNext(currChild);
            }
            state.styleMap().mapFillYPosition(CSSPropertyBackgroundPositionY, currChild, valueList->itemWithoutBoundsCheck(i));
            prevChild = currChild;
            currChild = currChild->next();
        }
    } else {
        state.styleMap().mapFillYPosition(CSSPropertyBackgroundPositionY, currChild, value);
        currChild = currChild->next();
    }
    while (currChild) {
        /* Reset all remaining layers to not have the property set. */
        currChild->clearYPosition();
        currChild = currChild->next();
    }
}

void StyleBuilderFunctions::applyInitialCSSPropertyBackgroundRepeatX(StyleResolverState& state)
{
    FillLayer* currChild = state.style()->accessBackgroundLayers();
    currChild->setRepeatX(FillLayer::initialFillRepeatX(BackgroundFillLayer));
    for (currChild = currChild->next(); currChild; currChild = currChild->next())
        currChild->clearRepeatX();
}

void StyleBuilderFunctions::applyInheritCSSPropertyBackgroundRepeatX(StyleResolverState& state)
{
    FillLayer* currChild = state.style()->accessBackgroundLayers();
    FillLayer* prevChild = 0;
    const FillLayer* currParent = state.parentStyle()->backgroundLayers();
    while (currParent && currParent->isRepeatXSet()) {
        if (!currChild) {
            /* Need to make a new layer.*/
            currChild = new FillLayer(BackgroundFillLayer);
            prevChild->setNext(currChild);
        }
        currChild->setRepeatX(currParent->repeatX());
        prevChild = currChild;
        currChild = prevChild->next();
        currParent = currParent->next();
    }

    while (currChild) {
        /* Reset any remaining layers to not have the property set. */
        currChild->clearRepeatX();
        currChild = currChild->next();
    }
}

void StyleBuilderFunctions::applyValueCSSPropertyBackgroundRepeatX(StyleResolverState& state, CSSValue* value)
{
    FillLayer* currChild = state.style()->accessBackgroundLayers();
    FillLayer* prevChild = 0;
    if (value->isValueList() && !value->isImageSetValue()) {
        /* Walk each value and put it into a layer, creating new layers as needed. */
        CSSValueList* valueList = toCSSValueList(value);
        for (unsigned int i = 0; i < valueList->length(); i++) {
            if (!currChild) {
                /* Need to make a new layer to hold this value */
                currChild = new FillLayer(BackgroundFillLayer);
                prevChild->setNext(currChild);
            }
            state.styleMap().mapFillRepeatX(CSSPropertyBackgroundRepeatX, currChild, valueList->itemWithoutBoundsCheck(i));
            prevChild = currChild;
            currChild = currChild->next();
        }
    } else {
        state.styleMap().mapFillRepeatX(CSSPropertyBackgroundRepeatX, currChild, value);
        currChild = currChild->next();
    }
    while (currChild) {
        /* Reset all remaining layers to not have the property set. */
        currChild->clearRepeatX();
        currChild = currChild->next();
    }
}

void StyleBuilderFunctions::applyInitialCSSPropertyBackgroundRepeatY(StyleResolverState& state)
{
    FillLayer* currChild = state.style()->accessBackgroundLayers();
    currChild->setRepeatY(FillLayer::initialFillRepeatY(BackgroundFillLayer));
    for (currChild = currChild->next(); currChild; currChild = currChild->next())
        currChild->clearRepeatY();
}

void StyleBuilderFunctions::applyInheritCSSPropertyBackgroundRepeatY(StyleResolverState& state)
{
    FillLayer* currChild = state.style()->accessBackgroundLayers();
    FillLayer* prevChild = 0;
    const FillLayer* currParent = state.parentStyle()->backgroundLayers();
    while (currParent && currParent->isRepeatYSet()) {
        if (!currChild) {
            /* Need to make a new layer.*/
            currChild = new FillLayer(BackgroundFillLayer);
            prevChild->setNext(currChild);
        }
        currChild->setRepeatY(currParent->repeatY());
        prevChild = currChild;
        currChild = prevChild->next();
        currParent = currParent->next();
    }

    while (currChild) {
        /* Reset any remaining layers to not have the property set. */
        currChild->clearRepeatY();
        currChild = currChild->next();
    }
}

void StyleBuilderFunctions::applyValueCSSPropertyBackgroundRepeatY(StyleResolverState& state, CSSValue* value)
{
    FillLayer* currChild = state.style()->accessBackgroundLayers();
    FillLayer* prevChild = 0;
    if (value->isValueList() && !value->isImageSetValue()) {
        /* Walk each value and put it into a layer, creating new layers as needed. */
        CSSValueList* valueList = toCSSValueList(value);
        for (unsigned int i = 0; i < valueList->length(); i++) {
            if (!currChild) {
                /* Need to make a new layer to hold this value */
                currChild = new FillLayer(BackgroundFillLayer);
                prevChild->setNext(currChild);
            }
            state.styleMap().mapFillRepeatY(CSSPropertyBackgroundRepeatY, currChild, valueList->itemWithoutBoundsCheck(i));
            prevChild = currChild;
            currChild = currChild->next();
        }
    } else {
        state.styleMap().mapFillRepeatY(CSSPropertyBackgroundRepeatY, currChild, value);
        currChild = currChild->next();
    }
    while (currChild) {
        /* Reset all remaining layers to not have the property set. */
        currChild->clearRepeatY();
        currChild = currChild->next();
    }
}

void StyleBuilderFunctions::applyInitialCSSPropertyBackgroundSize(StyleResolverState& state)
{
    FillLayer* currChild = state.style()->accessBackgroundLayers();
    currChild->setSize(FillLayer::initialFillSize(BackgroundFillLayer));
    for (currChild = currChild->next(); currChild; currChild = currChild->next())
        currChild->clearSize();
}

void StyleBuilderFunctions::applyInheritCSSPropertyBackgroundSize(StyleResolverState& state)
{
    FillLayer* currChild = state.style()->accessBackgroundLayers();
    FillLayer* prevChild = 0;
    const FillLayer* currParent = state.parentStyle()->backgroundLayers();
    while (currParent && currParent->isSizeSet()) {
        if (!currChild) {
            /* Need to make a new layer.*/
            currChild = new FillLayer(BackgroundFillLayer);
            prevChild->setNext(currChild);
        }
        currChild->setSize(currParent->size());
        prevChild = currChild;
        currChild = prevChild->next();
        currParent = currParent->next();
    }

    while (currChild) {
        /* Reset any remaining layers to not have the property set. */
        currChild->clearSize();
        currChild = currChild->next();
    }
}

void StyleBuilderFunctions::applyValueCSSPropertyBackgroundSize(StyleResolverState& state, CSSValue* value)
{
    FillLayer* currChild = state.style()->accessBackgroundLayers();
    FillLayer* prevChild = 0;
    if (value->isValueList() && !value->isImageSetValue()) {
        /* Walk each value and put it into a layer, creating new layers as needed. */
        CSSValueList* valueList = toCSSValueList(value);
        for (unsigned int i = 0; i < valueList->length(); i++) {
            if (!currChild) {
                /* Need to make a new layer to hold this value */
                currChild = new FillLayer(BackgroundFillLayer);
                prevChild->setNext(currChild);
            }
            state.styleMap().mapFillSize(CSSPropertyBackgroundSize, currChild, valueList->itemWithoutBoundsCheck(i));
            prevChild = currChild;
            currChild = currChild->next();
        }
    } else {
        state.styleMap().mapFillSize(CSSPropertyBackgroundSize, currChild, value);
        currChild = currChild->next();
    }
    while (currChild) {
        /* Reset all remaining layers to not have the property set. */
        currChild->clearSize();
        currChild = currChild->next();
    }
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitBackgroundComposite(StyleResolverState& state)
{
    FillLayer* currChild = state.style()->accessBackgroundLayers();
    currChild->setComposite(FillLayer::initialFillComposite(BackgroundFillLayer));
    for (currChild = currChild->next(); currChild; currChild = currChild->next())
        currChild->clearComposite();
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitBackgroundComposite(StyleResolverState& state)
{
    FillLayer* currChild = state.style()->accessBackgroundLayers();
    FillLayer* prevChild = 0;
    const FillLayer* currParent = state.parentStyle()->backgroundLayers();
    while (currParent && currParent->isCompositeSet()) {
        if (!currChild) {
            /* Need to make a new layer.*/
            currChild = new FillLayer(BackgroundFillLayer);
            prevChild->setNext(currChild);
        }
        currChild->setComposite(currParent->composite());
        prevChild = currChild;
        currChild = prevChild->next();
        currParent = currParent->next();
    }

    while (currChild) {
        /* Reset any remaining layers to not have the property set. */
        currChild->clearComposite();
        currChild = currChild->next();
    }
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitBackgroundComposite(StyleResolverState& state, CSSValue* value)
{
    FillLayer* currChild = state.style()->accessBackgroundLayers();
    FillLayer* prevChild = 0;
    if (value->isValueList() && !value->isImageSetValue()) {
        /* Walk each value and put it into a layer, creating new layers as needed. */
        CSSValueList* valueList = toCSSValueList(value);
        for (unsigned int i = 0; i < valueList->length(); i++) {
            if (!currChild) {
                /* Need to make a new layer to hold this value */
                currChild = new FillLayer(BackgroundFillLayer);
                prevChild->setNext(currChild);
            }
            state.styleMap().mapFillComposite(CSSPropertyWebkitBackgroundComposite, currChild, valueList->itemWithoutBoundsCheck(i));
            prevChild = currChild;
            currChild = currChild->next();
        }
    } else {
        state.styleMap().mapFillComposite(CSSPropertyWebkitBackgroundComposite, currChild, value);
        currChild = currChild->next();
    }
    while (currChild) {
        /* Reset all remaining layers to not have the property set. */
        currChild->clearComposite();
        currChild = currChild->next();
    }
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitMaskClip(StyleResolverState& state)
{
    FillLayer* currChild = state.style()->accessMaskLayers();
    currChild->setClip(FillLayer::initialFillClip(MaskFillLayer));
    for (currChild = currChild->next(); currChild; currChild = currChild->next())
        currChild->clearClip();
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitMaskClip(StyleResolverState& state)
{
    FillLayer* currChild = state.style()->accessMaskLayers();
    FillLayer* prevChild = 0;
    const FillLayer* currParent = state.parentStyle()->maskLayers();
    while (currParent && currParent->isClipSet()) {
        if (!currChild) {
            /* Need to make a new layer.*/
            currChild = new FillLayer(MaskFillLayer);
            prevChild->setNext(currChild);
        }
        currChild->setClip(currParent->clip());
        prevChild = currChild;
        currChild = prevChild->next();
        currParent = currParent->next();
    }

    while (currChild) {
        /* Reset any remaining layers to not have the property set. */
        currChild->clearClip();
        currChild = currChild->next();
    }
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitMaskClip(StyleResolverState& state, CSSValue* value)
{
    FillLayer* currChild = state.style()->accessMaskLayers();
    FillLayer* prevChild = 0;
    if (value->isValueList() && !value->isImageSetValue()) {
        /* Walk each value and put it into a layer, creating new layers as needed. */
        CSSValueList* valueList = toCSSValueList(value);
        for (unsigned int i = 0; i < valueList->length(); i++) {
            if (!currChild) {
                /* Need to make a new layer to hold this value */
                currChild = new FillLayer(MaskFillLayer);
                prevChild->setNext(currChild);
            }
            state.styleMap().mapFillClip(CSSPropertyWebkitMaskClip, currChild, valueList->itemWithoutBoundsCheck(i));
            prevChild = currChild;
            currChild = currChild->next();
        }
    } else {
        state.styleMap().mapFillClip(CSSPropertyWebkitMaskClip, currChild, value);
        currChild = currChild->next();
    }
    while (currChild) {
        /* Reset all remaining layers to not have the property set. */
        currChild->clearClip();
        currChild = currChild->next();
    }
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitMaskComposite(StyleResolverState& state)
{
    FillLayer* currChild = state.style()->accessMaskLayers();
    currChild->setComposite(FillLayer::initialFillComposite(MaskFillLayer));
    for (currChild = currChild->next(); currChild; currChild = currChild->next())
        currChild->clearComposite();
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitMaskComposite(StyleResolverState& state)
{
    FillLayer* currChild = state.style()->accessMaskLayers();
    FillLayer* prevChild = 0;
    const FillLayer* currParent = state.parentStyle()->maskLayers();
    while (currParent && currParent->isCompositeSet()) {
        if (!currChild) {
            /* Need to make a new layer.*/
            currChild = new FillLayer(MaskFillLayer);
            prevChild->setNext(currChild);
        }
        currChild->setComposite(currParent->composite());
        prevChild = currChild;
        currChild = prevChild->next();
        currParent = currParent->next();
    }

    while (currChild) {
        /* Reset any remaining layers to not have the property set. */
        currChild->clearComposite();
        currChild = currChild->next();
    }
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitMaskComposite(StyleResolverState& state, CSSValue* value)
{
    FillLayer* currChild = state.style()->accessMaskLayers();
    FillLayer* prevChild = 0;
    if (value->isValueList() && !value->isImageSetValue()) {
        /* Walk each value and put it into a layer, creating new layers as needed. */
        CSSValueList* valueList = toCSSValueList(value);
        for (unsigned int i = 0; i < valueList->length(); i++) {
            if (!currChild) {
                /* Need to make a new layer to hold this value */
                currChild = new FillLayer(MaskFillLayer);
                prevChild->setNext(currChild);
            }
            state.styleMap().mapFillComposite(CSSPropertyWebkitMaskComposite, currChild, valueList->itemWithoutBoundsCheck(i));
            prevChild = currChild;
            currChild = currChild->next();
        }
    } else {
        state.styleMap().mapFillComposite(CSSPropertyWebkitMaskComposite, currChild, value);
        currChild = currChild->next();
    }
    while (currChild) {
        /* Reset all remaining layers to not have the property set. */
        currChild->clearComposite();
        currChild = currChild->next();
    }
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitMaskImage(StyleResolverState& state)
{
    FillLayer* currChild = state.style()->accessMaskLayers();
    currChild->setImage(FillLayer::initialFillImage(MaskFillLayer));
    for (currChild = currChild->next(); currChild; currChild = currChild->next())
        currChild->clearImage();
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitMaskImage(StyleResolverState& state)
{
    FillLayer* currChild = state.style()->accessMaskLayers();
    FillLayer* prevChild = 0;
    const FillLayer* currParent = state.parentStyle()->maskLayers();
    while (currParent && currParent->isImageSet()) {
        if (!currChild) {
            /* Need to make a new layer.*/
            currChild = new FillLayer(MaskFillLayer);
            prevChild->setNext(currChild);
        }
        currChild->setImage(currParent->image());
        prevChild = currChild;
        currChild = prevChild->next();
        currParent = currParent->next();
    }

    while (currChild) {
        /* Reset any remaining layers to not have the property set. */
        currChild->clearImage();
        currChild = currChild->next();
    }
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitMaskImage(StyleResolverState& state, CSSValue* value)
{
    FillLayer* currChild = state.style()->accessMaskLayers();
    FillLayer* prevChild = 0;
    if (value->isValueList() && !value->isImageSetValue()) {
        /* Walk each value and put it into a layer, creating new layers as needed. */
        CSSValueList* valueList = toCSSValueList(value);
        for (unsigned int i = 0; i < valueList->length(); i++) {
            if (!currChild) {
                /* Need to make a new layer to hold this value */
                currChild = new FillLayer(MaskFillLayer);
                prevChild->setNext(currChild);
            }
            state.styleMap().mapFillImage(CSSPropertyWebkitMaskImage, currChild, valueList->itemWithoutBoundsCheck(i));
            prevChild = currChild;
            currChild = currChild->next();
        }
    } else {
        state.styleMap().mapFillImage(CSSPropertyWebkitMaskImage, currChild, value);
        currChild = currChild->next();
    }
    while (currChild) {
        /* Reset all remaining layers to not have the property set. */
        currChild->clearImage();
        currChild = currChild->next();
    }
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitMaskOrigin(StyleResolverState& state)
{
    FillLayer* currChild = state.style()->accessMaskLayers();
    currChild->setOrigin(FillLayer::initialFillOrigin(MaskFillLayer));
    for (currChild = currChild->next(); currChild; currChild = currChild->next())
        currChild->clearOrigin();
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitMaskOrigin(StyleResolverState& state)
{
    FillLayer* currChild = state.style()->accessMaskLayers();
    FillLayer* prevChild = 0;
    const FillLayer* currParent = state.parentStyle()->maskLayers();
    while (currParent && currParent->isOriginSet()) {
        if (!currChild) {
            /* Need to make a new layer.*/
            currChild = new FillLayer(MaskFillLayer);
            prevChild->setNext(currChild);
        }
        currChild->setOrigin(currParent->origin());
        prevChild = currChild;
        currChild = prevChild->next();
        currParent = currParent->next();
    }

    while (currChild) {
        /* Reset any remaining layers to not have the property set. */
        currChild->clearOrigin();
        currChild = currChild->next();
    }
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitMaskOrigin(StyleResolverState& state, CSSValue* value)
{
    FillLayer* currChild = state.style()->accessMaskLayers();
    FillLayer* prevChild = 0;
    if (value->isValueList() && !value->isImageSetValue()) {
        /* Walk each value and put it into a layer, creating new layers as needed. */
        CSSValueList* valueList = toCSSValueList(value);
        for (unsigned int i = 0; i < valueList->length(); i++) {
            if (!currChild) {
                /* Need to make a new layer to hold this value */
                currChild = new FillLayer(MaskFillLayer);
                prevChild->setNext(currChild);
            }
            state.styleMap().mapFillOrigin(CSSPropertyWebkitMaskOrigin, currChild, valueList->itemWithoutBoundsCheck(i));
            prevChild = currChild;
            currChild = currChild->next();
        }
    } else {
        state.styleMap().mapFillOrigin(CSSPropertyWebkitMaskOrigin, currChild, value);
        currChild = currChild->next();
    }
    while (currChild) {
        /* Reset all remaining layers to not have the property set. */
        currChild->clearOrigin();
        currChild = currChild->next();
    }
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitMaskPositionX(StyleResolverState& state)
{
    FillLayer* currChild = state.style()->accessMaskLayers();
    currChild->setXPosition(FillLayer::initialFillXPosition(MaskFillLayer));
    for (currChild = currChild->next(); currChild; currChild = currChild->next())
        currChild->clearXPosition();
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitMaskPositionX(StyleResolverState& state)
{
    FillLayer* currChild = state.style()->accessMaskLayers();
    FillLayer* prevChild = 0;
    const FillLayer* currParent = state.parentStyle()->maskLayers();
    while (currParent && currParent->isXPositionSet()) {
        if (!currChild) {
            /* Need to make a new layer.*/
            currChild = new FillLayer(MaskFillLayer);
            prevChild->setNext(currChild);
        }
        currChild->setXPosition(currParent->xPosition());
        prevChild = currChild;
        currChild = prevChild->next();
        currParent = currParent->next();
    }

    while (currChild) {
        /* Reset any remaining layers to not have the property set. */
        currChild->clearXPosition();
        currChild = currChild->next();
    }
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitMaskPositionX(StyleResolverState& state, CSSValue* value)
{
    FillLayer* currChild = state.style()->accessMaskLayers();
    FillLayer* prevChild = 0;
    if (value->isValueList() && !value->isImageSetValue()) {
        /* Walk each value and put it into a layer, creating new layers as needed. */
        CSSValueList* valueList = toCSSValueList(value);
        for (unsigned int i = 0; i < valueList->length(); i++) {
            if (!currChild) {
                /* Need to make a new layer to hold this value */
                currChild = new FillLayer(MaskFillLayer);
                prevChild->setNext(currChild);
            }
            state.styleMap().mapFillXPosition(CSSPropertyWebkitMaskPositionX, currChild, valueList->itemWithoutBoundsCheck(i));
            prevChild = currChild;
            currChild = currChild->next();
        }
    } else {
        state.styleMap().mapFillXPosition(CSSPropertyWebkitMaskPositionX, currChild, value);
        currChild = currChild->next();
    }
    while (currChild) {
        /* Reset all remaining layers to not have the property set. */
        currChild->clearXPosition();
        currChild = currChild->next();
    }
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitMaskPositionY(StyleResolverState& state)
{
    FillLayer* currChild = state.style()->accessMaskLayers();
    currChild->setYPosition(FillLayer::initialFillYPosition(MaskFillLayer));
    for (currChild = currChild->next(); currChild; currChild = currChild->next())
        currChild->clearYPosition();
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitMaskPositionY(StyleResolverState& state)
{
    FillLayer* currChild = state.style()->accessMaskLayers();
    FillLayer* prevChild = 0;
    const FillLayer* currParent = state.parentStyle()->maskLayers();
    while (currParent && currParent->isYPositionSet()) {
        if (!currChild) {
            /* Need to make a new layer.*/
            currChild = new FillLayer(MaskFillLayer);
            prevChild->setNext(currChild);
        }
        currChild->setYPosition(currParent->yPosition());
        prevChild = currChild;
        currChild = prevChild->next();
        currParent = currParent->next();
    }

    while (currChild) {
        /* Reset any remaining layers to not have the property set. */
        currChild->clearYPosition();
        currChild = currChild->next();
    }
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitMaskPositionY(StyleResolverState& state, CSSValue* value)
{
    FillLayer* currChild = state.style()->accessMaskLayers();
    FillLayer* prevChild = 0;
    if (value->isValueList() && !value->isImageSetValue()) {
        /* Walk each value and put it into a layer, creating new layers as needed. */
        CSSValueList* valueList = toCSSValueList(value);
        for (unsigned int i = 0; i < valueList->length(); i++) {
            if (!currChild) {
                /* Need to make a new layer to hold this value */
                currChild = new FillLayer(MaskFillLayer);
                prevChild->setNext(currChild);
            }
            state.styleMap().mapFillYPosition(CSSPropertyWebkitMaskPositionY, currChild, valueList->itemWithoutBoundsCheck(i));
            prevChild = currChild;
            currChild = currChild->next();
        }
    } else {
        state.styleMap().mapFillYPosition(CSSPropertyWebkitMaskPositionY, currChild, value);
        currChild = currChild->next();
    }
    while (currChild) {
        /* Reset all remaining layers to not have the property set. */
        currChild->clearYPosition();
        currChild = currChild->next();
    }
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitMaskRepeatX(StyleResolverState& state)
{
    FillLayer* currChild = state.style()->accessMaskLayers();
    currChild->setRepeatX(FillLayer::initialFillRepeatX(MaskFillLayer));
    for (currChild = currChild->next(); currChild; currChild = currChild->next())
        currChild->clearRepeatX();
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitMaskRepeatX(StyleResolverState& state)
{
    FillLayer* currChild = state.style()->accessMaskLayers();
    FillLayer* prevChild = 0;
    const FillLayer* currParent = state.parentStyle()->maskLayers();
    while (currParent && currParent->isRepeatXSet()) {
        if (!currChild) {
            /* Need to make a new layer.*/
            currChild = new FillLayer(MaskFillLayer);
            prevChild->setNext(currChild);
        }
        currChild->setRepeatX(currParent->repeatX());
        prevChild = currChild;
        currChild = prevChild->next();
        currParent = currParent->next();
    }

    while (currChild) {
        /* Reset any remaining layers to not have the property set. */
        currChild->clearRepeatX();
        currChild = currChild->next();
    }
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitMaskRepeatX(StyleResolverState& state, CSSValue* value)
{
    FillLayer* currChild = state.style()->accessMaskLayers();
    FillLayer* prevChild = 0;
    if (value->isValueList() && !value->isImageSetValue()) {
        /* Walk each value and put it into a layer, creating new layers as needed. */
        CSSValueList* valueList = toCSSValueList(value);
        for (unsigned int i = 0; i < valueList->length(); i++) {
            if (!currChild) {
                /* Need to make a new layer to hold this value */
                currChild = new FillLayer(MaskFillLayer);
                prevChild->setNext(currChild);
            }
            state.styleMap().mapFillRepeatX(CSSPropertyWebkitMaskRepeatX, currChild, valueList->itemWithoutBoundsCheck(i));
            prevChild = currChild;
            currChild = currChild->next();
        }
    } else {
        state.styleMap().mapFillRepeatX(CSSPropertyWebkitMaskRepeatX, currChild, value);
        currChild = currChild->next();
    }
    while (currChild) {
        /* Reset all remaining layers to not have the property set. */
        currChild->clearRepeatX();
        currChild = currChild->next();
    }
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitMaskRepeatY(StyleResolverState& state)
{
    FillLayer* currChild = state.style()->accessMaskLayers();
    currChild->setRepeatY(FillLayer::initialFillRepeatY(MaskFillLayer));
    for (currChild = currChild->next(); currChild; currChild = currChild->next())
        currChild->clearRepeatY();
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitMaskRepeatY(StyleResolverState& state)
{
    FillLayer* currChild = state.style()->accessMaskLayers();
    FillLayer* prevChild = 0;
    const FillLayer* currParent = state.parentStyle()->maskLayers();
    while (currParent && currParent->isRepeatYSet()) {
        if (!currChild) {
            /* Need to make a new layer.*/
            currChild = new FillLayer(MaskFillLayer);
            prevChild->setNext(currChild);
        }
        currChild->setRepeatY(currParent->repeatY());
        prevChild = currChild;
        currChild = prevChild->next();
        currParent = currParent->next();
    }

    while (currChild) {
        /* Reset any remaining layers to not have the property set. */
        currChild->clearRepeatY();
        currChild = currChild->next();
    }
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitMaskRepeatY(StyleResolverState& state, CSSValue* value)
{
    FillLayer* currChild = state.style()->accessMaskLayers();
    FillLayer* prevChild = 0;
    if (value->isValueList() && !value->isImageSetValue()) {
        /* Walk each value and put it into a layer, creating new layers as needed. */
        CSSValueList* valueList = toCSSValueList(value);
        for (unsigned int i = 0; i < valueList->length(); i++) {
            if (!currChild) {
                /* Need to make a new layer to hold this value */
                currChild = new FillLayer(MaskFillLayer);
                prevChild->setNext(currChild);
            }
            state.styleMap().mapFillRepeatY(CSSPropertyWebkitMaskRepeatY, currChild, valueList->itemWithoutBoundsCheck(i));
            prevChild = currChild;
            currChild = currChild->next();
        }
    } else {
        state.styleMap().mapFillRepeatY(CSSPropertyWebkitMaskRepeatY, currChild, value);
        currChild = currChild->next();
    }
    while (currChild) {
        /* Reset all remaining layers to not have the property set. */
        currChild->clearRepeatY();
        currChild = currChild->next();
    }
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitMaskSize(StyleResolverState& state)
{
    FillLayer* currChild = state.style()->accessMaskLayers();
    currChild->setSize(FillLayer::initialFillSize(MaskFillLayer));
    for (currChild = currChild->next(); currChild; currChild = currChild->next())
        currChild->clearSize();
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitMaskSize(StyleResolverState& state)
{
    FillLayer* currChild = state.style()->accessMaskLayers();
    FillLayer* prevChild = 0;
    const FillLayer* currParent = state.parentStyle()->maskLayers();
    while (currParent && currParent->isSizeSet()) {
        if (!currChild) {
            /* Need to make a new layer.*/
            currChild = new FillLayer(MaskFillLayer);
            prevChild->setNext(currChild);
        }
        currChild->setSize(currParent->size());
        prevChild = currChild;
        currChild = prevChild->next();
        currParent = currParent->next();
    }

    while (currChild) {
        /* Reset any remaining layers to not have the property set. */
        currChild->clearSize();
        currChild = currChild->next();
    }
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitMaskSize(StyleResolverState& state, CSSValue* value)
{
    FillLayer* currChild = state.style()->accessMaskLayers();
    FillLayer* prevChild = 0;
    if (value->isValueList() && !value->isImageSetValue()) {
        /* Walk each value and put it into a layer, creating new layers as needed. */
        CSSValueList* valueList = toCSSValueList(value);
        for (unsigned int i = 0; i < valueList->length(); i++) {
            if (!currChild) {
                /* Need to make a new layer to hold this value */
                currChild = new FillLayer(MaskFillLayer);
                prevChild->setNext(currChild);
            }
            state.styleMap().mapFillSize(CSSPropertyWebkitMaskSize, currChild, valueList->itemWithoutBoundsCheck(i));
            prevChild = currChild;
            currChild = currChild->next();
        }
    } else {
        state.styleMap().mapFillSize(CSSPropertyWebkitMaskSize, currChild, value);
        currChild = currChild->next();
    }
    while (currChild) {
        /* Reset all remaining layers to not have the property set. */
        currChild->clearSize();
        currChild = currChild->next();
    }
}


void StyleBuilderFunctions::applyInitialCSSPropertyFontStyle(StyleResolverState& state)
{
    state.fontBuilder().setItalic(FontItalicOff);
}

void StyleBuilderFunctions::applyInheritCSSPropertyFontStyle(StyleResolverState& state)
{
    state.fontBuilder().setItalic(state.parentFontDescription().italic());
}

void StyleBuilderFunctions::applyValueCSSPropertyFontStyle(StyleResolverState& state, CSSValue* value)
{
    if (!value->isPrimitiveValue())
        return;
    CSSPrimitiveValue* primitiveValue = toCSSPrimitiveValue(value);
    state.fontBuilder().setItalic(static_cast<FontItalic>(*primitiveValue));
}

void StyleBuilderFunctions::applyInitialCSSPropertyFontVariant(StyleResolverState& state)
{
    state.fontBuilder().setSmallCaps(FontSmallCapsOff);
}

void StyleBuilderFunctions::applyInheritCSSPropertyFontVariant(StyleResolverState& state)
{
    state.fontBuilder().setSmallCaps(state.parentFontDescription().smallCaps());
}

void StyleBuilderFunctions::applyValueCSSPropertyFontVariant(StyleResolverState& state, CSSValue* value)
{
    if (!value->isPrimitiveValue())
        return;
    CSSPrimitiveValue* primitiveValue = toCSSPrimitiveValue(value);
    state.fontBuilder().setSmallCaps(static_cast<FontSmallCaps>(*primitiveValue));
}

void StyleBuilderFunctions::applyInitialCSSPropertyTextRendering(StyleResolverState& state)
{
    state.fontBuilder().setTextRenderingMode(AutoTextRendering);
}

void StyleBuilderFunctions::applyInheritCSSPropertyTextRendering(StyleResolverState& state)
{
    state.fontBuilder().setTextRenderingMode(state.parentFontDescription().textRenderingMode());
}

void StyleBuilderFunctions::applyValueCSSPropertyTextRendering(StyleResolverState& state, CSSValue* value)
{
    if (!value->isPrimitiveValue())
        return;
    CSSPrimitiveValue* primitiveValue = toCSSPrimitiveValue(value);
    state.fontBuilder().setTextRenderingMode(static_cast<TextRenderingMode>(*primitiveValue));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitFontKerning(StyleResolverState& state)
{
    state.fontBuilder().setKerning(FontDescription::AutoKerning);
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitFontKerning(StyleResolverState& state)
{
    state.fontBuilder().setKerning(state.parentFontDescription().kerning());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitFontKerning(StyleResolverState& state, CSSValue* value)
{
    if (!value->isPrimitiveValue())
        return;
    CSSPrimitiveValue* primitiveValue = toCSSPrimitiveValue(value);
    state.fontBuilder().setKerning(static_cast<FontDescription::Kerning>(*primitiveValue));
}

void StyleBuilderFunctions::applyInitialCSSPropertyWebkitFontSmoothing(StyleResolverState& state)
{
    state.fontBuilder().setFontSmoothing(AutoSmoothing);
}

void StyleBuilderFunctions::applyInheritCSSPropertyWebkitFontSmoothing(StyleResolverState& state)
{
    state.fontBuilder().setFontSmoothing(state.parentFontDescription().fontSmoothing());
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitFontSmoothing(StyleResolverState& state, CSSValue* value)
{
    if (!value->isPrimitiveValue())
        return;
    CSSPrimitiveValue* primitiveValue = toCSSPrimitiveValue(value);
    state.fontBuilder().setFontSmoothing(static_cast<FontSmoothingMode>(*primitiveValue));
}


void StyleBuilderFunctions::applyValueCSSPropertyWebkitMarqueeRepetition(StyleResolverState& state, CSSValue* value)
{
    if (!value->isPrimitiveValue())
        return;

    CSSPrimitiveValue* primitiveValue = toCSSPrimitiveValue(value);
    if (primitiveValue->getValueID() == CSSValueInfinite)
        state.style()->setMarqueeLoopCount(-1);
    else
        state.style()->setMarqueeLoopCount(primitiveValue->getValue<int>(CSSPrimitiveValue::CSS_NUMBER));
}


void StyleBuilderFunctions::applyValueCSSPropertyWebkitShapeInside(StyleResolverState& state, CSSValue* value)
{
    if (value->isPrimitiveValue()) {
        CSSPrimitiveValue* primitiveValue = toCSSPrimitiveValue(value);
        if (primitiveValue->getValueID() == CSSValueAuto)
            state.style()->setShapeInside(0);
        else if (primitiveValue->getValueID() == CSSValueOutsideShape)
            state.style()->setShapeInside(ShapeValue::createOutsideValue());
        else if (primitiveValue->isShape()) {
            state.style()->setShapeInside(ShapeValue::createShapeValue(basicShapeForValue(state, primitiveValue->getShapeValue())));
        }
    } else if (value->isImageValue()) {
        state.style()->setShapeInside(ShapeValue::createImageValue(state.styleImage(CSSPropertyWebkitShapeInside, value)));
    }
}

void StyleBuilderFunctions::applyValueCSSPropertyWebkitShapeOutside(StyleResolverState& state, CSSValue* value)
{
    if (value->isPrimitiveValue()) {
        CSSPrimitiveValue* primitiveValue = toCSSPrimitiveValue(value);
        if (primitiveValue->getValueID() == CSSValueAuto)
            state.style()->setShapeOutside(0);
        else if (primitiveValue->getValueID() == CSSValueOutsideShape)
            state.style()->setShapeOutside(ShapeValue::createOutsideValue());
        else if (primitiveValue->isShape()) {
            state.style()->setShapeOutside(ShapeValue::createShapeValue(basicShapeForValue(state, primitiveValue->getShapeValue())));
        }
    } else if (value->isImageValue()) {
        state.style()->setShapeOutside(ShapeValue::createImageValue(state.styleImage(CSSPropertyWebkitShapeOutside, value)));
    }
}

} // namespace WebCore
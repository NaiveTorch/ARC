// Code generated from InspectorInstrumentation.idl

#include "config.h"

#include "InspectorCanvasInstrumentationInl.h"
#include "InspectorConsoleInstrumentationInl.h"
#include "InspectorDatabaseInstrumentationInl.h"
#include "InspectorInstrumentationInl.h"
#include "InspectorOverridesInl.h"
#include "InstrumentingAgentsInl.h"
#include "core/inspector/InspectorAgent.h"
#include "core/inspector/InspectorApplicationCacheAgent.h"
#include "core/inspector/InspectorCSSAgent.h"
#include "core/inspector/InspectorCanvasAgent.h"
#include "core/inspector/InspectorConsoleAgent.h"
#include "core/inspector/InspectorDOMAgent.h"
#include "core/inspector/InspectorDOMDebuggerAgent.h"
#include "core/inspector/InspectorDOMStorageAgent.h"
#include "core/inspector/InspectorDatabaseAgent.h"
#include "core/inspector/InspectorDebuggerAgent.h"
#include "core/inspector/InspectorLayerTreeAgent.h"
#include "core/inspector/InspectorPageAgent.h"
#include "core/inspector/InspectorProfilerAgent.h"
#include "core/inspector/InspectorResourceAgent.h"
#include "core/inspector/InspectorTimelineAgent.h"
#include "core/inspector/InspectorWorkerAgent.h"
#include "core/inspector/PageDebuggerAgent.h"
#include "core/inspector/PageRuntimeAgent.h"
#include "core/inspector/WorkerRuntimeAgent.h"

namespace WebCore {

InstrumentingAgents::InstrumentingAgents()
    : m_inspectorAgent(0)
    , m_inspectorApplicationCacheAgent(0)
    , m_inspectorCSSAgent(0)
    , m_inspectorCanvasAgent(0)
    , m_inspectorConsoleAgent(0)
    , m_inspectorDOMAgent(0)
    , m_inspectorDOMDebuggerAgent(0)
    , m_inspectorDOMStorageAgent(0)
    , m_inspectorDatabaseAgent(0)
    , m_inspectorDebuggerAgent(0)
    , m_inspectorLayerTreeAgent(0)
    , m_inspectorPageAgent(0)
    , m_inspectorProfilerAgent(0)
    , m_inspectorResourceAgent(0)
    , m_inspectorTimelineAgent(0)
    , m_inspectorWorkerAgent(0)
    , m_pageDebuggerAgent(0)
    , m_pageRuntimeAgent(0)
    , m_workerRuntimeAgent(0)
{
}

void InstrumentingAgents::reset()
{
    m_inspectorAgent = 0;
    m_inspectorApplicationCacheAgent = 0;
    m_inspectorCSSAgent = 0;
    m_inspectorCanvasAgent = 0;
    m_inspectorConsoleAgent = 0;
    m_inspectorDOMAgent = 0;
    m_inspectorDOMDebuggerAgent = 0;
    m_inspectorDOMStorageAgent = 0;
    m_inspectorDatabaseAgent = 0;
    m_inspectorDebuggerAgent = 0;
    m_inspectorLayerTreeAgent = 0;
    m_inspectorPageAgent = 0;
    m_inspectorProfilerAgent = 0;
    m_inspectorResourceAgent = 0;
    m_inspectorTimelineAgent = 0;
    m_inspectorWorkerAgent = 0;
    m_pageDebuggerAgent = 0;
    m_pageRuntimeAgent = 0;
    m_workerRuntimeAgent = 0;
}

namespace InspectorInstrumentation {

void didClearWindowObjectInWorldImpl(InstrumentingAgents* agents, Frame* paramFrame, DOMWrapperWorld* paramDOMWrapperWorld)
{
    if (InspectorPageAgent* agent = agents->inspectorPageAgent())
        agent->didClearWindowObjectInWorld(paramFrame, paramDOMWrapperWorld);
    if (InspectorAgent* agent = agents->inspectorAgent())
        agent->didClearWindowObjectInWorld(paramFrame, paramDOMWrapperWorld);
    if (PageDebuggerAgent* agent = agents->pageDebuggerAgent())
        agent->didClearWindowObjectInWorld(paramFrame, paramDOMWrapperWorld);
    if (PageRuntimeAgent* agent = agents->pageRuntimeAgent())
        agent->didClearWindowObjectInWorld(paramFrame, paramDOMWrapperWorld);
}

void willInsertDOMNodeImpl(InstrumentingAgents* agents, Node* parent)
{
    if (InspectorDOMDebuggerAgent* agent = agents->inspectorDOMDebuggerAgent())
        agent->willInsertDOMNode(parent);
}

void didInsertDOMNodeImpl(InstrumentingAgents* agents, Node* paramNode)
{
    if (InspectorDOMAgent* agent = agents->inspectorDOMAgent())
        agent->didInsertDOMNode(paramNode);
    if (InspectorDOMDebuggerAgent* agent = agents->inspectorDOMDebuggerAgent())
        agent->didInsertDOMNode(paramNode);
}

void willRemoveDOMNodeImpl(InstrumentingAgents* agents, Node* paramNode)
{
    if (InspectorDOMDebuggerAgent* agent = agents->inspectorDOMDebuggerAgent())
        agent->willRemoveDOMNode(paramNode);
    if (InspectorDOMAgent* agent = agents->inspectorDOMAgent())
        agent->willRemoveDOMNode(paramNode);
}

void willModifyDOMAttrImpl(InstrumentingAgents* agents, Element* paramElement, const AtomicString& oldValue, const AtomicString& newValue)
{
    if (InspectorDOMDebuggerAgent* agent = agents->inspectorDOMDebuggerAgent())
        agent->willModifyDOMAttr(paramElement, oldValue, newValue);
    if (InspectorDOMAgent* agent = agents->inspectorDOMAgent())
        agent->willModifyDOMAttr(paramElement, oldValue, newValue);
}

void didModifyDOMAttrImpl(InstrumentingAgents* agents, Element* paramElement, const AtomicString& name, const AtomicString& value)
{
    if (InspectorDOMAgent* agent = agents->inspectorDOMAgent())
        agent->didModifyDOMAttr(paramElement, name, value);
}

void didRemoveDOMAttrImpl(InstrumentingAgents* agents, Element* paramElement, const AtomicString& name)
{
    if (InspectorDOMAgent* agent = agents->inspectorDOMAgent())
        agent->didRemoveDOMAttr(paramElement, name);
}

void characterDataModifiedImpl(InstrumentingAgents* agents, CharacterData* paramCharacterData)
{
    if (InspectorDOMAgent* agent = agents->inspectorDOMAgent())
        agent->characterDataModified(paramCharacterData);
}

void didInvalidateStyleAttrImpl(InstrumentingAgents* agents, Node* paramNode)
{
    if (InspectorDOMAgent* agent = agents->inspectorDOMAgent())
        agent->didInvalidateStyleAttr(paramNode);
    if (InspectorDOMDebuggerAgent* agent = agents->inspectorDOMDebuggerAgent())
        agent->didInvalidateStyleAttr(paramNode);
}

void activeStyleSheetsUpdatedImpl(InstrumentingAgents* agents, Document* paramDocument, const Vector<RefPtr<StyleSheet> >& newSheets)
{
    if (InspectorCSSAgent* agent = agents->inspectorCSSAgent())
        agent->activeStyleSheetsUpdated(paramDocument, newSheets);
}

void frameWindowDiscardedImpl(InstrumentingAgents* agents, DOMWindow* domWindow)
{
    if (InspectorConsoleAgent* agent = agents->inspectorConsoleAgent())
        agent->frameWindowDiscarded(domWindow);
}

void mediaQueryResultChangedImpl(InstrumentingAgents* agents)
{
    if (InspectorCSSAgent* agent = agents->inspectorCSSAgent())
        agent->mediaQueryResultChanged();
}

void didPushShadowRootImpl(InstrumentingAgents* agents, Element* host, ShadowRoot* paramShadowRoot)
{
    if (InspectorDOMAgent* agent = agents->inspectorDOMAgent())
        agent->didPushShadowRoot(host, paramShadowRoot);
}

void willPopShadowRootImpl(InstrumentingAgents* agents, Element* host, ShadowRoot* paramShadowRoot)
{
    if (InspectorDOMAgent* agent = agents->inspectorDOMAgent())
        agent->willPopShadowRoot(host, paramShadowRoot);
}

void didCreateNamedFlowImpl(InstrumentingAgents* agents, Document* paramDocument, NamedFlow* paramNamedFlow)
{
    if (InspectorCSSAgent* agent = agents->inspectorCSSAgent())
        agent->didCreateNamedFlow(paramDocument, paramNamedFlow);
}

void willRemoveNamedFlowImpl(InstrumentingAgents* agents, Document* paramDocument, NamedFlow* paramNamedFlow)
{
    if (InspectorCSSAgent* agent = agents->inspectorCSSAgent())
        agent->willRemoveNamedFlow(paramDocument, paramNamedFlow);
}

void didUpdateRegionLayoutImpl(InstrumentingAgents* agents, Document* paramDocument, NamedFlow* paramNamedFlow)
{
    if (InspectorCSSAgent* agent = agents->inspectorCSSAgent())
        agent->didUpdateRegionLayout(paramDocument, paramNamedFlow);
}

void didChangeRegionOversetImpl(InstrumentingAgents* agents, Document* paramDocument, NamedFlow* paramNamedFlow)
{
    if (InspectorCSSAgent* agent = agents->inspectorCSSAgent())
        agent->didChangeRegionOverset(paramDocument, paramNamedFlow);
}

void willSendXMLHttpRequestImpl(InstrumentingAgents* agents, const String& url)
{
    if (InspectorDOMDebuggerAgent* agent = agents->inspectorDOMDebuggerAgent())
        agent->willSendXMLHttpRequest(url);
}

void didFireWebGLErrorImpl(InstrumentingAgents* agents, const String& errorName)
{
    if (InspectorDOMDebuggerAgent* agent = agents->inspectorDOMDebuggerAgent())
        agent->didFireWebGLError(errorName);
}

void didFireWebGLWarningImpl(InstrumentingAgents* agents)
{
    if (InspectorDOMDebuggerAgent* agent = agents->inspectorDOMDebuggerAgent())
        agent->didFireWebGLWarning();
}

void didFireWebGLErrorOrWarningImpl(InstrumentingAgents* agents, const String& message)
{
    if (InspectorDOMDebuggerAgent* agent = agents->inspectorDOMDebuggerAgent())
        agent->didFireWebGLErrorOrWarning(message);
}

void didScheduleResourceRequestImpl(InstrumentingAgents* agents, Document* paramDocument, const String& url)
{
    if (InspectorTimelineAgent* agent = agents->inspectorTimelineAgent())
        agent->didScheduleResourceRequest(paramDocument, url);
}

void didInstallTimerImpl(InstrumentingAgents* agents, ScriptExecutionContext* paramScriptExecutionContext, int timerId, int timeout, bool singleShot)
{
    if (InspectorDOMDebuggerAgent* agent = agents->inspectorDOMDebuggerAgent())
        agent->didInstallTimer(paramScriptExecutionContext, timerId, timeout, singleShot);
    if (InspectorTimelineAgent* agent = agents->inspectorTimelineAgent())
        agent->didInstallTimer(paramScriptExecutionContext, timerId, timeout, singleShot);
}

void didRemoveTimerImpl(InstrumentingAgents* agents, ScriptExecutionContext* paramScriptExecutionContext, int timerId)
{
    if (InspectorDOMDebuggerAgent* agent = agents->inspectorDOMDebuggerAgent())
        agent->didRemoveTimer(paramScriptExecutionContext, timerId);
    if (InspectorTimelineAgent* agent = agents->inspectorTimelineAgent())
        agent->didRemoveTimer(paramScriptExecutionContext, timerId);
}

InspectorInstrumentationCookie willCallFunctionImpl(InstrumentingAgents* agents, ScriptExecutionContext* paramScriptExecutionContext, const String& scriptName, int scriptLine)
{
    int timelineAgentId = 0;
    if (InspectorTimelineAgent* agent = agents->inspectorTimelineAgent()) {
        if (agent->willCallFunction(paramScriptExecutionContext, scriptName, scriptLine))
            timelineAgentId = agent->id();
    }
    return InspectorInstrumentationCookie(agents, timelineAgentId);
}

void didCallFunctionImpl(const InspectorInstrumentationCookie& paramInspectorInstrumentationCookie)
{
    if (InspectorTimelineAgent* agent = retrieveTimelineAgent(paramInspectorInstrumentationCookie))
        agent->didCallFunction();
}

InspectorInstrumentationCookie willDispatchXHRReadyStateChangeEventImpl(InstrumentingAgents* agents, ScriptExecutionContext* paramScriptExecutionContext, XMLHttpRequest* paramXMLHttpRequest)
{
    int timelineAgentId = 0;
    if (InspectorTimelineAgent* agent = agents->inspectorTimelineAgent()) {
        if (agent->willDispatchXHRReadyStateChangeEvent(paramScriptExecutionContext, paramXMLHttpRequest))
            timelineAgentId = agent->id();
    }
    return InspectorInstrumentationCookie(agents, timelineAgentId);
}

void didDispatchXHRReadyStateChangeEventImpl(const InspectorInstrumentationCookie& paramInspectorInstrumentationCookie)
{
    if (InspectorTimelineAgent* agent = retrieveTimelineAgent(paramInspectorInstrumentationCookie))
        agent->didDispatchXHRReadyStateChangeEvent();
}

InspectorInstrumentationCookie willDispatchEventImpl(InstrumentingAgents* agents, Document* paramDocument, const Event& paramEvent, DOMWindow* paramDOMWindow, Node* paramNode, const EventPath& paramEventPath)
{
    int timelineAgentId = 0;
    if (InspectorTimelineAgent* agent = agents->inspectorTimelineAgent()) {
        if (agent->willDispatchEvent(paramDocument, paramEvent, paramDOMWindow, paramNode, paramEventPath))
            timelineAgentId = agent->id();
    }
    return InspectorInstrumentationCookie(agents, timelineAgentId);
}

void didDispatchEventImpl(const InspectorInstrumentationCookie& paramInspectorInstrumentationCookie)
{
    if (InspectorTimelineAgent* agent = retrieveTimelineAgent(paramInspectorInstrumentationCookie))
        agent->didDispatchEvent();
}

InspectorInstrumentationCookie willHandleEventImpl(InstrumentingAgents* agents, Event* paramEvent)
{
    if (InspectorDOMDebuggerAgent* agent = agents->inspectorDOMDebuggerAgent())
        agent->willHandleEvent(paramEvent);
    return InspectorInstrumentationCookie(agents, 0);
}

void didHandleEventImpl(const InspectorInstrumentationCookie& paramInspectorInstrumentationCookie)
{
    if (InspectorDebuggerAgent* agent = paramInspectorInstrumentationCookie.instrumentingAgents()->inspectorDebuggerAgent())
        agent->didHandleEvent();
}

InspectorInstrumentationCookie willDispatchEventOnWindowImpl(InstrumentingAgents* agents, const Event& paramEvent, DOMWindow* paramDOMWindow)
{
    int timelineAgentId = 0;
    if (InspectorTimelineAgent* agent = agents->inspectorTimelineAgent()) {
        if (agent->willDispatchEventOnWindow(paramEvent, paramDOMWindow))
            timelineAgentId = agent->id();
    }
    return InspectorInstrumentationCookie(agents, timelineAgentId);
}

void didDispatchEventOnWindowImpl(const InspectorInstrumentationCookie& paramInspectorInstrumentationCookie)
{
    if (InspectorTimelineAgent* agent = retrieveTimelineAgent(paramInspectorInstrumentationCookie))
        agent->didDispatchEventOnWindow();
}

InspectorInstrumentationCookie willEvaluateScriptImpl(InstrumentingAgents* agents, Frame* paramFrame, const String& url, int lineNumber)
{
    int timelineAgentId = 0;
    if (InspectorTimelineAgent* agent = agents->inspectorTimelineAgent()) {
        if (agent->willEvaluateScript(paramFrame, url, lineNumber))
            timelineAgentId = agent->id();
    }
    return InspectorInstrumentationCookie(agents, timelineAgentId);
}

void didEvaluateScriptImpl(const InspectorInstrumentationCookie& paramInspectorInstrumentationCookie)
{
    if (InspectorTimelineAgent* agent = retrieveTimelineAgent(paramInspectorInstrumentationCookie))
        agent->didEvaluateScript();
}

void scriptsEnabledImpl(InstrumentingAgents* agents, bool isEnabled)
{
    if (InspectorPageAgent* agent = agents->inspectorPageAgent())
        agent->scriptsEnabled(isEnabled);
}

void didCreateIsolatedContextImpl(InstrumentingAgents* agents, Frame* paramFrame, ScriptState* paramScriptState, SecurityOrigin* paramSecurityOrigin)
{
    if (PageRuntimeAgent* agent = agents->pageRuntimeAgent())
        agent->didCreateIsolatedContext(paramFrame, paramScriptState, paramSecurityOrigin);
}

InspectorInstrumentationCookie willFireTimerImpl(InstrumentingAgents* agents, ScriptExecutionContext* paramScriptExecutionContext, int timerId)
{
    if (InspectorDOMDebuggerAgent* agent = agents->inspectorDOMDebuggerAgent())
        agent->willFireTimer(paramScriptExecutionContext, timerId);
    int timelineAgentId = 0;
    if (InspectorTimelineAgent* agent = agents->inspectorTimelineAgent()) {
        if (agent->willFireTimer(paramScriptExecutionContext, timerId))
            timelineAgentId = agent->id();
    }
    return InspectorInstrumentationCookie(agents, timelineAgentId);
}

void didFireTimerImpl(const InspectorInstrumentationCookie& paramInspectorInstrumentationCookie)
{
    if (InspectorDebuggerAgent* agent = paramInspectorInstrumentationCookie.instrumentingAgents()->inspectorDebuggerAgent())
        agent->didFireTimer();
    if (InspectorTimelineAgent* agent = retrieveTimelineAgent(paramInspectorInstrumentationCookie))
        agent->didFireTimer();
}

void didInvalidateLayoutImpl(InstrumentingAgents* agents, Frame* paramFrame)
{
    if (InspectorTimelineAgent* agent = agents->inspectorTimelineAgent())
        agent->didInvalidateLayout(paramFrame);
}

InspectorInstrumentationCookie willLayoutImpl(InstrumentingAgents* agents, Frame* paramFrame)
{
    int timelineAgentId = 0;
    if (InspectorTimelineAgent* agent = agents->inspectorTimelineAgent()) {
        if (agent->willLayout(paramFrame))
            timelineAgentId = agent->id();
    }
    return InspectorInstrumentationCookie(agents, timelineAgentId);
}

void didLayoutImpl(const InspectorInstrumentationCookie& paramInspectorInstrumentationCookie, RenderObject* root)
{
    if (InspectorTimelineAgent* agent = retrieveTimelineAgent(paramInspectorInstrumentationCookie))
        agent->didLayout(root);
    if (InspectorPageAgent* agent = paramInspectorInstrumentationCookie.instrumentingAgents()->inspectorPageAgent())
        agent->didLayout(root);
}

void didScrollImpl(InstrumentingAgents* agents)
{
    if (InspectorPageAgent* agent = agents->inspectorPageAgent())
        agent->didScroll();
}

void didResizeMainFrameImpl(InstrumentingAgents* agents)
{
    if (InspectorPageAgent* agent = agents->inspectorPageAgent())
        agent->didResizeMainFrame();
}

InspectorInstrumentationCookie willDispatchXHRLoadEventImpl(InstrumentingAgents* agents, ScriptExecutionContext* paramScriptExecutionContext, XMLHttpRequest* paramXMLHttpRequest)
{
    int timelineAgentId = 0;
    if (InspectorTimelineAgent* agent = agents->inspectorTimelineAgent()) {
        if (agent->willDispatchXHRLoadEvent(paramScriptExecutionContext, paramXMLHttpRequest))
            timelineAgentId = agent->id();
    }
    return InspectorInstrumentationCookie(agents, timelineAgentId);
}

void didDispatchXHRLoadEventImpl(const InspectorInstrumentationCookie& paramInspectorInstrumentationCookie)
{
    if (InspectorTimelineAgent* agent = retrieveTimelineAgent(paramInspectorInstrumentationCookie))
        agent->didDispatchXHRLoadEvent();
}

void willScrollLayerImpl(InstrumentingAgents* agents, RenderObject* paramRenderObject)
{
    if (InspectorTimelineAgent* agent = agents->inspectorTimelineAgent())
        agent->willScrollLayer(paramRenderObject);
}

void didScrollLayerImpl(InstrumentingAgents* agents)
{
    if (InspectorTimelineAgent* agent = agents->inspectorTimelineAgent())
        agent->didScrollLayer();
}

void willPaintImpl(InstrumentingAgents* agents, RenderObject* paramRenderObject)
{
    if (InspectorTimelineAgent* agent = agents->inspectorTimelineAgent())
        agent->willPaint(paramRenderObject);
}

void didPaintImpl(InstrumentingAgents* agents, RenderObject* paramRenderObject, GraphicsContext* paramGraphicsContext, const LayoutRect& paramLayoutRect)
{
    if (InspectorTimelineAgent* agent = agents->inspectorTimelineAgent())
        agent->didPaint(paramRenderObject, paramGraphicsContext, paramLayoutRect);
    if (InspectorPageAgent* agent = agents->inspectorPageAgent())
        agent->didPaint(paramRenderObject, paramGraphicsContext, paramLayoutRect);
}

InspectorInstrumentationCookie willRecalculateStyleImpl(InstrumentingAgents* agents, Document* paramDocument)
{
    if (InspectorResourceAgent* agent = agents->inspectorResourceAgent())
        agent->willRecalculateStyle(paramDocument);
    int timelineAgentId = 0;
    if (InspectorTimelineAgent* agent = agents->inspectorTimelineAgent()) {
        if (agent->willRecalculateStyle(paramDocument))
            timelineAgentId = agent->id();
    }
    return InspectorInstrumentationCookie(agents, timelineAgentId);
}

void didRecalculateStyleImpl(const InspectorInstrumentationCookie& paramInspectorInstrumentationCookie)
{
    if (InspectorTimelineAgent* agent = retrieveTimelineAgent(paramInspectorInstrumentationCookie))
        agent->didRecalculateStyle();
    if (InspectorResourceAgent* agent = paramInspectorInstrumentationCookie.instrumentingAgents()->inspectorResourceAgent())
        agent->didRecalculateStyle();
    if (InspectorPageAgent* agent = paramInspectorInstrumentationCookie.instrumentingAgents()->inspectorPageAgent())
        agent->didRecalculateStyle();
}

void didRecalculateStyleForElementImpl(InstrumentingAgents* agents)
{
    if (InspectorTimelineAgent* agent = agents->inspectorTimelineAgent())
        agent->didRecalculateStyleForElement();
}

void didScheduleStyleRecalculationImpl(InstrumentingAgents* agents, Document* paramDocument)
{
    if (InspectorTimelineAgent* agent = agents->inspectorTimelineAgent())
        agent->didScheduleStyleRecalculation(paramDocument);
    if (InspectorResourceAgent* agent = agents->inspectorResourceAgent())
        agent->didScheduleStyleRecalculation(paramDocument);
}

void applyUserAgentOverrideImpl(InstrumentingAgents* agents, String* userAgent)
{
    if (InspectorResourceAgent* agent = agents->inspectorResourceAgent())
        agent->applyUserAgentOverride(userAgent);
}

void applyScreenWidthOverrideImpl(InstrumentingAgents* agents, long* width)
{
    if (InspectorPageAgent* agent = agents->inspectorPageAgent())
        agent->applyScreenWidthOverride(width);
}

void applyScreenHeightOverrideImpl(InstrumentingAgents* agents, long* height)
{
    if (InspectorPageAgent* agent = agents->inspectorPageAgent())
        agent->applyScreenHeightOverride(height);
}

void applyEmulatedMediaImpl(InstrumentingAgents* agents, String* media)
{
    if (InspectorPageAgent* agent = agents->inspectorPageAgent())
        agent->applyEmulatedMedia(media);
}

void willSendRequestImpl(InstrumentingAgents* agents, unsigned long identifier, DocumentLoader* paramDocumentLoader, ResourceRequest& paramResourceRequest, const ResourceResponse& redirectResponse, const FetchInitiatorInfo& paramFetchInitiatorInfo)
{
    if (InspectorTimelineAgent* agent = agents->inspectorTimelineAgent())
        agent->willSendRequest(identifier, paramDocumentLoader, paramResourceRequest, redirectResponse, paramFetchInitiatorInfo);
    if (InspectorResourceAgent* agent = agents->inspectorResourceAgent())
        agent->willSendRequest(identifier, paramDocumentLoader, paramResourceRequest, redirectResponse, paramFetchInitiatorInfo);
}

void markResourceAsCachedImpl(InstrumentingAgents* agents, unsigned long identifier)
{
    if (InspectorResourceAgent* agent = agents->inspectorResourceAgent())
        agent->markResourceAsCached(identifier);
}

InspectorInstrumentationCookie willReceiveResourceDataImpl(InstrumentingAgents* agents, Frame* paramFrame, unsigned long identifier, int length)
{
    int timelineAgentId = 0;
    if (InspectorTimelineAgent* agent = agents->inspectorTimelineAgent()) {
        if (agent->willReceiveResourceData(paramFrame, identifier, length))
            timelineAgentId = agent->id();
    }
    return InspectorInstrumentationCookie(agents, timelineAgentId);
}

void didReceiveResourceDataImpl(const InspectorInstrumentationCookie& paramInspectorInstrumentationCookie)
{
    if (InspectorTimelineAgent* agent = retrieveTimelineAgent(paramInspectorInstrumentationCookie))
        agent->didReceiveResourceData();
}

InspectorInstrumentationCookie willReceiveResourceResponseImpl(InstrumentingAgents* agents, Frame* paramFrame, unsigned long identifier, const ResourceResponse& paramResourceResponse)
{
    int timelineAgentId = 0;
    if (InspectorTimelineAgent* agent = agents->inspectorTimelineAgent()) {
        if (agent->willReceiveResourceResponse(paramFrame, identifier, paramResourceResponse))
            timelineAgentId = agent->id();
    }
    return InspectorInstrumentationCookie(agents, timelineAgentId);
}

void didReceiveResourceResponseImpl(const InspectorInstrumentationCookie& paramInspectorInstrumentationCookie, unsigned long identifier, DocumentLoader* paramDocumentLoader, const ResourceResponse& paramResourceResponse, ResourceLoader* paramResourceLoader)
{
    if (InspectorTimelineAgent* agent = retrieveTimelineAgent(paramInspectorInstrumentationCookie))
        agent->didReceiveResourceResponse(identifier, paramDocumentLoader, paramResourceResponse, paramResourceLoader);
    if (InspectorResourceAgent* agent = paramInspectorInstrumentationCookie.instrumentingAgents()->inspectorResourceAgent())
        agent->didReceiveResourceResponse(identifier, paramDocumentLoader, paramResourceResponse, paramResourceLoader);
    if (InspectorConsoleAgent* agent = paramInspectorInstrumentationCookie.instrumentingAgents()->inspectorConsoleAgent())
        agent->didReceiveResourceResponse(identifier, paramDocumentLoader, paramResourceResponse, paramResourceLoader);
}

void didReceiveDataImpl(InstrumentingAgents* agents, unsigned long identifier, const char* data, int dataLength, int encodedDataLength)
{
    if (InspectorResourceAgent* agent = agents->inspectorResourceAgent())
        agent->didReceiveData(identifier, data, dataLength, encodedDataLength);
}

void didFinishLoadingImpl(InstrumentingAgents* agents, unsigned long identifier, DocumentLoader* paramDocumentLoader, double finishTime)
{
    if (InspectorTimelineAgent* agent = agents->inspectorTimelineAgent())
        agent->didFinishLoading(identifier, paramDocumentLoader, finishTime);
    if (InspectorResourceAgent* agent = agents->inspectorResourceAgent())
        agent->didFinishLoading(identifier, paramDocumentLoader, finishTime);
}

void didFailLoadingImpl(InstrumentingAgents* agents, unsigned long identifier, DocumentLoader* paramDocumentLoader, const ResourceError& paramResourceError)
{
    if (InspectorTimelineAgent* agent = agents->inspectorTimelineAgent())
        agent->didFailLoading(identifier, paramDocumentLoader, paramResourceError);
    if (InspectorResourceAgent* agent = agents->inspectorResourceAgent())
        agent->didFailLoading(identifier, paramDocumentLoader, paramResourceError);
    if (InspectorConsoleAgent* agent = agents->inspectorConsoleAgent())
        agent->didFailLoading(identifier, paramDocumentLoader, paramResourceError);
}

void documentThreadableLoaderStartedLoadingForClientImpl(InstrumentingAgents* agents, unsigned long identifier, ThreadableLoaderClient* client)
{
    if (InspectorResourceAgent* agent = agents->inspectorResourceAgent())
        agent->documentThreadableLoaderStartedLoadingForClient(identifier, client);
}

void willLoadXHRImpl(InstrumentingAgents* agents, ThreadableLoaderClient* client, const String& method, const KURL& url, bool async, PassRefPtr<FormData> paramFormData, const HTTPHeaderMap& headers, bool includeCredentials)
{
    if (InspectorResourceAgent* agent = agents->inspectorResourceAgent())
        agent->willLoadXHR(client, method, url, async, paramFormData, headers, includeCredentials);
}

void didFailXHRLoadingImpl(InstrumentingAgents* agents, ThreadableLoaderClient* client)
{
    if (InspectorResourceAgent* agent = agents->inspectorResourceAgent())
        agent->didFailXHRLoading(client);
}

void didFinishXHRLoadingImpl(InstrumentingAgents* agents, ThreadableLoaderClient* client, unsigned long identifier, ScriptString sourceString, const String& url, const String& sendURL, unsigned sendLineNumber)
{
    if (InspectorConsoleAgent* agent = agents->inspectorConsoleAgent())
        agent->didFinishXHRLoading(client, identifier, sourceString, url, sendURL, sendLineNumber);
    if (InspectorResourceAgent* agent = agents->inspectorResourceAgent())
        agent->didFinishXHRLoading(client, identifier, sourceString, url, sendURL, sendLineNumber);
}

void didReceiveXHRResponseImpl(InstrumentingAgents* agents, unsigned long identifier)
{
    if (InspectorResourceAgent* agent = agents->inspectorResourceAgent())
        agent->didReceiveXHRResponse(identifier);
}

void willLoadXHRSynchronouslyImpl(InstrumentingAgents* agents)
{
    if (InspectorResourceAgent* agent = agents->inspectorResourceAgent())
        agent->willLoadXHRSynchronously();
}

void didLoadXHRSynchronouslyImpl(InstrumentingAgents* agents)
{
    if (InspectorResourceAgent* agent = agents->inspectorResourceAgent())
        agent->didLoadXHRSynchronously();
}

void scriptImportedImpl(InstrumentingAgents* agents, unsigned long identifier, const String& sourceString)
{
    if (InspectorResourceAgent* agent = agents->inspectorResourceAgent())
        agent->scriptImported(identifier, sourceString);
}

void scriptExecutionBlockedByCSPImpl(InstrumentingAgents* agents, const String& directiveText)
{
    if (InspectorDebuggerAgent* agent = agents->inspectorDebuggerAgent())
        agent->scriptExecutionBlockedByCSP(directiveText);
}

void didReceiveScriptResponseImpl(InstrumentingAgents* agents, unsigned long identifier)
{
    if (InspectorResourceAgent* agent = agents->inspectorResourceAgent())
        agent->didReceiveScriptResponse(identifier);
}

void domContentLoadedEventFiredImpl(InstrumentingAgents* agents, Frame* paramFrame)
{
    if (InspectorTimelineAgent* agent = agents->inspectorTimelineAgent())
        agent->domContentLoadedEventFired(paramFrame);
    if (InspectorAgent* agent = agents->inspectorAgent())
        agent->domContentLoadedEventFired(paramFrame);
    if (InspectorDOMAgent* agent = agents->inspectorDOMAgent())
        agent->domContentLoadedEventFired(paramFrame);
    if (InspectorPageAgent* agent = agents->inspectorPageAgent())
        agent->domContentLoadedEventFired(paramFrame);
}

void loadEventFiredImpl(InstrumentingAgents* agents, Frame* paramFrame)
{
    if (InspectorDOMAgent* agent = agents->inspectorDOMAgent())
        agent->loadEventFired(paramFrame);
    if (InspectorTimelineAgent* agent = agents->inspectorTimelineAgent())
        agent->loadEventFired(paramFrame);
    if (InspectorPageAgent* agent = agents->inspectorPageAgent())
        agent->loadEventFired(paramFrame);
}

void frameDetachedFromParentImpl(InstrumentingAgents* agents, Frame* paramFrame)
{
    if (InspectorCanvasAgent* agent = agents->inspectorCanvasAgent())
        agent->frameDetachedFromParent(paramFrame);
    if (InspectorPageAgent* agent = agents->inspectorPageAgent())
        agent->frameDetachedFromParent(paramFrame);
    if (InspectorCSSAgent* agent = agents->inspectorCSSAgent())
        agent->frameDetachedFromParent(paramFrame);
}

void childDocumentOpenedImpl(InstrumentingAgents* agents, Document* paramDocument)
{
    if (InspectorPageAgent* agent = agents->inspectorPageAgent())
        agent->childDocumentOpened(paramDocument);
}

void didCommitLoadImpl(InstrumentingAgents* agents, Frame* paramFrame, DocumentLoader* paramDocumentLoader)
{
    if (InspectorConsoleAgent* agent = agents->inspectorConsoleAgent())
        agent->didCommitLoad(paramFrame, paramDocumentLoader);
    if (InspectorResourceAgent* agent = agents->inspectorResourceAgent())
        agent->didCommitLoad(paramFrame, paramDocumentLoader);
    if (InspectorCSSAgent* agent = agents->inspectorCSSAgent())
        agent->didCommitLoad(paramFrame, paramDocumentLoader);
    if (InspectorDatabaseAgent* agent = agents->inspectorDatabaseAgent())
        agent->didCommitLoad(paramFrame, paramDocumentLoader);
    if (InspectorDOMAgent* agent = agents->inspectorDOMAgent())
        agent->didCommitLoad(paramFrame, paramDocumentLoader);
    if (InspectorLayerTreeAgent* agent = agents->inspectorLayerTreeAgent())
        agent->didCommitLoad(paramFrame, paramDocumentLoader);
    if (InspectorAgent* agent = agents->inspectorAgent())
        agent->didCommitLoad(paramFrame, paramDocumentLoader);
    if (InspectorCanvasAgent* agent = agents->inspectorCanvasAgent())
        agent->didCommitLoad(paramFrame, paramDocumentLoader);
    if (InspectorPageAgent* agent = agents->inspectorPageAgent())
        agent->didCommitLoad(paramFrame, paramDocumentLoader);
}

void frameDocumentUpdatedImpl(InstrumentingAgents* agents, Frame* paramFrame)
{
    if (InspectorDOMAgent* agent = agents->inspectorDOMAgent())
        agent->frameDocumentUpdated(paramFrame);
}

void loaderDetachedFromFrameImpl(InstrumentingAgents* agents, DocumentLoader* paramDocumentLoader)
{
    if (InspectorPageAgent* agent = agents->inspectorPageAgent())
        agent->loaderDetachedFromFrame(paramDocumentLoader);
}

void frameStartedLoadingImpl(InstrumentingAgents* agents, Frame* paramFrame)
{
    if (InspectorPageAgent* agent = agents->inspectorPageAgent())
        agent->frameStartedLoading(paramFrame);
}

void frameStoppedLoadingImpl(InstrumentingAgents* agents, Frame* paramFrame)
{
    if (InspectorPageAgent* agent = agents->inspectorPageAgent())
        agent->frameStoppedLoading(paramFrame);
}

void frameScheduledNavigationImpl(InstrumentingAgents* agents, Frame* paramFrame, double delay)
{
    if (InspectorPageAgent* agent = agents->inspectorPageAgent())
        agent->frameScheduledNavigation(paramFrame, delay);
}

void frameClearedScheduledNavigationImpl(InstrumentingAgents* agents, Frame* paramFrame)
{
    if (InspectorPageAgent* agent = agents->inspectorPageAgent())
        agent->frameClearedScheduledNavigation(paramFrame);
}

InspectorInstrumentationCookie willRunJavaScriptDialogImpl(InstrumentingAgents* agents, const String& message)
{
    if (InspectorPageAgent* agent = agents->inspectorPageAgent())
        agent->willRunJavaScriptDialog(message);
    return InspectorInstrumentationCookie(agents, 0);
}

void didRunJavaScriptDialogImpl(const InspectorInstrumentationCookie& paramInspectorInstrumentationCookie)
{
    if (InspectorPageAgent* agent = paramInspectorInstrumentationCookie.instrumentingAgents()->inspectorPageAgent())
        agent->didRunJavaScriptDialog();
}

InspectorInstrumentationCookie willWriteHTMLImpl(InstrumentingAgents* agents, Document* paramDocument, unsigned startLine)
{
    int timelineAgentId = 0;
    if (InspectorTimelineAgent* agent = agents->inspectorTimelineAgent()) {
        if (agent->willWriteHTML(paramDocument, startLine))
            timelineAgentId = agent->id();
    }
    return InspectorInstrumentationCookie(agents, timelineAgentId);
}

void didWriteHTMLImpl(const InspectorInstrumentationCookie& paramInspectorInstrumentationCookie, unsigned endLine)
{
    if (InspectorTimelineAgent* agent = retrieveTimelineAgent(paramInspectorInstrumentationCookie))
        agent->didWriteHTML(endLine);
}

void didRequestAnimationFrameImpl(InstrumentingAgents* agents, Document* paramDocument, int callbackId)
{
    if (InspectorDOMDebuggerAgent* agent = agents->inspectorDOMDebuggerAgent())
        agent->didRequestAnimationFrame(paramDocument, callbackId);
    if (InspectorTimelineAgent* agent = agents->inspectorTimelineAgent())
        agent->didRequestAnimationFrame(paramDocument, callbackId);
}

void didCancelAnimationFrameImpl(InstrumentingAgents* agents, Document* paramDocument, int callbackId)
{
    if (InspectorDOMDebuggerAgent* agent = agents->inspectorDOMDebuggerAgent())
        agent->didCancelAnimationFrame(paramDocument, callbackId);
    if (InspectorTimelineAgent* agent = agents->inspectorTimelineAgent())
        agent->didCancelAnimationFrame(paramDocument, callbackId);
}

InspectorInstrumentationCookie willFireAnimationFrameImpl(InstrumentingAgents* agents, Document* paramDocument, int callbackId)
{
    if (InspectorDOMDebuggerAgent* agent = agents->inspectorDOMDebuggerAgent())
        agent->willFireAnimationFrame(paramDocument, callbackId);
    int timelineAgentId = 0;
    if (InspectorTimelineAgent* agent = agents->inspectorTimelineAgent()) {
        if (agent->willFireAnimationFrame(paramDocument, callbackId))
            timelineAgentId = agent->id();
    }
    return InspectorInstrumentationCookie(agents, timelineAgentId);
}

void didFireAnimationFrameImpl(const InspectorInstrumentationCookie& paramInspectorInstrumentationCookie)
{
    if (InspectorTimelineAgent* agent = retrieveTimelineAgent(paramInspectorInstrumentationCookie))
        agent->didFireAnimationFrame();
}

void didDispatchDOMStorageEventImpl(InstrumentingAgents* agents, const String& key, const String& oldValue, const String& newValue, StorageType storageType, SecurityOrigin* securityOrigin)
{
    if (InspectorDOMStorageAgent* agent = agents->inspectorDOMStorageAgent())
        agent->didDispatchDOMStorageEvent(key, oldValue, newValue, storageType, securityOrigin);
}

void didStartWorkerGlobalScopeImpl(InstrumentingAgents* agents, WorkerGlobalScopeProxy* proxy, const KURL& url)
{
    if (InspectorWorkerAgent* agent = agents->inspectorWorkerAgent())
        agent->didStartWorkerGlobalScope(proxy, url);
}

void willEvaluateWorkerScriptImpl(InstrumentingAgents* agents, WorkerGlobalScope* context, int workerThreadStartMode)
{
    if (WorkerRuntimeAgent* agent = agents->workerRuntimeAgent())
        agent->willEvaluateWorkerScript(context, workerThreadStartMode);
}

void workerGlobalScopeTerminatedImpl(InstrumentingAgents* agents, WorkerGlobalScopeProxy* proxy)
{
    if (InspectorWorkerAgent* agent = agents->inspectorWorkerAgent())
        agent->workerGlobalScopeTerminated(proxy);
}

void didCreateWebSocketImpl(InstrumentingAgents* agents, Document* paramDocument, unsigned long identifier, const KURL& requestURL, const String& protocol)
{
    if (InspectorResourceAgent* agent = agents->inspectorResourceAgent())
        agent->didCreateWebSocket(paramDocument, identifier, requestURL, protocol);
    if (InspectorTimelineAgent* agent = agents->inspectorTimelineAgent())
        agent->didCreateWebSocket(paramDocument, identifier, requestURL, protocol);
}

void willSendWebSocketHandshakeRequestImpl(InstrumentingAgents* agents, Document* paramDocument, unsigned long identifier, const WebSocketHandshakeRequest& request)
{
    if (InspectorResourceAgent* agent = agents->inspectorResourceAgent())
        agent->willSendWebSocketHandshakeRequest(paramDocument, identifier, request);
    if (InspectorTimelineAgent* agent = agents->inspectorTimelineAgent())
        agent->willSendWebSocketHandshakeRequest(paramDocument, identifier, request);
}

void didReceiveWebSocketHandshakeResponseImpl(InstrumentingAgents* agents, Document* paramDocument, unsigned long identifier, const WebSocketHandshakeResponse& response)
{
    if (InspectorResourceAgent* agent = agents->inspectorResourceAgent())
        agent->didReceiveWebSocketHandshakeResponse(paramDocument, identifier, response);
    if (InspectorTimelineAgent* agent = agents->inspectorTimelineAgent())
        agent->didReceiveWebSocketHandshakeResponse(paramDocument, identifier, response);
}

void didCloseWebSocketImpl(InstrumentingAgents* agents, Document* paramDocument, unsigned long identifier)
{
    if (InspectorResourceAgent* agent = agents->inspectorResourceAgent())
        agent->didCloseWebSocket(paramDocument, identifier);
    if (InspectorTimelineAgent* agent = agents->inspectorTimelineAgent())
        agent->didCloseWebSocket(paramDocument, identifier);
}

void didReceiveWebSocketFrameImpl(InstrumentingAgents* agents, unsigned long identifier, const WebSocketFrame& frame)
{
    if (InspectorResourceAgent* agent = agents->inspectorResourceAgent())
        agent->didReceiveWebSocketFrame(identifier, frame);
}

void didSendWebSocketFrameImpl(InstrumentingAgents* agents, unsigned long identifier, const WebSocketFrame& frame)
{
    if (InspectorResourceAgent* agent = agents->inspectorResourceAgent())
        agent->didSendWebSocketFrame(identifier, frame);
}

void didReceiveWebSocketFrameErrorImpl(InstrumentingAgents* agents, unsigned long identifier, const String& errorMessage)
{
    if (InspectorResourceAgent* agent = agents->inspectorResourceAgent())
        agent->didReceiveWebSocketFrameError(identifier, errorMessage);
}

void networkStateChangedImpl(InstrumentingAgents* agents)
{
    if (InspectorApplicationCacheAgent* agent = agents->inspectorApplicationCacheAgent())
        agent->networkStateChanged();
}

void updateApplicationCacheStatusImpl(InstrumentingAgents* agents, Frame* paramFrame)
{
    if (InspectorApplicationCacheAgent* agent = agents->inspectorApplicationCacheAgent())
        agent->updateApplicationCacheStatus(paramFrame);
}

void layerTreeDidChangeImpl(InstrumentingAgents* agents)
{
    if (InspectorLayerTreeAgent* agent = agents->inspectorLayerTreeAgent())
        agent->layerTreeDidChange();
}

void addMessageToConsoleImpl(InstrumentingAgents* agents, MessageSource source, MessageType type, MessageLevel level, const String& message, PassRefPtr<ScriptCallStack> callStack, unsigned long requestIdentifier)
{
    if (InspectorConsoleAgent* agent = agents->inspectorConsoleAgent())
        agent->addMessageToConsole(source, type, level, message, callStack, requestIdentifier);
    if (InspectorDebuggerAgent* agent = agents->inspectorDebuggerAgent())
        agent->addMessageToConsole(source, type, level, message, callStack, requestIdentifier);
}

void addMessageToConsoleImpl(InstrumentingAgents* agents, MessageSource source, MessageType type, MessageLevel level, const String& message, ScriptState* state, PassRefPtr<ScriptArguments> arguments, unsigned long requestIdentifier)
{
    if (InspectorConsoleAgent* agent = agents->inspectorConsoleAgent())
        agent->addMessageToConsole(source, type, level, message, state, arguments, requestIdentifier);
    if (InspectorDebuggerAgent* agent = agents->inspectorDebuggerAgent())
        agent->addMessageToConsole(source, type, level, message, state, arguments, requestIdentifier);
}

void addMessageToConsoleImpl(InstrumentingAgents* agents, MessageSource source, MessageType type, MessageLevel level, const String& message, const String& scriptId, unsigned lineNumber, unsigned columnNumber, ScriptState* state, unsigned long requestIdentifier)
{
    if (InspectorConsoleAgent* agent = agents->inspectorConsoleAgent())
        agent->addMessageToConsole(source, type, level, message, scriptId, lineNumber, columnNumber, state, requestIdentifier);
}

void consoleCountImpl(InstrumentingAgents* agents, ScriptState* state, PassRefPtr<ScriptArguments> arguments)
{
    if (InspectorConsoleAgent* agent = agents->inspectorConsoleAgent())
        agent->consoleCount(state, arguments);
}

void startConsoleTimingImpl(InstrumentingAgents* agents, Frame* frame, const String& title)
{
    if (InspectorTimelineAgent* agent = agents->inspectorTimelineAgent())
        agent->startConsoleTiming(frame, title);
    if (InspectorConsoleAgent* agent = agents->inspectorConsoleAgent())
        agent->startConsoleTiming(frame, title);
}

void stopConsoleTimingImpl(InstrumentingAgents* agents, Frame* frame, const String& title, PassRefPtr<ScriptCallStack> stack)
{
    if (InspectorConsoleAgent* agent = agents->inspectorConsoleAgent())
        agent->stopConsoleTiming(frame, title, stack);
    if (InspectorTimelineAgent* agent = agents->inspectorTimelineAgent())
        agent->stopConsoleTiming(frame, title, stack);
}

void consoleTimeStampImpl(InstrumentingAgents* agents, Frame* frame, PassRefPtr<ScriptArguments> arguments)
{
    if (InspectorTimelineAgent* agent = agents->inspectorTimelineAgent())
        agent->consoleTimeStamp(frame, arguments);
}

void addStartProfilingMessageToConsoleImpl(InstrumentingAgents* agents, const String& title, unsigned lineNumber, const String& sourceURL)
{
    if (InspectorProfilerAgent* agent = agents->inspectorProfilerAgent())
        agent->addStartProfilingMessageToConsole(title, lineNumber, sourceURL);
}

void addProfileImpl(InstrumentingAgents* agents, PassRefPtr<ScriptProfile> profile, PassRefPtr<ScriptCallStack> callStack)
{
    if (InspectorProfilerAgent* agent = agents->inspectorProfilerAgent())
        agent->addProfile(profile, callStack);
}

void didOpenDatabaseImpl(InstrumentingAgents* agents, PassRefPtr<Database> database, const String& domain, const String& name, const String& version)
{
    if (InspectorDatabaseAgent* agent = agents->inspectorDatabaseAgent())
        agent->didOpenDatabase(database, domain, name, version);
}

bool forcePseudoStateImpl(InstrumentingAgents* agents, Element* element, CSSSelector::PseudoType pseudoState)
{
    if (InspectorCSSAgent* agent = agents->inspectorCSSAgent())
        return agent->forcePseudoState(element, pseudoState);
    return false;
}

bool shouldApplyScreenWidthOverrideImpl(InstrumentingAgents* agents)
{
    if (InspectorPageAgent* agent = agents->inspectorPageAgent())
        return agent->shouldApplyScreenWidthOverride();
    return false;
}

bool shouldApplyScreenHeightOverrideImpl(InstrumentingAgents* agents)
{
    if (InspectorPageAgent* agent = agents->inspectorPageAgent())
        return agent->shouldApplyScreenHeightOverride();
    return false;
}

bool shouldPauseDedicatedWorkerOnStartImpl(InstrumentingAgents* agents)
{
    if (InspectorWorkerAgent* agent = agents->inspectorWorkerAgent())
        return agent->shouldPauseDedicatedWorkerOnStart();
    return false;
}

GeolocationPosition* overrideGeolocationPositionImpl(InstrumentingAgents* agents, GeolocationPosition* position)
{
    if (InspectorPageAgent* agent = agents->inspectorPageAgent())
        return agent->overrideGeolocationPosition(position);
    return position;
}

DeviceOrientationData* overrideDeviceOrientationImpl(InstrumentingAgents* agents, DeviceOrientationData* deviceOrientation)
{
    if (InspectorPageAgent* agent = agents->inspectorPageAgent())
        return agent->overrideDeviceOrientation(deviceOrientation);
    return deviceOrientation;
}

String getCurrentUserInitiatedProfileNameImpl(InstrumentingAgents* agents, bool incrementProfileNumber)
{
    if (InspectorProfilerAgent* agent = agents->inspectorProfilerAgent())
        return agent->getCurrentUserInitiatedProfileName(incrementProfileNumber);
    return "";
}

ScriptObject wrapCanvas2DRenderingContextForInstrumentationImpl(InstrumentingAgents* agents, const ScriptObject& paramScriptObject)
{
    if (InspectorCanvasAgent* agent = agents->inspectorCanvasAgent())
        return agent->wrapCanvas2DRenderingContextForInstrumentation(paramScriptObject);
    return ScriptObject();
}

ScriptObject wrapWebGLRenderingContextForInstrumentationImpl(InstrumentingAgents* agents, const ScriptObject& paramScriptObject)
{
    if (InspectorCanvasAgent* agent = agents->inspectorCanvasAgent())
        return agent->wrapWebGLRenderingContextForInstrumentation(paramScriptObject);
    return ScriptObject();
}

} // namespace InspectorInstrumentation

} // namespace WebCore

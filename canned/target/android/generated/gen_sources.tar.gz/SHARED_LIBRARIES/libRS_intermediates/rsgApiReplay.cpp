/*
 * Copyright (C) 2011 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/*
 * Copyright (C) 2011 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "rsDevice.h"
#include "rsContext.h"
#include "rsThreadIO.h"
#include "rsgApiStructs.h"
#include "rsgApiFuncDecl.h"

namespace android {
namespace renderscript {

void rsp_ContextSendMessage(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_ContextSendMessage *cmd = static_cast<const RS_CMD_ContextSendMessage *>(vp);
    const uint8_t *baseData = 0;
    if (cmdSizeBytes != sizeof(RS_CMD_ContextSendMessage)) {
        baseData = &((const uint8_t *)vp)[sizeof(*cmd)];
    }
    rsi_ContextSendMessage(con,
           cmd->id,
           (const uint8_t *)&baseData[(intptr_t)cmd->data],
           cmd->data_length);
    size_t totalSize = 0;
    totalSize += cmd->data_length;
    if ((totalSize != 0) && (cmdSizeBytes == sizeof(RS_CMD_ContextSendMessage))) {
        con->mIO.coreSetReturn(NULL, 0);
    }
};

void rsp_AllocationGetSurface(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_AllocationGetSurface *cmd = static_cast<const RS_CMD_AllocationGetSurface *>(vp);
    
    RsNativeWindow ret = rsi_AllocationGetSurface(con,
           cmd->alloc);
    con->mIO.coreSetReturn(&ret, sizeof(ret));
};

void rsp_AllocationSetSurface(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_AllocationSetSurface *cmd = static_cast<const RS_CMD_AllocationSetSurface *>(vp);
    rsi_AllocationSetSurface(con,
           cmd->alloc,
           cmd->sur);
    con->mIO.coreSetReturn(NULL, 0);
};

void rsp_ContextFinish(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_ContextFinish *cmd = static_cast<const RS_CMD_ContextFinish *>(vp);
    rsi_ContextFinish(con);
    con->mIO.coreSetReturn(NULL, 0);
};

void rsp_ContextDump(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_ContextDump *cmd = static_cast<const RS_CMD_ContextDump *>(vp);
    rsi_ContextDump(con,
           cmd->bits);
};

void rsp_ContextSetPriority(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_ContextSetPriority *cmd = static_cast<const RS_CMD_ContextSetPriority *>(vp);
    rsi_ContextSetPriority(con,
           cmd->priority);
};

void rsp_ContextDestroyWorker(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_ContextDestroyWorker *cmd = static_cast<const RS_CMD_ContextDestroyWorker *>(vp);
    rsi_ContextDestroyWorker(con);
    con->mIO.coreSetReturn(NULL, 0);
};

void rsp_AssignName(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_AssignName *cmd = static_cast<const RS_CMD_AssignName *>(vp);
    const uint8_t *baseData = 0;
    if (cmdSizeBytes != sizeof(RS_CMD_AssignName)) {
        baseData = &((const uint8_t *)vp)[sizeof(*cmd)];
    }
    rsi_AssignName(con,
           cmd->obj,
           (const char *)&baseData[(intptr_t)cmd->name],
           cmd->name_length);
    size_t totalSize = 0;
    totalSize += cmd->name_length;
    if ((totalSize != 0) && (cmdSizeBytes == sizeof(RS_CMD_AssignName))) {
        con->mIO.coreSetReturn(NULL, 0);
    }
};

void rsp_ObjDestroy(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_ObjDestroy *cmd = static_cast<const RS_CMD_ObjDestroy *>(vp);
    rsi_ObjDestroy(con,
           cmd->objPtr);
};

void rsp_AllocationCopyToBitmap(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_AllocationCopyToBitmap *cmd = static_cast<const RS_CMD_AllocationCopyToBitmap *>(vp);
    rsi_AllocationCopyToBitmap(con,
           cmd->alloc,
           cmd->data,
           cmd->data_length);
    con->mIO.coreSetReturn(NULL, 0);
};

void rsp_Allocation1DData(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_Allocation1DData *cmd = static_cast<const RS_CMD_Allocation1DData *>(vp);
    const uint8_t *baseData = 0;
    if (cmdSizeBytes != sizeof(RS_CMD_Allocation1DData)) {
        baseData = &((const uint8_t *)vp)[sizeof(*cmd)];
    }
    rsi_Allocation1DData(con,
           cmd->va,
           cmd->xoff,
           cmd->lod,
           cmd->count,
           (const void *)&baseData[(intptr_t)cmd->data],
           cmd->data_length);
    size_t totalSize = 0;
    totalSize += cmd->data_length;
    if ((totalSize != 0) && (cmdSizeBytes == sizeof(RS_CMD_Allocation1DData))) {
        con->mIO.coreSetReturn(NULL, 0);
    }
};

void rsp_Allocation1DElementData(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_Allocation1DElementData *cmd = static_cast<const RS_CMD_Allocation1DElementData *>(vp);
    const uint8_t *baseData = 0;
    if (cmdSizeBytes != sizeof(RS_CMD_Allocation1DElementData)) {
        baseData = &((const uint8_t *)vp)[sizeof(*cmd)];
    }
    rsi_Allocation1DElementData(con,
           cmd->va,
           cmd->x,
           cmd->lod,
           (const void *)&baseData[(intptr_t)cmd->data],
           cmd->data_length,
           cmd->comp_offset);
    size_t totalSize = 0;
    totalSize += cmd->data_length;
    if ((totalSize != 0) && (cmdSizeBytes == sizeof(RS_CMD_Allocation1DElementData))) {
        con->mIO.coreSetReturn(NULL, 0);
    }
};

void rsp_Allocation2DData(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_Allocation2DData *cmd = static_cast<const RS_CMD_Allocation2DData *>(vp);
    const uint8_t *baseData = 0;
    if (cmdSizeBytes != sizeof(RS_CMD_Allocation2DData)) {
        baseData = &((const uint8_t *)vp)[sizeof(*cmd)];
    }
    rsi_Allocation2DData(con,
           cmd->va,
           cmd->xoff,
           cmd->yoff,
           cmd->lod,
           cmd->face,
           cmd->w,
           cmd->h,
           (const void *)&baseData[(intptr_t)cmd->data],
           cmd->data_length,
           cmd->stride);
    size_t totalSize = 0;
    totalSize += cmd->data_length;
    if ((totalSize != 0) && (cmdSizeBytes == sizeof(RS_CMD_Allocation2DData))) {
        con->mIO.coreSetReturn(NULL, 0);
    }
};

void rsp_Allocation3DData(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_Allocation3DData *cmd = static_cast<const RS_CMD_Allocation3DData *>(vp);
    const uint8_t *baseData = 0;
    if (cmdSizeBytes != sizeof(RS_CMD_Allocation3DData)) {
        baseData = &((const uint8_t *)vp)[sizeof(*cmd)];
    }
    rsi_Allocation3DData(con,
           cmd->va,
           cmd->xoff,
           cmd->yoff,
           cmd->zoff,
           cmd->lod,
           cmd->w,
           cmd->h,
           cmd->d,
           (const void *)&baseData[(intptr_t)cmd->data],
           cmd->data_length,
           cmd->stride);
    size_t totalSize = 0;
    totalSize += cmd->data_length;
    if ((totalSize != 0) && (cmdSizeBytes == sizeof(RS_CMD_Allocation3DData))) {
        con->mIO.coreSetReturn(NULL, 0);
    }
};

void rsp_AllocationGenerateMipmaps(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_AllocationGenerateMipmaps *cmd = static_cast<const RS_CMD_AllocationGenerateMipmaps *>(vp);
    rsi_AllocationGenerateMipmaps(con,
           cmd->va);
};

void rsp_AllocationRead(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_AllocationRead *cmd = static_cast<const RS_CMD_AllocationRead *>(vp);
    rsi_AllocationRead(con,
           cmd->va,
           cmd->data,
           cmd->data_length);
    con->mIO.coreSetReturn(NULL, 0);
};

void rsp_Allocation1DRead(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_Allocation1DRead *cmd = static_cast<const RS_CMD_Allocation1DRead *>(vp);
    rsi_Allocation1DRead(con,
           cmd->va,
           cmd->xoff,
           cmd->lod,
           cmd->count,
           cmd->data,
           cmd->data_length);
    con->mIO.coreSetReturn(NULL, 0);
};

void rsp_Allocation2DRead(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_Allocation2DRead *cmd = static_cast<const RS_CMD_Allocation2DRead *>(vp);
    rsi_Allocation2DRead(con,
           cmd->va,
           cmd->xoff,
           cmd->yoff,
           cmd->lod,
           cmd->face,
           cmd->w,
           cmd->h,
           cmd->data,
           cmd->data_length,
           cmd->stride);
    con->mIO.coreSetReturn(NULL, 0);
};

void rsp_AllocationSyncAll(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_AllocationSyncAll *cmd = static_cast<const RS_CMD_AllocationSyncAll *>(vp);
    rsi_AllocationSyncAll(con,
           cmd->va,
           cmd->src);
};

void rsp_AllocationResize1D(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_AllocationResize1D *cmd = static_cast<const RS_CMD_AllocationResize1D *>(vp);
    rsi_AllocationResize1D(con,
           cmd->va,
           cmd->dimX);
};

void rsp_AllocationCopy2DRange(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_AllocationCopy2DRange *cmd = static_cast<const RS_CMD_AllocationCopy2DRange *>(vp);
    rsi_AllocationCopy2DRange(con,
           cmd->dest,
           cmd->destXoff,
           cmd->destYoff,
           cmd->destMip,
           cmd->destFace,
           cmd->width,
           cmd->height,
           cmd->src,
           cmd->srcXoff,
           cmd->srcYoff,
           cmd->srcMip,
           cmd->srcFace);
};

void rsp_AllocationCopy3DRange(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_AllocationCopy3DRange *cmd = static_cast<const RS_CMD_AllocationCopy3DRange *>(vp);
    rsi_AllocationCopy3DRange(con,
           cmd->dest,
           cmd->destXoff,
           cmd->destYoff,
           cmd->destZoff,
           cmd->destMip,
           cmd->width,
           cmd->height,
           cmd->depth,
           cmd->src,
           cmd->srcXoff,
           cmd->srcYoff,
           cmd->srcZoff,
           cmd->srcMip);
};

void rsp_ScriptBindAllocation(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_ScriptBindAllocation *cmd = static_cast<const RS_CMD_ScriptBindAllocation *>(vp);
    rsi_ScriptBindAllocation(con,
           cmd->vtm,
           cmd->va,
           cmd->slot);
};

void rsp_ScriptSetTimeZone(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_ScriptSetTimeZone *cmd = static_cast<const RS_CMD_ScriptSetTimeZone *>(vp);
    const uint8_t *baseData = 0;
    if (cmdSizeBytes != sizeof(RS_CMD_ScriptSetTimeZone)) {
        baseData = &((const uint8_t *)vp)[sizeof(*cmd)];
    }
    rsi_ScriptSetTimeZone(con,
           cmd->s,
           (const char *)&baseData[(intptr_t)cmd->timeZone],
           cmd->timeZone_length);
    size_t totalSize = 0;
    totalSize += cmd->timeZone_length;
    if ((totalSize != 0) && (cmdSizeBytes == sizeof(RS_CMD_ScriptSetTimeZone))) {
        con->mIO.coreSetReturn(NULL, 0);
    }
};

void rsp_ScriptInvoke(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_ScriptInvoke *cmd = static_cast<const RS_CMD_ScriptInvoke *>(vp);
    rsi_ScriptInvoke(con,
           cmd->s,
           cmd->slot);
};

void rsp_ScriptInvokeV(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_ScriptInvokeV *cmd = static_cast<const RS_CMD_ScriptInvokeV *>(vp);
    const uint8_t *baseData = 0;
    if (cmdSizeBytes != sizeof(RS_CMD_ScriptInvokeV)) {
        baseData = &((const uint8_t *)vp)[sizeof(*cmd)];
    }
    rsi_ScriptInvokeV(con,
           cmd->s,
           cmd->slot,
           (const void *)&baseData[(intptr_t)cmd->data],
           cmd->data_length);
    size_t totalSize = 0;
    totalSize += cmd->data_length;
    if ((totalSize != 0) && (cmdSizeBytes == sizeof(RS_CMD_ScriptInvokeV))) {
        con->mIO.coreSetReturn(NULL, 0);
    }
};

void rsp_ScriptForEach(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_ScriptForEach *cmd = static_cast<const RS_CMD_ScriptForEach *>(vp);
    const uint8_t *baseData = 0;
    if (cmdSizeBytes != sizeof(RS_CMD_ScriptForEach)) {
        baseData = &((const uint8_t *)vp)[sizeof(*cmd)];
    }
    rsi_ScriptForEach(con,
           cmd->s,
           cmd->slot,
           cmd->ain,
           cmd->aout,
           (const void *)&baseData[(intptr_t)cmd->usr],
           cmd->usr_length,
           (const RsScriptCall *)&baseData[(intptr_t)cmd->sc],
           cmd->sc_length);
    size_t totalSize = 0;
    totalSize += cmd->usr_length;
    totalSize += cmd->sc_length;
    if ((totalSize != 0) && (cmdSizeBytes == sizeof(RS_CMD_ScriptForEach))) {
        con->mIO.coreSetReturn(NULL, 0);
    }
};

void rsp_ScriptSetVarI(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_ScriptSetVarI *cmd = static_cast<const RS_CMD_ScriptSetVarI *>(vp);
    rsi_ScriptSetVarI(con,
           cmd->s,
           cmd->slot,
           cmd->value);
};

void rsp_ScriptSetVarObj(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_ScriptSetVarObj *cmd = static_cast<const RS_CMD_ScriptSetVarObj *>(vp);
    rsi_ScriptSetVarObj(con,
           cmd->s,
           cmd->slot,
           cmd->value);
};

void rsp_ScriptSetVarJ(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_ScriptSetVarJ *cmd = static_cast<const RS_CMD_ScriptSetVarJ *>(vp);
    rsi_ScriptSetVarJ(con,
           cmd->s,
           cmd->slot,
           cmd->value);
};

void rsp_ScriptSetVarF(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_ScriptSetVarF *cmd = static_cast<const RS_CMD_ScriptSetVarF *>(vp);
    rsi_ScriptSetVarF(con,
           cmd->s,
           cmd->slot,
           cmd->value);
};

void rsp_ScriptSetVarD(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_ScriptSetVarD *cmd = static_cast<const RS_CMD_ScriptSetVarD *>(vp);
    rsi_ScriptSetVarD(con,
           cmd->s,
           cmd->slot,
           cmd->value);
};

void rsp_ScriptSetVarV(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_ScriptSetVarV *cmd = static_cast<const RS_CMD_ScriptSetVarV *>(vp);
    const uint8_t *baseData = 0;
    if (cmdSizeBytes != sizeof(RS_CMD_ScriptSetVarV)) {
        baseData = &((const uint8_t *)vp)[sizeof(*cmd)];
    }
    rsi_ScriptSetVarV(con,
           cmd->s,
           cmd->slot,
           (const void *)&baseData[(intptr_t)cmd->data],
           cmd->data_length);
    size_t totalSize = 0;
    totalSize += cmd->data_length;
    if ((totalSize != 0) && (cmdSizeBytes == sizeof(RS_CMD_ScriptSetVarV))) {
        con->mIO.coreSetReturn(NULL, 0);
    }
};

void rsp_ScriptGetVarV(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_ScriptGetVarV *cmd = static_cast<const RS_CMD_ScriptGetVarV *>(vp);
    rsi_ScriptGetVarV(con,
           cmd->s,
           cmd->slot,
           cmd->data,
           cmd->data_length);
    con->mIO.coreSetReturn(NULL, 0);
};

void rsp_ScriptSetVarVE(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_ScriptSetVarVE *cmd = static_cast<const RS_CMD_ScriptSetVarVE *>(vp);
    const uint8_t *baseData = 0;
    if (cmdSizeBytes != sizeof(RS_CMD_ScriptSetVarVE)) {
        baseData = &((const uint8_t *)vp)[sizeof(*cmd)];
    }
    rsi_ScriptSetVarVE(con,
           cmd->s,
           cmd->slot,
           (const void *)&baseData[(intptr_t)cmd->data],
           cmd->data_length,
           cmd->e,
           (const size_t *)&baseData[(intptr_t)cmd->dims],
           cmd->dims_length);
    size_t totalSize = 0;
    totalSize += cmd->data_length;
    totalSize += cmd->dims_length;
    if ((totalSize != 0) && (cmdSizeBytes == sizeof(RS_CMD_ScriptSetVarVE))) {
        con->mIO.coreSetReturn(NULL, 0);
    }
};

void rsp_ScriptCCreate(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_ScriptCCreate *cmd = static_cast<const RS_CMD_ScriptCCreate *>(vp);
    
    RsScript ret = rsi_ScriptCCreate(con,
           cmd->resName,
           cmd->resName_length,
           cmd->cacheDir,
           cmd->cacheDir_length,
           cmd->text,
           cmd->text_length);
    con->mIO.coreSetReturn(&ret, sizeof(ret));
};

void rsp_ScriptIntrinsicCreate(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_ScriptIntrinsicCreate *cmd = static_cast<const RS_CMD_ScriptIntrinsicCreate *>(vp);
    
    RsScript ret = rsi_ScriptIntrinsicCreate(con,
           cmd->id,
           cmd->eid);
    con->mIO.coreSetReturn(&ret, sizeof(ret));
};

void rsp_ScriptGroupSetOutput(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_ScriptGroupSetOutput *cmd = static_cast<const RS_CMD_ScriptGroupSetOutput *>(vp);
    rsi_ScriptGroupSetOutput(con,
           cmd->group,
           cmd->kernel,
           cmd->alloc);
};

void rsp_ScriptGroupSetInput(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_ScriptGroupSetInput *cmd = static_cast<const RS_CMD_ScriptGroupSetInput *>(vp);
    rsi_ScriptGroupSetInput(con,
           cmd->group,
           cmd->kernel,
           cmd->alloc);
};

void rsp_ScriptGroupExecute(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_ScriptGroupExecute *cmd = static_cast<const RS_CMD_ScriptGroupExecute *>(vp);
    rsi_ScriptGroupExecute(con,
           cmd->group);
};

void rsp_AllocationIoSend(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_AllocationIoSend *cmd = static_cast<const RS_CMD_AllocationIoSend *>(vp);
    rsi_AllocationIoSend(con,
           cmd->alloc);
};

void rsp_AllocationIoReceive(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_AllocationIoReceive *cmd = static_cast<const RS_CMD_AllocationIoReceive *>(vp);
    rsi_AllocationIoReceive(con,
           cmd->alloc);
};

void rsp_ProgramBindConstants(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_ProgramBindConstants *cmd = static_cast<const RS_CMD_ProgramBindConstants *>(vp);
    rsi_ProgramBindConstants(con,
           cmd->vp,
           cmd->slot,
           cmd->constants);
};

void rsp_ProgramBindTexture(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_ProgramBindTexture *cmd = static_cast<const RS_CMD_ProgramBindTexture *>(vp);
    rsi_ProgramBindTexture(con,
           cmd->pf,
           cmd->slot,
           cmd->a);
};

void rsp_ProgramBindSampler(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_ProgramBindSampler *cmd = static_cast<const RS_CMD_ProgramBindSampler *>(vp);
    rsi_ProgramBindSampler(con,
           cmd->pf,
           cmd->slot,
           cmd->s);
};

void rsp_FontCreateFromFile(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_FontCreateFromFile *cmd = static_cast<const RS_CMD_FontCreateFromFile *>(vp);
    
    RsFont ret = rsi_FontCreateFromFile(con,
           cmd->name,
           cmd->name_length,
           cmd->fontSize,
           cmd->dpi);
    con->mIO.coreSetReturn(&ret, sizeof(ret));
};

void rsp_FontCreateFromMemory(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_FontCreateFromMemory *cmd = static_cast<const RS_CMD_FontCreateFromMemory *>(vp);
    
    RsFont ret = rsi_FontCreateFromMemory(con,
           cmd->name,
           cmd->name_length,
           cmd->fontSize,
           cmd->dpi,
           cmd->data,
           cmd->data_length);
    con->mIO.coreSetReturn(&ret, sizeof(ret));
};

void rsp_MeshCreate(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_MeshCreate *cmd = static_cast<const RS_CMD_MeshCreate *>(vp);
    
    RsMesh ret = rsi_MeshCreate(con,
           cmd->vtx,
           cmd->vtx_length,
           cmd->idx,
           cmd->idx_length,
           cmd->primType,
           cmd->primType_length);
    con->mIO.coreSetReturn(&ret, sizeof(ret));
};

void rsp_PathCreate(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_PathCreate *cmd = static_cast<const RS_CMD_PathCreate *>(vp);
    
    RsPath ret = rsi_PathCreate(con,
           cmd->pp,
           cmd->isStatic,
           cmd->vertex,
           cmd->loops,
           cmd->quality);
    con->mIO.coreSetReturn(&ret, sizeof(ret));
};

void rsp_ContextBindProgramStore(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_ContextBindProgramStore *cmd = static_cast<const RS_CMD_ContextBindProgramStore *>(vp);
    rsi_ContextBindProgramStore(con,
           cmd->pgm);
};

void rsp_ContextBindProgramFragment(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_ContextBindProgramFragment *cmd = static_cast<const RS_CMD_ContextBindProgramFragment *>(vp);
    rsi_ContextBindProgramFragment(con,
           cmd->pgm);
};

void rsp_ContextBindProgramVertex(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_ContextBindProgramVertex *cmd = static_cast<const RS_CMD_ContextBindProgramVertex *>(vp);
    rsi_ContextBindProgramVertex(con,
           cmd->pgm);
};

void rsp_ContextBindProgramRaster(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_ContextBindProgramRaster *cmd = static_cast<const RS_CMD_ContextBindProgramRaster *>(vp);
    rsi_ContextBindProgramRaster(con,
           cmd->pgm);
};

void rsp_ContextBindFont(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_ContextBindFont *cmd = static_cast<const RS_CMD_ContextBindFont *>(vp);
    rsi_ContextBindFont(con,
           cmd->pgm);
};

void rsp_ContextSetSurface(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_ContextSetSurface *cmd = static_cast<const RS_CMD_ContextSetSurface *>(vp);
    rsi_ContextSetSurface(con,
           cmd->width,
           cmd->height,
           cmd->sur);
    con->mIO.coreSetReturn(NULL, 0);
};

void rsp_ContextBindRootScript(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_ContextBindRootScript *cmd = static_cast<const RS_CMD_ContextBindRootScript *>(vp);
    rsi_ContextBindRootScript(con,
           cmd->sampler);
};

void rsp_ContextPause(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_ContextPause *cmd = static_cast<const RS_CMD_ContextPause *>(vp);
    rsi_ContextPause(con);
};

void rsp_ContextResume(Context *con, const void *vp, size_t cmdSizeBytes) {
    const RS_CMD_ContextResume *cmd = static_cast<const RS_CMD_ContextResume *>(vp);
    rsi_ContextResume(con);
};

void rspr_ContextDestroy(Context *con, ThreadIO *io) {
    RS_CMD_ContextDestroy cmd;



    rsi_ContextDestroy(con);

    io->coreSetReturn(NULL, 0);
};

void rspr_ContextGetMessage(Context *con, ThreadIO *io) {
    RS_CMD_ContextGetMessage cmd;
    io->coreRead(&cmd.data_length, sizeof(cmd.data_length));
    io->coreRead(&cmd.receiveLen_length, sizeof(cmd.receiveLen_length));
    io->coreRead(&cmd.usrID_length, sizeof(cmd.usrID_length));

    cmd.data = (void *)malloc(cmd.data_length);
    cmd.receiveLen = (size_t *)malloc(cmd.receiveLen_length);
    cmd.usrID = (uint32_t *)malloc(cmd.usrID_length);


    RsMessageToClientType ret =
    rsi_ContextGetMessage(con,
           cmd.data,
           cmd.data_length,
           cmd.receiveLen,
           cmd.receiveLen_length,
           cmd.usrID,
           cmd.usrID_length);
    io->coreSetReturn((void *)cmd.data, cmd.data_length);
    io->coreSetReturn((void *)cmd.receiveLen, cmd.receiveLen_length);
    io->coreSetReturn((void *)cmd.usrID, cmd.usrID_length);

    io->coreSetReturn(&ret, sizeof(ret));
    free((void *)cmd.data);
    free((void *)cmd.receiveLen);
    free((void *)cmd.usrID);
};

void rspr_ContextPeekMessage(Context *con, ThreadIO *io) {
    RS_CMD_ContextPeekMessage cmd;
    io->coreRead(&cmd.receiveLen_length, sizeof(cmd.receiveLen_length));
    io->coreRead(&cmd.usrID_length, sizeof(cmd.usrID_length));

    cmd.receiveLen = (size_t *)malloc(cmd.receiveLen_length);
    cmd.usrID = (uint32_t *)malloc(cmd.usrID_length);


    RsMessageToClientType ret =
    rsi_ContextPeekMessage(con,
           cmd.receiveLen,
           cmd.receiveLen_length,
           cmd.usrID,
           cmd.usrID_length);
    io->coreSetReturn((void *)cmd.receiveLen, cmd.receiveLen_length);
    io->coreSetReturn((void *)cmd.usrID, cmd.usrID_length);

    io->coreSetReturn(&ret, sizeof(ret));
    free((void *)cmd.receiveLen);
    free((void *)cmd.usrID);
};

void rspr_ContextSendMessage(Context *con, ThreadIO *io) {
    RS_CMD_ContextSendMessage cmd;
    io->coreRead(&cmd.id, sizeof(cmd.id));
    io->coreRead(&cmd.data_length, sizeof(cmd.data_length));

    cmd.data = (const uint8_t *)malloc(cmd.data_length);
    if (cmd.data_length) io->coreRead((void *)cmd.data, cmd.data_length);


    rsi_ContextSendMessage(con,
           cmd.id,
           cmd.data,
           cmd.data_length);

    io->coreSetReturn(NULL, 0);
    free((void *)cmd.data);
};

void rspr_ContextInitToClient(Context *con, ThreadIO *io) {
    RS_CMD_ContextInitToClient cmd;



    rsi_ContextInitToClient(con);

    io->coreSetReturn(NULL, 0);
};

void rspr_ContextDeinitToClient(Context *con, ThreadIO *io) {
    RS_CMD_ContextDeinitToClient cmd;



    rsi_ContextDeinitToClient(con);

    io->coreSetReturn(NULL, 0);
};

void rspr_TypeCreate(Context *con, ThreadIO *io) {
    RS_CMD_TypeCreate cmd;
    io->coreRead(&cmd.e, sizeof(cmd.e));
    io->coreRead(&cmd.dimX, sizeof(cmd.dimX));
    io->coreRead(&cmd.dimY, sizeof(cmd.dimY));
    io->coreRead(&cmd.dimZ, sizeof(cmd.dimZ));
    io->coreRead(&cmd.mips, sizeof(cmd.mips));
    io->coreRead(&cmd.faces, sizeof(cmd.faces));
    io->coreRead(&cmd.yuv, sizeof(cmd.yuv));



    RsType ret =
    rsi_TypeCreate(con,
           cmd.e,
           cmd.dimX,
           cmd.dimY,
           cmd.dimZ,
           cmd.mips,
           cmd.faces,
           cmd.yuv);

    io->coreSetReturn(&ret, sizeof(ret));
};

void rspr_AllocationCreateTyped(Context *con, ThreadIO *io) {
    RS_CMD_AllocationCreateTyped cmd;
    io->coreRead(&cmd.vtype, sizeof(cmd.vtype));
    io->coreRead(&cmd.mips, sizeof(cmd.mips));
    io->coreRead(&cmd.usages, sizeof(cmd.usages));
    io->coreRead(&cmd.ptr, sizeof(cmd.ptr));



    RsAllocation ret =
    rsi_AllocationCreateTyped(con,
           cmd.vtype,
           cmd.mips,
           cmd.usages,
           cmd.ptr);

    io->coreSetReturn(&ret, sizeof(ret));
};

void rspr_AllocationCreateFromBitmap(Context *con, ThreadIO *io) {
    RS_CMD_AllocationCreateFromBitmap cmd;
    io->coreRead(&cmd.vtype, sizeof(cmd.vtype));
    io->coreRead(&cmd.mips, sizeof(cmd.mips));
    io->coreRead(&cmd.data_length, sizeof(cmd.data_length));
    io->coreRead(&cmd.usages, sizeof(cmd.usages));

    cmd.data = (const void *)malloc(cmd.data_length);
    if (cmd.data_length) io->coreRead((void *)cmd.data, cmd.data_length);


    RsAllocation ret =
    rsi_AllocationCreateFromBitmap(con,
           cmd.vtype,
           cmd.mips,
           cmd.data,
           cmd.data_length,
           cmd.usages);

    io->coreSetReturn(&ret, sizeof(ret));
    free((void *)cmd.data);
};

void rspr_AllocationCubeCreateFromBitmap(Context *con, ThreadIO *io) {
    RS_CMD_AllocationCubeCreateFromBitmap cmd;
    io->coreRead(&cmd.vtype, sizeof(cmd.vtype));
    io->coreRead(&cmd.mips, sizeof(cmd.mips));
    io->coreRead(&cmd.data_length, sizeof(cmd.data_length));
    io->coreRead(&cmd.usages, sizeof(cmd.usages));

    cmd.data = (const void *)malloc(cmd.data_length);
    if (cmd.data_length) io->coreRead((void *)cmd.data, cmd.data_length);


    RsAllocation ret =
    rsi_AllocationCubeCreateFromBitmap(con,
           cmd.vtype,
           cmd.mips,
           cmd.data,
           cmd.data_length,
           cmd.usages);

    io->coreSetReturn(&ret, sizeof(ret));
    free((void *)cmd.data);
};

void rspr_AllocationGetSurface(Context *con, ThreadIO *io) {
    RS_CMD_AllocationGetSurface cmd;
    io->coreRead(&cmd.alloc, sizeof(cmd.alloc));



    RsNativeWindow ret =
    rsi_AllocationGetSurface(con,
           cmd.alloc);

    io->coreSetReturn(&ret, sizeof(ret));
};

void rspr_AllocationSetSurface(Context *con, ThreadIO *io) {
    RS_CMD_AllocationSetSurface cmd;
    io->coreRead(&cmd.alloc, sizeof(cmd.alloc));
    io->coreRead(&cmd.sur, sizeof(cmd.sur));



    rsi_AllocationSetSurface(con,
           cmd.alloc,
           cmd.sur);

    io->coreSetReturn(NULL, 0);
};

void rspr_ContextFinish(Context *con, ThreadIO *io) {
    RS_CMD_ContextFinish cmd;



    rsi_ContextFinish(con);

    io->coreSetReturn(NULL, 0);
};

void rspr_ContextDump(Context *con, ThreadIO *io) {
    RS_CMD_ContextDump cmd;
    io->coreRead(&cmd.bits, sizeof(cmd.bits));



    rsi_ContextDump(con,
           cmd.bits);

    io->coreSetReturn(NULL, 0);
};

void rspr_ContextSetPriority(Context *con, ThreadIO *io) {
    RS_CMD_ContextSetPriority cmd;
    io->coreRead(&cmd.priority, sizeof(cmd.priority));



    rsi_ContextSetPriority(con,
           cmd.priority);

    io->coreSetReturn(NULL, 0);
};

void rspr_ContextDestroyWorker(Context *con, ThreadIO *io) {
    RS_CMD_ContextDestroyWorker cmd;



    rsi_ContextDestroyWorker(con);

    io->coreSetReturn(NULL, 0);
};

void rspr_AssignName(Context *con, ThreadIO *io) {
    RS_CMD_AssignName cmd;
    io->coreRead(&cmd.obj, sizeof(cmd.obj));
    io->coreRead(&cmd.name_length, sizeof(cmd.name_length));

    cmd.name = (const char *)malloc(cmd.name_length);
    if (cmd.name_length) io->coreRead((void *)cmd.name, cmd.name_length);


    rsi_AssignName(con,
           cmd.obj,
           cmd.name,
           cmd.name_length);

    io->coreSetReturn(NULL, 0);
    free((void *)cmd.name);
};

void rspr_ObjDestroy(Context *con, ThreadIO *io) {
    RS_CMD_ObjDestroy cmd;
    io->coreRead(&cmd.objPtr, sizeof(cmd.objPtr));



    rsi_ObjDestroy(con,
           cmd.objPtr);

    io->coreSetReturn(NULL, 0);
};

void rspr_ElementCreate(Context *con, ThreadIO *io) {
    RS_CMD_ElementCreate cmd;
    io->coreRead(&cmd.mType, sizeof(cmd.mType));
    io->coreRead(&cmd.mKind, sizeof(cmd.mKind));
    io->coreRead(&cmd.mNormalized, sizeof(cmd.mNormalized));
    io->coreRead(&cmd.mVectorSize, sizeof(cmd.mVectorSize));



    RsElement ret =
    rsi_ElementCreate(con,
           cmd.mType,
           cmd.mKind,
           cmd.mNormalized,
           cmd.mVectorSize);

    io->coreSetReturn(&ret, sizeof(ret));
};

void rspr_ElementCreate2(Context *con, ThreadIO *io) {
    RS_CMD_ElementCreate2 cmd;
    io->coreRead(&cmd.elements_length, sizeof(cmd.elements_length));
    io->coreRead(&cmd.names_length_length, sizeof(cmd.names_length_length));
    io->coreRead(&cmd.arraySize_length, sizeof(cmd.arraySize_length));

    cmd.elements = (const RsElement *)malloc(cmd.elements_length);
    if (cmd.elements_length) io->coreRead((void *)cmd.elements, cmd.elements_length);
    cmd.names_length = (const size_t *)malloc(cmd.names_length_length);
    if (cmd.names_length_length) io->coreRead((void *)cmd.names_length, cmd.names_length_length);
    cmd.arraySize = (const uint32_t *)malloc(cmd.arraySize_length);
    if (cmd.arraySize_length) io->coreRead((void *)cmd.arraySize, cmd.arraySize_length);

    for (size_t ct = 0; ct < (cmd.names_length_length / sizeof(cmd.names_length)); ct++) {
        cmd.names = (const char **)malloc(cmd.names_length[ct]);
        io->coreRead(& cmd.names, cmd.names_length[ct]);
    }

    RsElement ret =
    rsi_ElementCreate2(con,
           cmd.elements,
           cmd.elements_length,
           cmd.names,
           cmd.names_length_length,
           cmd.names_length,
           cmd.arraySize,
           cmd.arraySize_length);

    io->coreSetReturn(&ret, sizeof(ret));
    free((void *)cmd.elements);
    free((void *)cmd.names_length);
    free((void *)cmd.arraySize);
    for (size_t ct = 0; ct < (cmd.names_length_length / sizeof(cmd.names_length)); ct++) {
        free((void *)cmd.names);
    }
};

void rspr_AllocationCopyToBitmap(Context *con, ThreadIO *io) {
    RS_CMD_AllocationCopyToBitmap cmd;
    io->coreRead(&cmd.alloc, sizeof(cmd.alloc));
    io->coreRead(&cmd.data_length, sizeof(cmd.data_length));

    cmd.data = (void *)malloc(cmd.data_length);


    rsi_AllocationCopyToBitmap(con,
           cmd.alloc,
           cmd.data,
           cmd.data_length);
    io->coreSetReturn((void *)cmd.data, cmd.data_length);

    io->coreSetReturn(NULL, 0);
    free((void *)cmd.data);
};

void rspr_Allocation1DData(Context *con, ThreadIO *io) {
    RS_CMD_Allocation1DData cmd;
    io->coreRead(&cmd.va, sizeof(cmd.va));
    io->coreRead(&cmd.xoff, sizeof(cmd.xoff));
    io->coreRead(&cmd.lod, sizeof(cmd.lod));
    io->coreRead(&cmd.count, sizeof(cmd.count));
    io->coreRead(&cmd.data_length, sizeof(cmd.data_length));

    cmd.data = (const void *)malloc(cmd.data_length);
    if (cmd.data_length) io->coreRead((void *)cmd.data, cmd.data_length);


    rsi_Allocation1DData(con,
           cmd.va,
           cmd.xoff,
           cmd.lod,
           cmd.count,
           cmd.data,
           cmd.data_length);

    io->coreSetReturn(NULL, 0);
    free((void *)cmd.data);
};

void rspr_Allocation1DElementData(Context *con, ThreadIO *io) {
    RS_CMD_Allocation1DElementData cmd;
    io->coreRead(&cmd.va, sizeof(cmd.va));
    io->coreRead(&cmd.x, sizeof(cmd.x));
    io->coreRead(&cmd.lod, sizeof(cmd.lod));
    io->coreRead(&cmd.data_length, sizeof(cmd.data_length));
    io->coreRead(&cmd.comp_offset, sizeof(cmd.comp_offset));

    cmd.data = (const void *)malloc(cmd.data_length);
    if (cmd.data_length) io->coreRead((void *)cmd.data, cmd.data_length);


    rsi_Allocation1DElementData(con,
           cmd.va,
           cmd.x,
           cmd.lod,
           cmd.data,
           cmd.data_length,
           cmd.comp_offset);

    io->coreSetReturn(NULL, 0);
    free((void *)cmd.data);
};

void rspr_Allocation2DData(Context *con, ThreadIO *io) {
    RS_CMD_Allocation2DData cmd;
    io->coreRead(&cmd.va, sizeof(cmd.va));
    io->coreRead(&cmd.xoff, sizeof(cmd.xoff));
    io->coreRead(&cmd.yoff, sizeof(cmd.yoff));
    io->coreRead(&cmd.lod, sizeof(cmd.lod));
    io->coreRead(&cmd.face, sizeof(cmd.face));
    io->coreRead(&cmd.w, sizeof(cmd.w));
    io->coreRead(&cmd.h, sizeof(cmd.h));
    io->coreRead(&cmd.data_length, sizeof(cmd.data_length));
    io->coreRead(&cmd.stride, sizeof(cmd.stride));

    cmd.data = (const void *)malloc(cmd.data_length);
    if (cmd.data_length) io->coreRead((void *)cmd.data, cmd.data_length);


    rsi_Allocation2DData(con,
           cmd.va,
           cmd.xoff,
           cmd.yoff,
           cmd.lod,
           cmd.face,
           cmd.w,
           cmd.h,
           cmd.data,
           cmd.data_length,
           cmd.stride);

    io->coreSetReturn(NULL, 0);
    free((void *)cmd.data);
};

void rspr_Allocation3DData(Context *con, ThreadIO *io) {
    RS_CMD_Allocation3DData cmd;
    io->coreRead(&cmd.va, sizeof(cmd.va));
    io->coreRead(&cmd.xoff, sizeof(cmd.xoff));
    io->coreRead(&cmd.yoff, sizeof(cmd.yoff));
    io->coreRead(&cmd.zoff, sizeof(cmd.zoff));
    io->coreRead(&cmd.lod, sizeof(cmd.lod));
    io->coreRead(&cmd.w, sizeof(cmd.w));
    io->coreRead(&cmd.h, sizeof(cmd.h));
    io->coreRead(&cmd.d, sizeof(cmd.d));
    io->coreRead(&cmd.data_length, sizeof(cmd.data_length));
    io->coreRead(&cmd.stride, sizeof(cmd.stride));

    cmd.data = (const void *)malloc(cmd.data_length);
    if (cmd.data_length) io->coreRead((void *)cmd.data, cmd.data_length);


    rsi_Allocation3DData(con,
           cmd.va,
           cmd.xoff,
           cmd.yoff,
           cmd.zoff,
           cmd.lod,
           cmd.w,
           cmd.h,
           cmd.d,
           cmd.data,
           cmd.data_length,
           cmd.stride);

    io->coreSetReturn(NULL, 0);
    free((void *)cmd.data);
};

void rspr_AllocationGenerateMipmaps(Context *con, ThreadIO *io) {
    RS_CMD_AllocationGenerateMipmaps cmd;
    io->coreRead(&cmd.va, sizeof(cmd.va));



    rsi_AllocationGenerateMipmaps(con,
           cmd.va);

    io->coreSetReturn(NULL, 0);
};

void rspr_AllocationRead(Context *con, ThreadIO *io) {
    RS_CMD_AllocationRead cmd;
    io->coreRead(&cmd.va, sizeof(cmd.va));
    io->coreRead(&cmd.data_length, sizeof(cmd.data_length));

    cmd.data = (void *)malloc(cmd.data_length);


    rsi_AllocationRead(con,
           cmd.va,
           cmd.data,
           cmd.data_length);
    io->coreSetReturn((void *)cmd.data, cmd.data_length);

    io->coreSetReturn(NULL, 0);
    free((void *)cmd.data);
};

void rspr_Allocation1DRead(Context *con, ThreadIO *io) {
    RS_CMD_Allocation1DRead cmd;
    io->coreRead(&cmd.va, sizeof(cmd.va));
    io->coreRead(&cmd.xoff, sizeof(cmd.xoff));
    io->coreRead(&cmd.lod, sizeof(cmd.lod));
    io->coreRead(&cmd.count, sizeof(cmd.count));
    io->coreRead(&cmd.data_length, sizeof(cmd.data_length));

    cmd.data = (void *)malloc(cmd.data_length);


    rsi_Allocation1DRead(con,
           cmd.va,
           cmd.xoff,
           cmd.lod,
           cmd.count,
           cmd.data,
           cmd.data_length);
    io->coreSetReturn((void *)cmd.data, cmd.data_length);

    io->coreSetReturn(NULL, 0);
    free((void *)cmd.data);
};

void rspr_Allocation2DRead(Context *con, ThreadIO *io) {
    RS_CMD_Allocation2DRead cmd;
    io->coreRead(&cmd.va, sizeof(cmd.va));
    io->coreRead(&cmd.xoff, sizeof(cmd.xoff));
    io->coreRead(&cmd.yoff, sizeof(cmd.yoff));
    io->coreRead(&cmd.lod, sizeof(cmd.lod));
    io->coreRead(&cmd.face, sizeof(cmd.face));
    io->coreRead(&cmd.w, sizeof(cmd.w));
    io->coreRead(&cmd.h, sizeof(cmd.h));
    io->coreRead(&cmd.data_length, sizeof(cmd.data_length));
    io->coreRead(&cmd.stride, sizeof(cmd.stride));

    cmd.data = (void *)malloc(cmd.data_length);


    rsi_Allocation2DRead(con,
           cmd.va,
           cmd.xoff,
           cmd.yoff,
           cmd.lod,
           cmd.face,
           cmd.w,
           cmd.h,
           cmd.data,
           cmd.data_length,
           cmd.stride);
    io->coreSetReturn((void *)cmd.data, cmd.data_length);

    io->coreSetReturn(NULL, 0);
    free((void *)cmd.data);
};

void rspr_AllocationSyncAll(Context *con, ThreadIO *io) {
    RS_CMD_AllocationSyncAll cmd;
    io->coreRead(&cmd.va, sizeof(cmd.va));
    io->coreRead(&cmd.src, sizeof(cmd.src));



    rsi_AllocationSyncAll(con,
           cmd.va,
           cmd.src);

    io->coreSetReturn(NULL, 0);
};

void rspr_AllocationResize1D(Context *con, ThreadIO *io) {
    RS_CMD_AllocationResize1D cmd;
    io->coreRead(&cmd.va, sizeof(cmd.va));
    io->coreRead(&cmd.dimX, sizeof(cmd.dimX));



    rsi_AllocationResize1D(con,
           cmd.va,
           cmd.dimX);

    io->coreSetReturn(NULL, 0);
};

void rspr_AllocationCopy2DRange(Context *con, ThreadIO *io) {
    RS_CMD_AllocationCopy2DRange cmd;
    io->coreRead(&cmd.dest, sizeof(cmd.dest));
    io->coreRead(&cmd.destXoff, sizeof(cmd.destXoff));
    io->coreRead(&cmd.destYoff, sizeof(cmd.destYoff));
    io->coreRead(&cmd.destMip, sizeof(cmd.destMip));
    io->coreRead(&cmd.destFace, sizeof(cmd.destFace));
    io->coreRead(&cmd.width, sizeof(cmd.width));
    io->coreRead(&cmd.height, sizeof(cmd.height));
    io->coreRead(&cmd.src, sizeof(cmd.src));
    io->coreRead(&cmd.srcXoff, sizeof(cmd.srcXoff));
    io->coreRead(&cmd.srcYoff, sizeof(cmd.srcYoff));
    io->coreRead(&cmd.srcMip, sizeof(cmd.srcMip));
    io->coreRead(&cmd.srcFace, sizeof(cmd.srcFace));



    rsi_AllocationCopy2DRange(con,
           cmd.dest,
           cmd.destXoff,
           cmd.destYoff,
           cmd.destMip,
           cmd.destFace,
           cmd.width,
           cmd.height,
           cmd.src,
           cmd.srcXoff,
           cmd.srcYoff,
           cmd.srcMip,
           cmd.srcFace);

    io->coreSetReturn(NULL, 0);
};

void rspr_AllocationCopy3DRange(Context *con, ThreadIO *io) {
    RS_CMD_AllocationCopy3DRange cmd;
    io->coreRead(&cmd.dest, sizeof(cmd.dest));
    io->coreRead(&cmd.destXoff, sizeof(cmd.destXoff));
    io->coreRead(&cmd.destYoff, sizeof(cmd.destYoff));
    io->coreRead(&cmd.destZoff, sizeof(cmd.destZoff));
    io->coreRead(&cmd.destMip, sizeof(cmd.destMip));
    io->coreRead(&cmd.width, sizeof(cmd.width));
    io->coreRead(&cmd.height, sizeof(cmd.height));
    io->coreRead(&cmd.depth, sizeof(cmd.depth));
    io->coreRead(&cmd.src, sizeof(cmd.src));
    io->coreRead(&cmd.srcXoff, sizeof(cmd.srcXoff));
    io->coreRead(&cmd.srcYoff, sizeof(cmd.srcYoff));
    io->coreRead(&cmd.srcZoff, sizeof(cmd.srcZoff));
    io->coreRead(&cmd.srcMip, sizeof(cmd.srcMip));



    rsi_AllocationCopy3DRange(con,
           cmd.dest,
           cmd.destXoff,
           cmd.destYoff,
           cmd.destZoff,
           cmd.destMip,
           cmd.width,
           cmd.height,
           cmd.depth,
           cmd.src,
           cmd.srcXoff,
           cmd.srcYoff,
           cmd.srcZoff,
           cmd.srcMip);

    io->coreSetReturn(NULL, 0);
};

void rspr_SamplerCreate(Context *con, ThreadIO *io) {
    RS_CMD_SamplerCreate cmd;
    io->coreRead(&cmd.magFilter, sizeof(cmd.magFilter));
    io->coreRead(&cmd.minFilter, sizeof(cmd.minFilter));
    io->coreRead(&cmd.wrapS, sizeof(cmd.wrapS));
    io->coreRead(&cmd.wrapT, sizeof(cmd.wrapT));
    io->coreRead(&cmd.wrapR, sizeof(cmd.wrapR));
    io->coreRead(&cmd.mAniso, sizeof(cmd.mAniso));



    RsSampler ret =
    rsi_SamplerCreate(con,
           cmd.magFilter,
           cmd.minFilter,
           cmd.wrapS,
           cmd.wrapT,
           cmd.wrapR,
           cmd.mAniso);

    io->coreSetReturn(&ret, sizeof(ret));
};

void rspr_ScriptBindAllocation(Context *con, ThreadIO *io) {
    RS_CMD_ScriptBindAllocation cmd;
    io->coreRead(&cmd.vtm, sizeof(cmd.vtm));
    io->coreRead(&cmd.va, sizeof(cmd.va));
    io->coreRead(&cmd.slot, sizeof(cmd.slot));



    rsi_ScriptBindAllocation(con,
           cmd.vtm,
           cmd.va,
           cmd.slot);

    io->coreSetReturn(NULL, 0);
};

void rspr_ScriptSetTimeZone(Context *con, ThreadIO *io) {
    RS_CMD_ScriptSetTimeZone cmd;
    io->coreRead(&cmd.s, sizeof(cmd.s));
    io->coreRead(&cmd.timeZone_length, sizeof(cmd.timeZone_length));

    cmd.timeZone = (const char *)malloc(cmd.timeZone_length);
    if (cmd.timeZone_length) io->coreRead((void *)cmd.timeZone, cmd.timeZone_length);


    rsi_ScriptSetTimeZone(con,
           cmd.s,
           cmd.timeZone,
           cmd.timeZone_length);

    io->coreSetReturn(NULL, 0);
    free((void *)cmd.timeZone);
};

void rspr_ScriptInvoke(Context *con, ThreadIO *io) {
    RS_CMD_ScriptInvoke cmd;
    io->coreRead(&cmd.s, sizeof(cmd.s));
    io->coreRead(&cmd.slot, sizeof(cmd.slot));



    rsi_ScriptInvoke(con,
           cmd.s,
           cmd.slot);

    io->coreSetReturn(NULL, 0);
};

void rspr_ScriptInvokeV(Context *con, ThreadIO *io) {
    RS_CMD_ScriptInvokeV cmd;
    io->coreRead(&cmd.s, sizeof(cmd.s));
    io->coreRead(&cmd.slot, sizeof(cmd.slot));
    io->coreRead(&cmd.data_length, sizeof(cmd.data_length));

    cmd.data = (const void *)malloc(cmd.data_length);
    if (cmd.data_length) io->coreRead((void *)cmd.data, cmd.data_length);


    rsi_ScriptInvokeV(con,
           cmd.s,
           cmd.slot,
           cmd.data,
           cmd.data_length);

    io->coreSetReturn(NULL, 0);
    free((void *)cmd.data);
};

void rspr_ScriptForEach(Context *con, ThreadIO *io) {
    RS_CMD_ScriptForEach cmd;
    io->coreRead(&cmd.s, sizeof(cmd.s));
    io->coreRead(&cmd.slot, sizeof(cmd.slot));
    io->coreRead(&cmd.ain, sizeof(cmd.ain));
    io->coreRead(&cmd.aout, sizeof(cmd.aout));
    io->coreRead(&cmd.usr_length, sizeof(cmd.usr_length));
    io->coreRead(&cmd.sc_length, sizeof(cmd.sc_length));

    cmd.usr = (const void *)malloc(cmd.usr_length);
    if (cmd.usr_length) io->coreRead((void *)cmd.usr, cmd.usr_length);
    cmd.sc = (const RsScriptCall *)malloc(cmd.sc_length);
    if (cmd.sc_length) io->coreRead((void *)cmd.sc, cmd.sc_length);


    rsi_ScriptForEach(con,
           cmd.s,
           cmd.slot,
           cmd.ain,
           cmd.aout,
           cmd.usr,
           cmd.usr_length,
           cmd.sc,
           cmd.sc_length);

    io->coreSetReturn(NULL, 0);
    free((void *)cmd.usr);
    free((void *)cmd.sc);
};

void rspr_ScriptSetVarI(Context *con, ThreadIO *io) {
    RS_CMD_ScriptSetVarI cmd;
    io->coreRead(&cmd.s, sizeof(cmd.s));
    io->coreRead(&cmd.slot, sizeof(cmd.slot));
    io->coreRead(&cmd.value, sizeof(cmd.value));



    rsi_ScriptSetVarI(con,
           cmd.s,
           cmd.slot,
           cmd.value);

    io->coreSetReturn(NULL, 0);
};

void rspr_ScriptSetVarObj(Context *con, ThreadIO *io) {
    RS_CMD_ScriptSetVarObj cmd;
    io->coreRead(&cmd.s, sizeof(cmd.s));
    io->coreRead(&cmd.slot, sizeof(cmd.slot));
    io->coreRead(&cmd.value, sizeof(cmd.value));



    rsi_ScriptSetVarObj(con,
           cmd.s,
           cmd.slot,
           cmd.value);

    io->coreSetReturn(NULL, 0);
};

void rspr_ScriptSetVarJ(Context *con, ThreadIO *io) {
    RS_CMD_ScriptSetVarJ cmd;
    io->coreRead(&cmd.s, sizeof(cmd.s));
    io->coreRead(&cmd.slot, sizeof(cmd.slot));
    io->coreRead(&cmd.value, sizeof(cmd.value));



    rsi_ScriptSetVarJ(con,
           cmd.s,
           cmd.slot,
           cmd.value);

    io->coreSetReturn(NULL, 0);
};

void rspr_ScriptSetVarF(Context *con, ThreadIO *io) {
    RS_CMD_ScriptSetVarF cmd;
    io->coreRead(&cmd.s, sizeof(cmd.s));
    io->coreRead(&cmd.slot, sizeof(cmd.slot));
    io->coreRead(&cmd.value, sizeof(cmd.value));



    rsi_ScriptSetVarF(con,
           cmd.s,
           cmd.slot,
           cmd.value);

    io->coreSetReturn(NULL, 0);
};

void rspr_ScriptSetVarD(Context *con, ThreadIO *io) {
    RS_CMD_ScriptSetVarD cmd;
    io->coreRead(&cmd.s, sizeof(cmd.s));
    io->coreRead(&cmd.slot, sizeof(cmd.slot));
    io->coreRead(&cmd.value, sizeof(cmd.value));



    rsi_ScriptSetVarD(con,
           cmd.s,
           cmd.slot,
           cmd.value);

    io->coreSetReturn(NULL, 0);
};

void rspr_ScriptSetVarV(Context *con, ThreadIO *io) {
    RS_CMD_ScriptSetVarV cmd;
    io->coreRead(&cmd.s, sizeof(cmd.s));
    io->coreRead(&cmd.slot, sizeof(cmd.slot));
    io->coreRead(&cmd.data_length, sizeof(cmd.data_length));

    cmd.data = (const void *)malloc(cmd.data_length);
    if (cmd.data_length) io->coreRead((void *)cmd.data, cmd.data_length);


    rsi_ScriptSetVarV(con,
           cmd.s,
           cmd.slot,
           cmd.data,
           cmd.data_length);

    io->coreSetReturn(NULL, 0);
    free((void *)cmd.data);
};

void rspr_ScriptGetVarV(Context *con, ThreadIO *io) {
    RS_CMD_ScriptGetVarV cmd;
    io->coreRead(&cmd.s, sizeof(cmd.s));
    io->coreRead(&cmd.slot, sizeof(cmd.slot));
    io->coreRead(&cmd.data_length, sizeof(cmd.data_length));

    cmd.data = (void *)malloc(cmd.data_length);


    rsi_ScriptGetVarV(con,
           cmd.s,
           cmd.slot,
           cmd.data,
           cmd.data_length);
    io->coreSetReturn((void *)cmd.data, cmd.data_length);

    io->coreSetReturn(NULL, 0);
    free((void *)cmd.data);
};

void rspr_ScriptSetVarVE(Context *con, ThreadIO *io) {
    RS_CMD_ScriptSetVarVE cmd;
    io->coreRead(&cmd.s, sizeof(cmd.s));
    io->coreRead(&cmd.slot, sizeof(cmd.slot));
    io->coreRead(&cmd.data_length, sizeof(cmd.data_length));
    io->coreRead(&cmd.e, sizeof(cmd.e));
    io->coreRead(&cmd.dims_length, sizeof(cmd.dims_length));

    cmd.data = (const void *)malloc(cmd.data_length);
    if (cmd.data_length) io->coreRead((void *)cmd.data, cmd.data_length);
    cmd.dims = (const size_t *)malloc(cmd.dims_length);
    if (cmd.dims_length) io->coreRead((void *)cmd.dims, cmd.dims_length);


    rsi_ScriptSetVarVE(con,
           cmd.s,
           cmd.slot,
           cmd.data,
           cmd.data_length,
           cmd.e,
           cmd.dims,
           cmd.dims_length);

    io->coreSetReturn(NULL, 0);
    free((void *)cmd.data);
    free((void *)cmd.dims);
};

void rspr_ScriptCCreate(Context *con, ThreadIO *io) {
    RS_CMD_ScriptCCreate cmd;
    io->coreRead(&cmd.resName_length, sizeof(cmd.resName_length));
    io->coreRead(&cmd.cacheDir_length, sizeof(cmd.cacheDir_length));
    io->coreRead(&cmd.text_length, sizeof(cmd.text_length));

    cmd.resName = (const char *)malloc(cmd.resName_length);
    if (cmd.resName_length) io->coreRead((void *)cmd.resName, cmd.resName_length);
    cmd.cacheDir = (const char *)malloc(cmd.cacheDir_length);
    if (cmd.cacheDir_length) io->coreRead((void *)cmd.cacheDir, cmd.cacheDir_length);
    cmd.text = (const char *)malloc(cmd.text_length);
    if (cmd.text_length) io->coreRead((void *)cmd.text, cmd.text_length);


    RsScript ret =
    rsi_ScriptCCreate(con,
           cmd.resName,
           cmd.resName_length,
           cmd.cacheDir,
           cmd.cacheDir_length,
           cmd.text,
           cmd.text_length);

    io->coreSetReturn(&ret, sizeof(ret));
    free((void *)cmd.resName);
    free((void *)cmd.cacheDir);
    free((void *)cmd.text);
};

void rspr_ScriptIntrinsicCreate(Context *con, ThreadIO *io) {
    RS_CMD_ScriptIntrinsicCreate cmd;
    io->coreRead(&cmd.id, sizeof(cmd.id));
    io->coreRead(&cmd.eid, sizeof(cmd.eid));



    RsScript ret =
    rsi_ScriptIntrinsicCreate(con,
           cmd.id,
           cmd.eid);

    io->coreSetReturn(&ret, sizeof(ret));
};

void rspr_ScriptKernelIDCreate(Context *con, ThreadIO *io) {
    RS_CMD_ScriptKernelIDCreate cmd;
    io->coreRead(&cmd.sid, sizeof(cmd.sid));
    io->coreRead(&cmd.slot, sizeof(cmd.slot));
    io->coreRead(&cmd.sig, sizeof(cmd.sig));



    RsScriptKernelID ret =
    rsi_ScriptKernelIDCreate(con,
           cmd.sid,
           cmd.slot,
           cmd.sig);

    io->coreSetReturn(&ret, sizeof(ret));
};

void rspr_ScriptFieldIDCreate(Context *con, ThreadIO *io) {
    RS_CMD_ScriptFieldIDCreate cmd;
    io->coreRead(&cmd.sid, sizeof(cmd.sid));
    io->coreRead(&cmd.slot, sizeof(cmd.slot));



    RsScriptFieldID ret =
    rsi_ScriptFieldIDCreate(con,
           cmd.sid,
           cmd.slot);

    io->coreSetReturn(&ret, sizeof(ret));
};

void rspr_ScriptGroupCreate(Context *con, ThreadIO *io) {
    RS_CMD_ScriptGroupCreate cmd;
    io->coreRead(&cmd.kernels_length, sizeof(cmd.kernels_length));
    io->coreRead(&cmd.src_length, sizeof(cmd.src_length));
    io->coreRead(&cmd.dstK_length, sizeof(cmd.dstK_length));
    io->coreRead(&cmd.dstF_length, sizeof(cmd.dstF_length));
    io->coreRead(&cmd.type_length, sizeof(cmd.type_length));

    cmd.kernels = (RsScriptKernelID *)malloc(cmd.kernels_length);
    cmd.src = (RsScriptKernelID *)malloc(cmd.src_length);
    cmd.dstK = (RsScriptKernelID *)malloc(cmd.dstK_length);
    cmd.dstF = (RsScriptFieldID *)malloc(cmd.dstF_length);
    cmd.type = (const RsType *)malloc(cmd.type_length);
    if (cmd.type_length) io->coreRead((void *)cmd.type, cmd.type_length);


    RsScriptGroup ret =
    rsi_ScriptGroupCreate(con,
           cmd.kernels,
           cmd.kernels_length,
           cmd.src,
           cmd.src_length,
           cmd.dstK,
           cmd.dstK_length,
           cmd.dstF,
           cmd.dstF_length,
           cmd.type,
           cmd.type_length);
    io->coreSetReturn((void *)cmd.kernels, cmd.kernels_length);
    io->coreSetReturn((void *)cmd.src, cmd.src_length);
    io->coreSetReturn((void *)cmd.dstK, cmd.dstK_length);
    io->coreSetReturn((void *)cmd.dstF, cmd.dstF_length);

    io->coreSetReturn(&ret, sizeof(ret));
    free((void *)cmd.kernels);
    free((void *)cmd.src);
    free((void *)cmd.dstK);
    free((void *)cmd.dstF);
    free((void *)cmd.type);
};

void rspr_ScriptGroupSetOutput(Context *con, ThreadIO *io) {
    RS_CMD_ScriptGroupSetOutput cmd;
    io->coreRead(&cmd.group, sizeof(cmd.group));
    io->coreRead(&cmd.kernel, sizeof(cmd.kernel));
    io->coreRead(&cmd.alloc, sizeof(cmd.alloc));



    rsi_ScriptGroupSetOutput(con,
           cmd.group,
           cmd.kernel,
           cmd.alloc);

    io->coreSetReturn(NULL, 0);
};

void rspr_ScriptGroupSetInput(Context *con, ThreadIO *io) {
    RS_CMD_ScriptGroupSetInput cmd;
    io->coreRead(&cmd.group, sizeof(cmd.group));
    io->coreRead(&cmd.kernel, sizeof(cmd.kernel));
    io->coreRead(&cmd.alloc, sizeof(cmd.alloc));



    rsi_ScriptGroupSetInput(con,
           cmd.group,
           cmd.kernel,
           cmd.alloc);

    io->coreSetReturn(NULL, 0);
};

void rspr_ScriptGroupExecute(Context *con, ThreadIO *io) {
    RS_CMD_ScriptGroupExecute cmd;
    io->coreRead(&cmd.group, sizeof(cmd.group));



    rsi_ScriptGroupExecute(con,
           cmd.group);

    io->coreSetReturn(NULL, 0);
};

void rspr_AllocationIoSend(Context *con, ThreadIO *io) {
    RS_CMD_AllocationIoSend cmd;
    io->coreRead(&cmd.alloc, sizeof(cmd.alloc));



    rsi_AllocationIoSend(con,
           cmd.alloc);

    io->coreSetReturn(NULL, 0);
};

void rspr_AllocationIoReceive(Context *con, ThreadIO *io) {
    RS_CMD_AllocationIoReceive cmd;
    io->coreRead(&cmd.alloc, sizeof(cmd.alloc));



    rsi_AllocationIoReceive(con,
           cmd.alloc);

    io->coreSetReturn(NULL, 0);
};

void rspr_ProgramStoreCreate(Context *con, ThreadIO *io) {
    RS_CMD_ProgramStoreCreate cmd;
    io->coreRead(&cmd.colorMaskR, sizeof(cmd.colorMaskR));
    io->coreRead(&cmd.colorMaskG, sizeof(cmd.colorMaskG));
    io->coreRead(&cmd.colorMaskB, sizeof(cmd.colorMaskB));
    io->coreRead(&cmd.colorMaskA, sizeof(cmd.colorMaskA));
    io->coreRead(&cmd.depthMask, sizeof(cmd.depthMask));
    io->coreRead(&cmd.ditherEnable, sizeof(cmd.ditherEnable));
    io->coreRead(&cmd.srcFunc, sizeof(cmd.srcFunc));
    io->coreRead(&cmd.destFunc, sizeof(cmd.destFunc));
    io->coreRead(&cmd.depthFunc, sizeof(cmd.depthFunc));



    RsProgramStore ret =
    rsi_ProgramStoreCreate(con,
           cmd.colorMaskR,
           cmd.colorMaskG,
           cmd.colorMaskB,
           cmd.colorMaskA,
           cmd.depthMask,
           cmd.ditherEnable,
           cmd.srcFunc,
           cmd.destFunc,
           cmd.depthFunc);

    io->coreSetReturn(&ret, sizeof(ret));
};

void rspr_ProgramRasterCreate(Context *con, ThreadIO *io) {
    RS_CMD_ProgramRasterCreate cmd;
    io->coreRead(&cmd.pointSprite, sizeof(cmd.pointSprite));
    io->coreRead(&cmd.cull, sizeof(cmd.cull));



    RsProgramRaster ret =
    rsi_ProgramRasterCreate(con,
           cmd.pointSprite,
           cmd.cull);

    io->coreSetReturn(&ret, sizeof(ret));
};

void rspr_ProgramBindConstants(Context *con, ThreadIO *io) {
    RS_CMD_ProgramBindConstants cmd;
    io->coreRead(&cmd.vp, sizeof(cmd.vp));
    io->coreRead(&cmd.slot, sizeof(cmd.slot));
    io->coreRead(&cmd.constants, sizeof(cmd.constants));



    rsi_ProgramBindConstants(con,
           cmd.vp,
           cmd.slot,
           cmd.constants);

    io->coreSetReturn(NULL, 0);
};

void rspr_ProgramBindTexture(Context *con, ThreadIO *io) {
    RS_CMD_ProgramBindTexture cmd;
    io->coreRead(&cmd.pf, sizeof(cmd.pf));
    io->coreRead(&cmd.slot, sizeof(cmd.slot));
    io->coreRead(&cmd.a, sizeof(cmd.a));



    rsi_ProgramBindTexture(con,
           cmd.pf,
           cmd.slot,
           cmd.a);

    io->coreSetReturn(NULL, 0);
};

void rspr_ProgramBindSampler(Context *con, ThreadIO *io) {
    RS_CMD_ProgramBindSampler cmd;
    io->coreRead(&cmd.pf, sizeof(cmd.pf));
    io->coreRead(&cmd.slot, sizeof(cmd.slot));
    io->coreRead(&cmd.s, sizeof(cmd.s));



    rsi_ProgramBindSampler(con,
           cmd.pf,
           cmd.slot,
           cmd.s);

    io->coreSetReturn(NULL, 0);
};

void rspr_ProgramFragmentCreate(Context *con, ThreadIO *io) {
    RS_CMD_ProgramFragmentCreate cmd;
    io->coreRead(&cmd.shaderText_length, sizeof(cmd.shaderText_length));
    io->coreRead(&cmd.textureNames_length_length, sizeof(cmd.textureNames_length_length));
    io->coreRead(&cmd.params_length, sizeof(cmd.params_length));

    cmd.shaderText = (const char *)malloc(cmd.shaderText_length);
    if (cmd.shaderText_length) io->coreRead((void *)cmd.shaderText, cmd.shaderText_length);
    cmd.textureNames_length = (const size_t *)malloc(cmd.textureNames_length_length);
    if (cmd.textureNames_length_length) io->coreRead((void *)cmd.textureNames_length, cmd.textureNames_length_length);
    cmd.params = (const uint32_t *)malloc(cmd.params_length);
    if (cmd.params_length) io->coreRead((void *)cmd.params, cmd.params_length);

    for (size_t ct = 0; ct < (cmd.textureNames_length_length / sizeof(cmd.textureNames_length)); ct++) {
        cmd.textureNames = (const char **)malloc(cmd.textureNames_length[ct]);
        io->coreRead(& cmd.textureNames, cmd.textureNames_length[ct]);
    }

    RsProgramFragment ret =
    rsi_ProgramFragmentCreate(con,
           cmd.shaderText,
           cmd.shaderText_length,
           cmd.textureNames,
           cmd.textureNames_length_length,
           cmd.textureNames_length,
           cmd.params,
           cmd.params_length);

    io->coreSetReturn(&ret, sizeof(ret));
    free((void *)cmd.shaderText);
    free((void *)cmd.textureNames_length);
    free((void *)cmd.params);
    for (size_t ct = 0; ct < (cmd.textureNames_length_length / sizeof(cmd.textureNames_length)); ct++) {
        free((void *)cmd.textureNames);
    }
};

void rspr_ProgramVertexCreate(Context *con, ThreadIO *io) {
    RS_CMD_ProgramVertexCreate cmd;
    io->coreRead(&cmd.shaderText_length, sizeof(cmd.shaderText_length));
    io->coreRead(&cmd.textureNames_length_length, sizeof(cmd.textureNames_length_length));
    io->coreRead(&cmd.params_length, sizeof(cmd.params_length));

    cmd.shaderText = (const char *)malloc(cmd.shaderText_length);
    if (cmd.shaderText_length) io->coreRead((void *)cmd.shaderText, cmd.shaderText_length);
    cmd.textureNames_length = (const size_t *)malloc(cmd.textureNames_length_length);
    if (cmd.textureNames_length_length) io->coreRead((void *)cmd.textureNames_length, cmd.textureNames_length_length);
    cmd.params = (const uint32_t *)malloc(cmd.params_length);
    if (cmd.params_length) io->coreRead((void *)cmd.params, cmd.params_length);

    for (size_t ct = 0; ct < (cmd.textureNames_length_length / sizeof(cmd.textureNames_length)); ct++) {
        cmd.textureNames = (const char **)malloc(cmd.textureNames_length[ct]);
        io->coreRead(& cmd.textureNames, cmd.textureNames_length[ct]);
    }

    RsProgramVertex ret =
    rsi_ProgramVertexCreate(con,
           cmd.shaderText,
           cmd.shaderText_length,
           cmd.textureNames,
           cmd.textureNames_length_length,
           cmd.textureNames_length,
           cmd.params,
           cmd.params_length);

    io->coreSetReturn(&ret, sizeof(ret));
    free((void *)cmd.shaderText);
    free((void *)cmd.textureNames_length);
    free((void *)cmd.params);
    for (size_t ct = 0; ct < (cmd.textureNames_length_length / sizeof(cmd.textureNames_length)); ct++) {
        free((void *)cmd.textureNames);
    }
};

void rspr_FontCreateFromFile(Context *con, ThreadIO *io) {
    RS_CMD_FontCreateFromFile cmd;
    io->coreRead(&cmd.name_length, sizeof(cmd.name_length));
    io->coreRead(&cmd.fontSize, sizeof(cmd.fontSize));
    io->coreRead(&cmd.dpi, sizeof(cmd.dpi));

    cmd.name = (const char *)malloc(cmd.name_length);
    if (cmd.name_length) io->coreRead((void *)cmd.name, cmd.name_length);


    RsFont ret =
    rsi_FontCreateFromFile(con,
           cmd.name,
           cmd.name_length,
           cmd.fontSize,
           cmd.dpi);

    io->coreSetReturn(&ret, sizeof(ret));
    free((void *)cmd.name);
};

void rspr_FontCreateFromMemory(Context *con, ThreadIO *io) {
    RS_CMD_FontCreateFromMemory cmd;
    io->coreRead(&cmd.name_length, sizeof(cmd.name_length));
    io->coreRead(&cmd.fontSize, sizeof(cmd.fontSize));
    io->coreRead(&cmd.dpi, sizeof(cmd.dpi));
    io->coreRead(&cmd.data_length, sizeof(cmd.data_length));

    cmd.name = (const char *)malloc(cmd.name_length);
    if (cmd.name_length) io->coreRead((void *)cmd.name, cmd.name_length);
    cmd.data = (const void *)malloc(cmd.data_length);
    if (cmd.data_length) io->coreRead((void *)cmd.data, cmd.data_length);


    RsFont ret =
    rsi_FontCreateFromMemory(con,
           cmd.name,
           cmd.name_length,
           cmd.fontSize,
           cmd.dpi,
           cmd.data,
           cmd.data_length);

    io->coreSetReturn(&ret, sizeof(ret));
    free((void *)cmd.name);
    free((void *)cmd.data);
};

void rspr_MeshCreate(Context *con, ThreadIO *io) {
    RS_CMD_MeshCreate cmd;
    io->coreRead(&cmd.vtx_length, sizeof(cmd.vtx_length));
    io->coreRead(&cmd.idx_length, sizeof(cmd.idx_length));
    io->coreRead(&cmd.primType_length, sizeof(cmd.primType_length));

    cmd.vtx = (RsAllocation *)malloc(cmd.vtx_length);
    cmd.idx = (RsAllocation *)malloc(cmd.idx_length);
    cmd.primType = (uint32_t *)malloc(cmd.primType_length);


    RsMesh ret =
    rsi_MeshCreate(con,
           cmd.vtx,
           cmd.vtx_length,
           cmd.idx,
           cmd.idx_length,
           cmd.primType,
           cmd.primType_length);
    io->coreSetReturn((void *)cmd.vtx, cmd.vtx_length);
    io->coreSetReturn((void *)cmd.idx, cmd.idx_length);
    io->coreSetReturn((void *)cmd.primType, cmd.primType_length);

    io->coreSetReturn(&ret, sizeof(ret));
    free((void *)cmd.vtx);
    free((void *)cmd.idx);
    free((void *)cmd.primType);
};

void rspr_PathCreate(Context *con, ThreadIO *io) {
    RS_CMD_PathCreate cmd;
    io->coreRead(&cmd.pp, sizeof(cmd.pp));
    io->coreRead(&cmd.isStatic, sizeof(cmd.isStatic));
    io->coreRead(&cmd.vertex, sizeof(cmd.vertex));
    io->coreRead(&cmd.loops, sizeof(cmd.loops));
    io->coreRead(&cmd.quality, sizeof(cmd.quality));



    RsPath ret =
    rsi_PathCreate(con,
           cmd.pp,
           cmd.isStatic,
           cmd.vertex,
           cmd.loops,
           cmd.quality);

    io->coreSetReturn(&ret, sizeof(ret));
};

void rspr_ContextBindProgramStore(Context *con, ThreadIO *io) {
    RS_CMD_ContextBindProgramStore cmd;
    io->coreRead(&cmd.pgm, sizeof(cmd.pgm));



    rsi_ContextBindProgramStore(con,
           cmd.pgm);

    io->coreSetReturn(NULL, 0);
};

void rspr_ContextBindProgramFragment(Context *con, ThreadIO *io) {
    RS_CMD_ContextBindProgramFragment cmd;
    io->coreRead(&cmd.pgm, sizeof(cmd.pgm));



    rsi_ContextBindProgramFragment(con,
           cmd.pgm);

    io->coreSetReturn(NULL, 0);
};

void rspr_ContextBindProgramVertex(Context *con, ThreadIO *io) {
    RS_CMD_ContextBindProgramVertex cmd;
    io->coreRead(&cmd.pgm, sizeof(cmd.pgm));



    rsi_ContextBindProgramVertex(con,
           cmd.pgm);

    io->coreSetReturn(NULL, 0);
};

void rspr_ContextBindProgramRaster(Context *con, ThreadIO *io) {
    RS_CMD_ContextBindProgramRaster cmd;
    io->coreRead(&cmd.pgm, sizeof(cmd.pgm));



    rsi_ContextBindProgramRaster(con,
           cmd.pgm);

    io->coreSetReturn(NULL, 0);
};

void rspr_ContextBindFont(Context *con, ThreadIO *io) {
    RS_CMD_ContextBindFont cmd;
    io->coreRead(&cmd.pgm, sizeof(cmd.pgm));



    rsi_ContextBindFont(con,
           cmd.pgm);

    io->coreSetReturn(NULL, 0);
};

void rspr_ContextSetSurface(Context *con, ThreadIO *io) {
    RS_CMD_ContextSetSurface cmd;
    io->coreRead(&cmd.width, sizeof(cmd.width));
    io->coreRead(&cmd.height, sizeof(cmd.height));
    io->coreRead(&cmd.sur, sizeof(cmd.sur));



    rsi_ContextSetSurface(con,
           cmd.width,
           cmd.height,
           cmd.sur);

    io->coreSetReturn(NULL, 0);
};

void rspr_ContextBindRootScript(Context *con, ThreadIO *io) {
    RS_CMD_ContextBindRootScript cmd;
    io->coreRead(&cmd.sampler, sizeof(cmd.sampler));



    rsi_ContextBindRootScript(con,
           cmd.sampler);

    io->coreSetReturn(NULL, 0);
};

void rspr_ContextPause(Context *con, ThreadIO *io) {
    RS_CMD_ContextPause cmd;



    rsi_ContextPause(con);

    io->coreSetReturn(NULL, 0);
};

void rspr_ContextResume(Context *con, ThreadIO *io) {
    RS_CMD_ContextResume cmd;



    rsi_ContextResume(con);

    io->coreSetReturn(NULL, 0);
};

RsPlaybackLocalFunc gPlaybackFuncs[78] = {
    NULL,
    NULL,
    NULL,
    NULL,
    rsp_ContextSendMessage,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    rsp_AllocationGetSurface,
    rsp_AllocationSetSurface,
    rsp_ContextFinish,
    rsp_ContextDump,
    rsp_ContextSetPriority,
    rsp_ContextDestroyWorker,
    rsp_AssignName,
    rsp_ObjDestroy,
    NULL,
    NULL,
    rsp_AllocationCopyToBitmap,
    rsp_Allocation1DData,
    rsp_Allocation1DElementData,
    rsp_Allocation2DData,
    rsp_Allocation3DData,
    rsp_AllocationGenerateMipmaps,
    rsp_AllocationRead,
    rsp_Allocation1DRead,
    rsp_Allocation2DRead,
    rsp_AllocationSyncAll,
    rsp_AllocationResize1D,
    rsp_AllocationCopy2DRange,
    rsp_AllocationCopy3DRange,
    NULL,
    rsp_ScriptBindAllocation,
    rsp_ScriptSetTimeZone,
    rsp_ScriptInvoke,
    rsp_ScriptInvokeV,
    rsp_ScriptForEach,
    rsp_ScriptSetVarI,
    rsp_ScriptSetVarObj,
    rsp_ScriptSetVarJ,
    rsp_ScriptSetVarF,
    rsp_ScriptSetVarD,
    rsp_ScriptSetVarV,
    rsp_ScriptGetVarV,
    rsp_ScriptSetVarVE,
    rsp_ScriptCCreate,
    rsp_ScriptIntrinsicCreate,
    NULL,
    NULL,
    NULL,
    rsp_ScriptGroupSetOutput,
    rsp_ScriptGroupSetInput,
    rsp_ScriptGroupExecute,
    rsp_AllocationIoSend,
    rsp_AllocationIoReceive,
    NULL,
    NULL,
    rsp_ProgramBindConstants,
    rsp_ProgramBindTexture,
    rsp_ProgramBindSampler,
    NULL,
    NULL,
    rsp_FontCreateFromFile,
    rsp_FontCreateFromMemory,
    rsp_MeshCreate,
    rsp_PathCreate,
    rsp_ContextBindProgramStore,
    rsp_ContextBindProgramFragment,
    rsp_ContextBindProgramVertex,
    rsp_ContextBindProgramRaster,
    rsp_ContextBindFont,
    rsp_ContextSetSurface,
    rsp_ContextBindRootScript,
    rsp_ContextPause,
    rsp_ContextResume,
};
RsPlaybackRemoteFunc gPlaybackRemoteFuncs[78] = {
    NULL,
    rspr_ContextDestroy,
    rspr_ContextGetMessage,
    rspr_ContextPeekMessage,
    rspr_ContextSendMessage,
    rspr_ContextInitToClient,
    rspr_ContextDeinitToClient,
    rspr_TypeCreate,
    rspr_AllocationCreateTyped,
    rspr_AllocationCreateFromBitmap,
    rspr_AllocationCubeCreateFromBitmap,
    rspr_AllocationGetSurface,
    rspr_AllocationSetSurface,
    rspr_ContextFinish,
    rspr_ContextDump,
    rspr_ContextSetPriority,
    rspr_ContextDestroyWorker,
    rspr_AssignName,
    rspr_ObjDestroy,
    rspr_ElementCreate,
    rspr_ElementCreate2,
    rspr_AllocationCopyToBitmap,
    rspr_Allocation1DData,
    rspr_Allocation1DElementData,
    rspr_Allocation2DData,
    rspr_Allocation3DData,
    rspr_AllocationGenerateMipmaps,
    rspr_AllocationRead,
    rspr_Allocation1DRead,
    rspr_Allocation2DRead,
    rspr_AllocationSyncAll,
    rspr_AllocationResize1D,
    rspr_AllocationCopy2DRange,
    rspr_AllocationCopy3DRange,
    rspr_SamplerCreate,
    rspr_ScriptBindAllocation,
    rspr_ScriptSetTimeZone,
    rspr_ScriptInvoke,
    rspr_ScriptInvokeV,
    rspr_ScriptForEach,
    rspr_ScriptSetVarI,
    rspr_ScriptSetVarObj,
    rspr_ScriptSetVarJ,
    rspr_ScriptSetVarF,
    rspr_ScriptSetVarD,
    rspr_ScriptSetVarV,
    rspr_ScriptGetVarV,
    rspr_ScriptSetVarVE,
    rspr_ScriptCCreate,
    rspr_ScriptIntrinsicCreate,
    rspr_ScriptKernelIDCreate,
    rspr_ScriptFieldIDCreate,
    rspr_ScriptGroupCreate,
    rspr_ScriptGroupSetOutput,
    rspr_ScriptGroupSetInput,
    rspr_ScriptGroupExecute,
    rspr_AllocationIoSend,
    rspr_AllocationIoReceive,
    rspr_ProgramStoreCreate,
    rspr_ProgramRasterCreate,
    rspr_ProgramBindConstants,
    rspr_ProgramBindTexture,
    rspr_ProgramBindSampler,
    rspr_ProgramFragmentCreate,
    rspr_ProgramVertexCreate,
    rspr_FontCreateFromFile,
    rspr_FontCreateFromMemory,
    rspr_MeshCreate,
    rspr_PathCreate,
    rspr_ContextBindProgramStore,
    rspr_ContextBindProgramFragment,
    rspr_ContextBindProgramVertex,
    rspr_ContextBindProgramRaster,
    rspr_ContextBindFont,
    rspr_ContextSetSurface,
    rspr_ContextBindRootScript,
    rspr_ContextPause,
    rspr_ContextResume,
};
};
};

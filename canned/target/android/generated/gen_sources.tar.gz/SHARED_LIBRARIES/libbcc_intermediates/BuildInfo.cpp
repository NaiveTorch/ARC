/* Automatically generated file (DON'T MODIFY) */

/* Repository directory: /ssd2/android_4.4_r1/frameworks/compile/libbcc */

/* File list:
   38a2fb4907aae1b9b1d6f19c2915c9b304c2fcb0 out/target/product/generic_x86/obj/STATIC_LIBRARIES/libbccCore_intermediates/libbccCore.a
   d1912888474b0a3778e3e81f501ed7c2820290a8 out/target/product/generic_x86/obj/STATIC_LIBRARIES/libbccExecutionEngine_intermediates/libbccExecutionEngine.a
   fffd575af98d4be58d466ec593bc3e6d012fd2c5 out/target/product/generic_x86/obj/STATIC_LIBRARIES/libbccRenderscript_intermediates/libbccRenderscript.a
   e24c7509684e6ac71b4c4fe74be635ea61246ea5 out/target/product/generic_x86/obj/STATIC_LIBRARIES/libbccSupport_intermediates/libbccSupport.a
   a592a3323e4ccf35a2351dab62708aea3c192df6 out/target/product/generic_x86/obj/STATIC_LIBRARIES/librsloader_intermediates/librsloader.a
   01b5c96209b4cf4e80559b37dd755351bbd23b70 out/target/product/generic_x86/obj/lib/libLLVM.so
   45a650ff45963bbefb1990a5e0e69c7ed2abc96f out/target/product/generic_x86/obj/lib/libbcinfo.so
   7c2c4db0655b4848fe4265f28a098ab59ecca39a out/target/product/generic_x86/obj/lib/libcutils.so
   411e897c21eb7da0aec135ae760b9aa5e32c1e63 out/target/product/generic_x86/obj/lib/libdl.so
   1c05bc666e2bac81f661446eb97424226b57d8c0 out/target/product/generic_x86/obj/lib/liblog.so
   848fb68637e8bdcaa737765ace422120354589de out/target/product/generic_x86/obj/lib/libstlport.so
   9b0e78e9a9e1a8050075b8ff80c0a05b3cc9251e out/target/product/generic_x86/obj/lib/libutils.so
*/

#include "bcc/Config/BuildInfo.h"

using namespace bcc;

const char* BuildInfo::GetBuildTime() {
  return "2014/07/08 21:08:53";
}

const char *BuildInfo::GetBuildRev() {
  return "4144caca4b336dd6b94d27fcdb089085f3ffb9cb modified (git)";
}

const char *BuildInfo::GetBuildSourceBlob() {
  return "b30d5b88c28516e5858074325339c4bdee544f35";
}


